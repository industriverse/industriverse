"""
Voice Interface Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements a sophisticated voice interface that enables natural language
interaction with the Ambient Intelligence system, supporting voice commands, queries,
and conversational interactions across different contexts and devices.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import uuid
from datetime import datetime
import re
import threading
import queue

# Initialize logger
logger = logging.getLogger(__name__)

class VoiceInterface:
    """
    Voice Interface component for providing natural language interaction
    within the Universal Skin UI/UX Layer.
    """
    
    # Command types
    TYPE_NAVIGATION = "navigation"
    TYPE_ACTION = "action"
    TYPE_QUERY = "query"
    TYPE_CONTROL = "control"
    TYPE_SYSTEM = "system"
    TYPE_CUSTOM = "custom"
    
    # Interaction modes
    MODE_COMMAND = "command"
    MODE_CONVERSATION = "conversation"
    MODE_AMBIENT = "ambient"
    MODE_DICTATION = "dictation"
    
    # Voice feedback types
    FEEDBACK_CONFIRMATION = "confirmation"
    FEEDBACK_ERROR = "error"
    FEEDBACK_INFORMATION = "information"
    FEEDBACK_SUGGESTION = "suggestion"
    FEEDBACK_AMBIENT = "ambient"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Voice Interface component with optional configuration."""
        self.config = config or {}
        self.command_registry = {}
        self.active_commands = set()
        self.command_history = []
        self.event_subscribers = {}
        self.conversation_context = {}
        self.current_mode = self.MODE_COMMAND
        self.listening = False
        self.processing_queue = queue.Queue()
        self.processing_thread = None
        self.wake_words = self.config.get("wake_words", ["Hey Ambient", "Ambient"])
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.protocol_bridge = None
        self.layer_avatars = None
        
        # Initialize default commands
        self._initialize_default_commands()
        
        logger.info("Voice Interface component initialized with config: %s", self.config)
    
    def _initialize_default_commands(self):
        """Initialize default voice commands."""
        # Navigation commands
        self.register_command({
            "id": "navigate_home",
            "name": "Navigate Home",
            "type": self.TYPE_NAVIGATION,
            "patterns": [
                "go home",
                "navigate to home",
                "show home screen",
                "take me home"
            ],
            "action": self._navigate_home,
            "enabled": True
        })
        
        self.register_command({
            "id": "navigate_to",
            "name": "Navigate To",
            "type": self.TYPE_NAVIGATION,
            "patterns": [
                "go to {destination}",
                "navigate to {destination}",
                "open {destination}",
                "show {destination}"
            ],
            "action": self._navigate_to,
            "enabled": True
        })
        
        # Action commands
        self.register_command({
            "id": "create_capsule",
            "name": "Create Capsule",
            "type": self.TYPE_ACTION,
            "patterns": [
                "create capsule",
                "new capsule",
                "spawn capsule",
                "make a capsule"
            ],
            "action": self._create_capsule,
            "enabled": True
        })
        
        self.register_command({
            "id": "pin_capsule",
            "name": "Pin Capsule",
            "type": self.TYPE_ACTION,
            "patterns": [
                "pin this capsule",
                "pin current capsule",
                "pin capsule",
                "dock this capsule"
            ],
            "action": self._pin_capsule,
            "enabled": True
        })
        
        # Query commands
        self.register_command({
            "id": "status_query",
            "name": "Status Query",
            "type": self.TYPE_QUERY,
            "patterns": [
                "what's the status",
                "system status",
                "how are things running",
                "check status"
            ],
            "action": self._status_query,
            "enabled": True
        })
        
        self.register_command({
            "id": "layer_query",
            "name": "Layer Query",
            "type": self.TYPE_QUERY,
            "patterns": [
                "how is {layer} layer doing",
                "status of {layer} layer",
                "check {layer} layer",
                "{layer} layer status"
            ],
            "action": self._layer_query,
            "enabled": True
        })
        
        # Control commands
        self.register_command({
            "id": "volume_control",
            "name": "Volume Control",
            "type": self.TYPE_CONTROL,
            "patterns": [
                "volume {level}",
                "set volume to {level}",
                "change volume to {level}",
                "{level} volume"
            ],
            "action": self._volume_control,
            "enabled": True
        })
        
        self.register_command({
            "id": "brightness_control",
            "name": "Brightness Control",
            "type": self.TYPE_CONTROL,
            "patterns": [
                "brightness {level}",
                "set brightness to {level}",
                "change brightness to {level}",
                "{level} brightness"
            ],
            "action": self._brightness_control,
            "enabled": True
        })
        
        # System commands
        self.register_command({
            "id": "switch_mode",
            "name": "Switch Mode",
            "type": self.TYPE_SYSTEM,
            "patterns": [
                "switch to {mode} mode",
                "enter {mode} mode",
                "change to {mode} mode",
                "{mode} mode"
            ],
            "action": self._switch_mode,
            "enabled": True
        })
        
        self.register_command({
            "id": "help",
            "name": "Help",
            "type": self.TYPE_SYSTEM,
            "patterns": [
                "help",
                "what can you do",
                "show commands",
                "available commands"
            ],
            "action": self._help,
            "enabled": True
        })
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, protocol_bridge=None,
                  layer_avatars=None):
        """Initialize the Voice Interface component and connect to required services."""
        logger.info("Initializing Voice Interface component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.protocol_bridge = protocol_bridge
        self.layer_avatars = layer_avatars
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("voice_input_detected", self._on_voice_input_detected)
        
        # Start processing thread
        self._start_processing_thread()
        
        logger.info("Voice Interface component initialization complete")
        return True
    
    def _start_processing_thread(self):
        """Start the voice command processing thread."""
        if self.processing_thread is None or not self.processing_thread.is_alive():
            self.processing_thread = threading.Thread(target=self._process_voice_commands)
            self.processing_thread.daemon = True
            self.processing_thread.start()
            logger.info("Voice command processing thread started")
    
    def _process_voice_commands(self):
        """Process voice commands from the queue."""
        while True:
            try:
                voice_input = self.processing_queue.get(timeout=1.0)
                if voice_input:
                    self._process_voice_input(voice_input)
                self.processing_queue.task_done()
            except queue.Empty:
                # No input to process, continue waiting
                pass
            except Exception as e:
                logger.error("Error processing voice command: %s", e)
    
    def register_command(self, command_data: Dict[str, Any]) -> Optional[str]:
        """
        Register a new voice command.
        
        Args:
            command_data: Command data
        
        Returns:
            Optional[str]: Command ID if registered successfully, None otherwise
        """
        logger.info("Registering command: %s", command_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type", "patterns"]
        for field in required_fields:
            if field not in command_data:
                logger.warning("Missing required field in command: %s", field)
                return None
        
        # Generate command ID if not provided
        command_id = command_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "action" not in command_data:
            logger.warning("Command has no action: %s", command_data.get("name"))
            return None
        
        if "enabled" not in command_data:
            command_data["enabled"] = True
        
        if "metadata" not in command_data:
            command_data["metadata"] = {}
        
        if "created_at" not in command_data:
            command_data["created_at"] = datetime.now().isoformat()
        
        # Store command ID
        command_data["id"] = command_id
        
        # Compile patterns into regex for faster matching
        command_data["compiled_patterns"] = []
        for pattern in command_data["patterns"]:
            # Convert {param} to regex capture groups
            regex_pattern = re.sub(r'\{(\w+)\}', r'(?P<\1>[\w\s]+)', pattern)
            # Compile regex
            compiled_pattern = re.compile(f"^{regex_pattern}$", re.IGNORECASE)
            command_data["compiled_patterns"].append(compiled_pattern)
        
        # Store command
        self.command_registry[command_id] = command_data
        
        # Add to active commands if enabled
        if command_data["enabled"]:
            self.active_commands.add(command_id)
        
        # Notify subscribers
        self._notify_subscribers("command_registered", {
            "command_id": command_id,
            "command": command_data
        })
        
        return command_id
    
    def update_command(self, command_id: str, command_data: Dict[str, Any]) -> bool:
        """
        Update an existing voice command.
        
        Args:
            command_id: Command identifier
            command_data: Updated command data
        
        Returns:
            bool: True if command was updated successfully, False otherwise
        """
        logger.info("Updating command: %s", command_id)
        
        if command_id not in self.command_registry:
            logger.warning("Command not found: %s", command_id)
            return False
        
        # Get current command data
        current_data = self.command_registry[command_id]
        
        # Update fields
        for key, value in command_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Recompile patterns if updated
        if "patterns" in command_data:
            current_data["compiled_patterns"] = []
            for pattern in current_data["patterns"]:
                # Convert {param} to regex capture groups
                regex_pattern = re.sub(r'\{(\w+)\}', r'(?P<\1>[\w\s]+)', pattern)
                # Compile regex
                compiled_pattern = re.compile(f"^{regex_pattern}$", re.IGNORECASE)
                current_data["compiled_patterns"].append(compiled_pattern)
        
        # Update active commands
        if current_data["enabled"]:
            self.active_commands.add(command_id)
        else:
            self.active_commands.discard(command_id)
        
        # Notify subscribers
        self._notify_subscribers("command_updated", {
            "command_id": command_id,
            "command": current_data
        })
        
        return True
    
    def delete_command(self, command_id: str) -> bool:
        """
        Delete a voice command.
        
        Args:
            command_id: Command identifier
        
        Returns:
            bool: True if command was deleted successfully, False otherwise
        """
        logger.info("Deleting command: %s", command_id)
        
        if command_id not in self.command_registry:
            logger.warning("Command not found: %s", command_id)
            return False
        
        # Remove command
        del self.command_registry[command_id]
        
        # Remove from active commands
        self.active_commands.discard(command_id)
        
        # Notify subscribers
        self._notify_subscribers("command_deleted", {
            "command_id": command_id
        })
        
        return True
    
    def get_command(self, command_id: str) -> Optional[Dict[str, Any]]:
        """
        Get command by ID.
        
        Args:
            command_id: Command identifier
        
        Returns:
            Optional[Dict[str, Any]]: Command if found, None otherwise
        """
        if command_id in self.command_registry:
            return self.command_registry[command_id]
        else:
            logger.warning("Command not found: %s", command_id)
            return None
    
    def get_all_commands(self, command_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all commands, optionally filtered by type.
        
        Args:
            command_type: Optional command type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of commands
        """
        commands = list(self.command_registry.values())
        
        if command_type:
            commands = [c for c in commands if c.get("type") == command_type]
        
        return commands
    
    def get_active_commands(self, command_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get active commands, optionally filtered by type.
        
        Args:
            command_type: Optional command type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of active commands
        """
        active_commands = [self.command_registry[cid] for cid in self.active_commands 
                         if cid in self.command_registry]
        
        if command_type:
            active_commands = [c for c in active_commands if c.get("type") == command_type]
        
        return active_commands
    
    def enable_command(self, command_id: str) -> bool:
        """
        Enable a voice command.
        
        Args:
            command_id: Command identifier
        
        Returns:
            bool: True if command was enabled successfully, False otherwise
        """
        logger.info("Enabling command: %s", command_id)
        
        if command_id not in self.command_registry:
            logger.warning("Command not found: %s", command_id)
            return False
        
        # Update command
        self.command_registry[command_id]["enabled"] = True
        
        # Add to active commands
        self.active_commands.add(command_id)
        
        # Notify subscribers
        self._notify_subscribers("command_enabled", {
            "command_id": command_id
        })
        
        return True
    
    def disable_command(self, command_id: str) -> bool:
        """
        Disable a voice command.
        
        Args:
            command_id: Command identifier
        
        Returns:
            bool: True if command was disabled successfully, False otherwise
        """
        logger.info("Disabling command: %s", command_id)
        
        if command_id not in self.command_registry:
            logger.warning("Command not found: %s", command_id)
            return False
        
        # Update command
        self.command_registry[command_id]["enabled"] = False
        
        # Remove from active commands
        self.active_commands.discard(command_id)
        
        # Notify subscribers
        self._notify_subscribers("command_disabled", {
            "command_id": command_id
        })
        
        return True
    
    def enable_commands_by_type(self, command_type: str) -> int:
        """
        Enable all commands of a specific type.
        
        Args:
            command_type: Command type
        
        Returns:
            int: Number of commands enabled
        """
        logger.info("Enabling commands of type: %s", command_type)
        
        count = 0
        for command_id, command in self.command_registry.items():
            if command.get("type") == command_type and not command.get("enabled", False):
                command["enabled"] = True
                self.active_commands.add(command_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("commands_enabled_by_type", {
                "command_type": command_type,
                "count": count
            })
        
        return count
    
    def disable_commands_by_type(self, command_type: str) -> int:
        """
        Disable all commands of a specific type.
        
        Args:
            command_type: Command type
        
        Returns:
            int: Number of commands disabled
        """
        logger.info("Disabling commands of type: %s", command_type)
        
        count = 0
        for command_id, command in self.command_registry.items():
            if command.get("type") == command_type and command.get("enabled", False):
                command["enabled"] = False
                self.active_commands.discard(command_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("commands_disabled_by_type", {
                "command_type": command_type,
                "count": count
            })
        
        return count
    
    def start_listening(self) -> bool:
        """
        Start listening for voice commands.
        
        Returns:
            bool: True if listening was started successfully, False otherwise
        """
        logger.info("Starting voice command listening")
        
        if self.listening:
            logger.warning("Already listening for voice commands")
            return False
        
        self.listening = True
        
        # Notify subscribers
        self._notify_subscribers("listening_started", {})
        
        return True
    
    def stop_listening(self) -> bool:
        """
        Stop listening for voice commands.
        
        Returns:
            bool: True if listening was stopped successfully, False otherwise
        """
        logger.info("Stopping voice command listening")
        
        if not self.listening:
            logger.warning("Not currently listening for voice commands")
            return False
        
        self.listening = False
        
        # Notify subscribers
        self._notify_subscribers("listening_stopped", {})
        
        return True
    
    def is_listening(self) -> bool:
        """
        Check if currently listening for voice commands.
        
        Returns:
            bool: True if listening, False otherwise
        """
        return self.listening
    
    def set_mode(self, mode: str) -> bool:
        """
        Set the voice interface mode.
        
        Args:
            mode: Voice interface mode
        
        Returns:
            bool: True if mode was set successfully, False otherwise
        """
        logger.info("Setting voice interface mode: %s", mode)
        
        valid_modes = [self.MODE_COMMAND, self.MODE_CONVERSATION, 
                      self.MODE_AMBIENT, self.MODE_DICTATION]
        
        if mode not in valid_modes:
            logger.warning("Invalid voice interface mode: %s", mode)
            return False
        
        self.current_mode = mode
        
        # Notify subscribers
        self._notify_subscribers("mode_changed", {
            "mode": mode
        })
        
        return True
    
    def get_mode(self) -> str:
        """
        Get the current voice interface mode.
        
        Returns:
            str: Current voice interface mode
        """
        return self.current_mode
    
    def process_voice_input(self, voice_input: str) -> None:
        """
        Process voice input.
        
        Args:
            voice_input: Voice input string
        """
        logger.info("Processing voice input: %s", voice_input)
        
        if not self.listening:
            logger.warning("Not currently listening for voice commands")
            return
        
        # Add to processing queue
        self.processing_queue.put(voice_input)
    
    def _process_voice_input(self, voice_input: str) -> Optional[Dict[str, Any]]:
        """
        Process voice input internally.
        
        Args:
            voice_input: Voice input string
        
        Returns:
            Optional[Dict[str, Any]]: Processed command if any, None otherwise
        """
        # Check for wake word if not in conversation or ambient mode
        if self.current_mode not in [self.MODE_CONVERSATION, self.MODE_AMBIENT]:
            wake_word_detected = False
            for wake_word in self.wake_words:
                if voice_input.lower().startswith(wake_word.lower()):
                    wake_word_detected = True
                    # Remove wake word from input
                    voice_input = voice_input[len(wake_word):].strip()
                    break
            
            if not wake_word_detected:
                logger.debug("No wake word detected in input")
                return None
        
        # Process based on current mode
        if self.current_mode == self.MODE_COMMAND:
            return self._process_command_mode(voice_input)
        elif self.current_mode == self.MODE_CONVERSATION:
            return self._process_conversation_mode(voice_input)
        elif self.current_mode == self.MODE_AMBIENT:
            return self._process_ambient_mode(voice_input)
        elif self.current_mode == self.MODE_DICTATION:
            return self._process_dictation_mode(voice_input)
        
        return None
    
    def _process_command_mode(self, voice_input: str) -> Optional[Dict[str, Any]]:
        """
        Process voice input in command mode.
        
        Args:
            voice_input: Voice input string
        
        Returns:
            Optional[Dict[str, Any]]: Processed command if any, None otherwise
        """
        # Get active commands
        active_commands = self.get_active_commands()
        if not active_commands:
            logger.warning("No active commands available")
            return None
        
        # Match input against command patterns
        for command in active_commands:
            command_id = command.get("id")
            compiled_patterns = command.get("compiled_patterns", [])
            
            for pattern in compiled_patterns:
                match = pattern.match(voice_input)
                if match:
                    # Extract parameters
                    params = match.groupdict()
                    
                    # Create command result
                    result = {
                        "command_id": command_id,
                        "command_type": command.get("type"),
                        "command_name": command.get("name"),
                        "parameters": params,
                        "raw_input": voice_input,
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    # Add to history
                    self.command_history.append(result)
                    
                    # Limit history size
                    max_history = self.config.get("max_history_size", 100)
                    if len(self.command_history) > max_history:
                        self.command_history = self.command_history[-max_history:]
                    
                    # Execute command action
                    action = command.get("action")
                    if action and callable(action):
                        try:
                            action_result = action(params)
                            result["action_result"] = action_result
                        except Exception as e:
                            logger.error("Error executing command action: %s", e)
                            result["error"] = str(e)
                    
                    # Notify subscribers
                    self._notify_subscribers("command_processed", result)
                    
                    return result
        
        # No matching command found
        logger.info("No matching command found for input: %s", voice_input)
        
        # Notify subscribers
        self._notify_subscribers("command_not_recognized", {
            "raw_input": voice_input,
            "timestamp": datetime.now().isoformat()
        })
        
        return None
    
    def _process_conversation_mode(self, voice_input: str) -> Optional[Dict[str, Any]]:
        """
        Process voice input in conversation mode.
        
        Args:
            voice_input: Voice input string
        
        Returns:
            Optional[Dict[str, Any]]: Processed conversation if any, None otherwise
        """
        # In conversation mode, maintain context and handle more natural language
        
        # Check for exit conversation mode command
        exit_phrases = ["exit conversation", "end conversation", "stop conversation", "command mode"]
        if any(voice_input.lower() == phrase for phrase in exit_phrases):
            self.set_mode(self.MODE_COMMAND)
            
            # Provide feedback
            self._provide_voice_feedback(
                self.FEEDBACK_CONFIRMATION,
                "Exiting conversation mode"
            )
            
            return {
                "conversation_action": "exit",
                "raw_input": voice_input,
                "timestamp": datetime.now().isoformat()
            }
        
        # Update conversation context
        if "history" not in self.conversation_context:
            self.conversation_context["history"] = []
        
        self.conversation_context["history"].append({
            "role": "user",
            "content": voice_input,
            "timestamp": datetime.now().isoformat()
        })
        
        # Process conversation input
        # This would typically involve sending to an LLM or other conversation processor
        # For now, we'll just echo back
        response = f"I heard: {voice_input}"
        
        # Update conversation context with response
        self.conversation_context["history"].append({
            "role": "assistant",
            "content": response,
            "timestamp": datetime.now().isoformat()
        })
        
        # Provide voice feedback
        self._provide_voice_feedback(
            self.FEEDBACK_INFORMATION,
            response
        )
        
        # Create result
        result = {
            "conversation_input": voice_input,
            "conversation_response": response,
            "conversation_context": self.conversation_context,
            "timestamp": datetime.now().isoformat()
        }
        
        # Notify subscribers
        self._notify_subscribers("conversation_processed", result)
        
        return result
    
    def _process_ambient_mode(self, voice_input: str) -> Optional[Dict[str, Any]]:
        """
        Process voice input in ambient mode.
        
        Args:
            voice_input: Voice input string
        
        Returns:
            Optional[Dict[str, Any]]: Processed ambient input if any, None otherwise
        """
        # In ambient mode, listen passively and only respond to specific triggers
        
        # Check for exit ambient mode command
        exit_phrases = ["exit ambient", "end ambient", "stop ambient", "command mode"]
        if any(voice_input.lower() == phrase for phrase in exit_phrases):
            self.set_mode(self.MODE_COMMAND)
            
            # Provide feedback
            self._provide_voice_feedback(
                self.FEEDBACK_CONFIRMATION,
                "Exiting ambient mode"
            )
            
            return {
                "ambient_action": "exit",
                "raw_input": voice_input,
                "timestamp": datetime.now().isoformat()
            }
        
        # Check for ambient triggers
        # This would typically involve more sophisticated analysis
        # For now, just check for some keywords
        
        ambient_triggers = {
            "status": "Checking system status...",
            "alert": "No alerts detected",
            "notification": "You have no new notifications",
            "update": "All systems are up to date"
        }
        
        for trigger, response in ambient_triggers.items():
            if trigger in voice_input.lower():
                # Provide ambient feedback
                self._provide_voice_feedback(
                    self.FEEDBACK_AMBIENT,
                    response
                )
                
                # Create result
                result = {
                    "ambient_trigger": trigger,
                    "ambient_response": response,
                    "raw_input": voice_input,
                    "timestamp": datetime.now().isoformat()
                }
                
                # Notify subscribers
                self._notify_subscribers("ambient_processed", result)
                
                return result
        
        # No trigger detected, just log and continue listening
        logger.debug("No ambient trigger detected in: %s", voice_input)
        
        return None
    
    def _process_dictation_mode(self, voice_input: str) -> Optional[Dict[str, Any]]:
        """
        Process voice input in dictation mode.
        
        Args:
            voice_input: Voice input string
        
        Returns:
            Optional[Dict[str, Any]]: Processed dictation if any, None otherwise
        """
        # In dictation mode, capture text for input fields
        
        # Check for exit dictation mode command
        exit_phrases = ["exit dictation", "end dictation", "stop dictation", "command mode"]
        if any(voice_input.lower() == phrase for phrase in exit_phrases):
            self.set_mode(self.MODE_COMMAND)
            
            # Provide feedback
            self._provide_voice_feedback(
                self.FEEDBACK_CONFIRMATION,
                "Exiting dictation mode"
            )
            
            return {
                "dictation_action": "exit",
                "raw_input": voice_input,
                "timestamp": datetime.now().isoformat()
            }
        
        # Process dictation input
        # This would typically involve sending to a dictation target
        
        # Create result
        result = {
            "dictation_text": voice_input,
            "timestamp": datetime.now().isoformat()
        }
        
        # Notify subscribers
        self._notify_subscribers("dictation_processed", result)
        
        return result
    
    def _provide_voice_feedback(self, feedback_type: str, message: str) -> None:
        """
        Provide voice feedback to the user.
        
        Args:
            feedback_type: Type of feedback
            message: Feedback message
        """
        logger.info("Providing voice feedback: %s - %s", feedback_type, message)
        
        # This would typically involve text-to-speech
        # For now, just log and notify subscribers
        
        feedback_data = {
            "type": feedback_type,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        
        # Notify subscribers
        self._notify_subscribers("voice_feedback", feedback_data)
    
    def get_command_history(self, limit: Optional[int] = None, 
                          command_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get command history.
        
        Args:
            limit: Optional limit on number of history items to return
            command_type: Optional command type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of command history items
        """
        history = self.command_history
        
        if command_type:
            history = [h for h in history if h.get("command_type") == command_type]
        
        if limit:
            history = history[-limit:]
        
        return history
    
    def clear_command_history(self) -> bool:
        """
        Clear command history.
        
        Returns:
            bool: True if history was cleared successfully
        """
        logger.info("Clearing command history")
        
        self.command_history = []
        
        # Notify subscribers
        self._notify_subscribers("command_history_cleared", {})
        
        return True
    
    def clear_conversation_context(self) -> bool:
        """
        Clear conversation context.
        
        Returns:
            bool: True if context was cleared successfully
        """
        logger.info("Clearing conversation context")
        
        self.conversation_context = {}
        
        # Notify subscribers
        self._notify_subscribers("conversation_context_cleared", {})
        
        return True
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Adjust voice interface based on context
        if context_type == "user_context":
            # Adjust for user preferences
            user_id = context_data.get("user_id")
            if user_id:
                logger.info("Adjusting voice interface for user: %s", user_id)
                # Apply user preferences
        
        elif context_type == "application_context":
            # Adjust for application needs
            app_id = context_data.get("app_id")
            if app_id:
                logger.info("Adjusting voice interface for application: %s", app_id)
                # Enable/disable commands based on application needs
        
        elif context_type == "task_context":
            # Adjust for current task
            task_type = context_data.get("task_type")
            if task_type:
                logger.info("Adjusting voice interface for task: %s", task_type)
                # Enable/disable commands based on task requirements
        
        elif context_type == "environment_context":
            # Adjust for environment
            noise_level = context_data.get("noise_level")
            if noise_level:
                logger.info("Adjusting voice interface for noise level: %s", noise_level)
                # Adjust voice recognition sensitivity
    
    def _on_voice_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle voice input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Voice input detected: %s", event_data)
        
        voice_input = event_data.get("input")
        if voice_input:
            self.process_voice_input(voice_input)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Voice Interface events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Voice Interface events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    # Default command actions
    
    def _navigate_home(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Navigate to home screen.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        logger.info("Navigating to home screen")
        
        # This would typically involve calling the Universal Skin Shell
        if self.universal_skin_shell:
            # Call navigation method
            pass
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            "Navigating to home screen"
        )
        
        return {
            "success": True,
            "destination": "home"
        }
    
    def _navigate_to(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Navigate to specified destination.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        destination = params.get("destination", "").strip().lower()
        logger.info("Navigating to: %s", destination)
        
        # This would typically involve calling the Universal Skin Shell
        if self.universal_skin_shell:
            # Call navigation method
            pass
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            f"Navigating to {destination}"
        )
        
        return {
            "success": True,
            "destination": destination
        }
    
    def _create_capsule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new capsule.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        logger.info("Creating new capsule")
        
        # This would typically involve calling the Capsule Manager
        capsule_id = str(uuid.uuid4())
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            "Creating new capsule"
        )
        
        return {
            "success": True,
            "capsule_id": capsule_id
        }
    
    def _pin_capsule(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Pin the current capsule.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        logger.info("Pinning current capsule")
        
        # This would typically involve calling the Capsule Manager
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            "Pinning current capsule"
        )
        
        return {
            "success": True
        }
    
    def _status_query(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Query system status.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        logger.info("Querying system status")
        
        # This would typically involve gathering status from various components
        status = "All systems are operating normally"
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_INFORMATION,
            status
        )
        
        return {
            "success": True,
            "status": status
        }
    
    def _layer_query(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Query layer status.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        layer = params.get("layer", "").strip().lower()
        logger.info("Querying status of layer: %s", layer)
        
        # This would typically involve querying the specific layer
        # For now, just provide a generic response
        status = f"The {layer} layer is operating normally"
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_INFORMATION,
            status
        )
        
        return {
            "success": True,
            "layer": layer,
            "status": status
        }
    
    def _volume_control(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Control system volume.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        level = params.get("level", "").strip().lower()
        logger.info("Setting volume to: %s", level)
        
        # Parse level
        volume = None
        if level in ["mute", "off"]:
            volume = 0
        elif level in ["low", "quiet"]:
            volume = 25
        elif level in ["medium", "normal"]:
            volume = 50
        elif level in ["high", "loud"]:
            volume = 75
        elif level in ["maximum", "max", "full"]:
            volume = 100
        else:
            try:
                # Try to parse as number
                volume = int(level.rstrip("%"))
                if volume < 0:
                    volume = 0
                elif volume > 100:
                    volume = 100
            except ValueError:
                # Invalid level
                self._provide_voice_feedback(
                    self.FEEDBACK_ERROR,
                    f"Invalid volume level: {level}"
                )
                return {
                    "success": False,
                    "error": f"Invalid volume level: {level}"
                }
        
        # This would typically involve setting system volume
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            f"Volume set to {volume}%"
        )
        
        return {
            "success": True,
            "volume": volume
        }
    
    def _brightness_control(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Control display brightness.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        level = params.get("level", "").strip().lower()
        logger.info("Setting brightness to: %s", level)
        
        # Parse level
        brightness = None
        if level in ["dim", "low", "dark"]:
            brightness = 25
        elif level in ["medium", "normal"]:
            brightness = 50
        elif level in ["high", "bright"]:
            brightness = 75
        elif level in ["maximum", "max", "full"]:
            brightness = 100
        else:
            try:
                # Try to parse as number
                brightness = int(level.rstrip("%"))
                if brightness < 0:
                    brightness = 0
                elif brightness > 100:
                    brightness = 100
            except ValueError:
                # Invalid level
                self._provide_voice_feedback(
                    self.FEEDBACK_ERROR,
                    f"Invalid brightness level: {level}"
                )
                return {
                    "success": False,
                    "error": f"Invalid brightness level: {level}"
                }
        
        # This would typically involve setting display brightness
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            f"Brightness set to {brightness}%"
        )
        
        return {
            "success": True,
            "brightness": brightness
        }
    
    def _switch_mode(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Switch voice interface mode.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        mode = params.get("mode", "").strip().lower()
        logger.info("Switching to mode: %s", mode)
        
        # Map mode name to constant
        mode_map = {
            "command": self.MODE_COMMAND,
            "conversation": self.MODE_CONVERSATION,
            "ambient": self.MODE_AMBIENT,
            "dictation": self.MODE_DICTATION
        }
        
        if mode not in mode_map:
            # Invalid mode
            self._provide_voice_feedback(
                self.FEEDBACK_ERROR,
                f"Invalid mode: {mode}"
            )
            return {
                "success": False,
                "error": f"Invalid mode: {mode}"
            }
        
        # Set mode
        new_mode = mode_map[mode]
        self.set_mode(new_mode)
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_CONFIRMATION,
            f"Switched to {mode} mode"
        )
        
        return {
            "success": True,
            "mode": new_mode
        }
    
    def _help(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Provide help information.
        
        Args:
            params: Command parameters
        
        Returns:
            Dict[str, Any]: Action result
        """
        logger.info("Providing help information")
        
        # Get active commands
        active_commands = self.get_active_commands()
        
        # Group by type
        commands_by_type = {}
        for command in active_commands:
            command_type = command.get("type")
            if command_type not in commands_by_type:
                commands_by_type[command_type] = []
            commands_by_type[command_type].append(command)
        
        # Build help message
        help_message = "Here are some things you can say: "
        
        for command_type, commands in commands_by_type.items():
            # Add a few examples from each type
            examples = []
            for command in commands[:2]:  # Limit to 2 examples per type
                patterns = command.get("patterns", [])
                if patterns:
                    # Get first pattern and replace parameters with examples
                    pattern = patterns[0]
                    pattern = re.sub(r'\{destination\}', "dashboard", pattern)
                    pattern = re.sub(r'\{layer\}', "data", pattern)
                    pattern = re.sub(r'\{level\}', "50", pattern)
                    pattern = re.sub(r'\{mode\}', "conversation", pattern)
                    examples.append(pattern)
            
            if examples:
                help_message += f"{', '.join(examples)}. "
        
        # Provide feedback
        self._provide_voice_feedback(
            self.FEEDBACK_INFORMATION,
            help_message
        )
        
        return {
            "success": True,
            "help_message": help_message,
            "commands_by_type": commands_by_type
        }
