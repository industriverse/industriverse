"""
Gesture Recognition Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements a sophisticated gesture recognition system that works across
different input modalities (touch, mouse, pen, camera-based hand tracking, etc.) to provide
a consistent and intuitive interaction model regardless of device or context.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import math
import uuid
from datetime import datetime
import numpy as np

# Initialize logger
logger = logging.getLogger(__name__)

class GestureRecognition:
    """
    Gesture Recognition component for providing a consistent interaction model
    across different input modalities and devices within the Universal Skin UI/UX Layer.
    """
    
    # Gesture type constants
    TYPE_TAP = "tap"
    TYPE_DOUBLE_TAP = "double_tap"
    TYPE_LONG_PRESS = "long_press"
    TYPE_SWIPE = "swipe"
    TYPE_PINCH = "pinch"
    TYPE_ROTATE = "rotate"
    TYPE_HOVER = "hover"
    TYPE_DRAG = "drag"
    TYPE_FLICK = "flick"
    TYPE_MULTI_TOUCH = "multi_touch"
    TYPE_HAND_POSE = "hand_pose"
    TYPE_GAZE = "gaze"
    TYPE_CUSTOM = "custom"
    
    # Input modality constants
    MODALITY_TOUCH = "touch"
    MODALITY_MOUSE = "mouse"
    MODALITY_PEN = "pen"
    MODALITY_CAMERA = "camera"
    MODALITY_LEAP_MOTION = "leap_motion"
    MODALITY_VR_CONTROLLER = "vr_controller"
    MODALITY_AR_GLASSES = "ar_glasses"
    MODALITY_GAZE_TRACKER = "gaze_tracker"
    MODALITY_CUSTOM = "custom"
    
    # Direction constants
    DIRECTION_UP = "up"
    DIRECTION_DOWN = "down"
    DIRECTION_LEFT = "left"
    DIRECTION_RIGHT = "right"
    DIRECTION_IN = "in"
    DIRECTION_OUT = "out"
    DIRECTION_CLOCKWISE = "clockwise"
    DIRECTION_COUNTERCLOCKWISE = "counterclockwise"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Gesture Recognition component with optional configuration."""
        self.config = config or {}
        self.gesture_definitions = {}
        self.active_gestures = set()
        self.gesture_history = []
        self.event_subscribers = {}
        self.input_handlers = {}
        self.calibration_data = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.device_adapter = None
        
        # Initialize default gesture definitions
        self._initialize_default_gestures()
        
        logger.info("Gesture Recognition component initialized with config: %s", self.config)
    
    def _initialize_default_gestures(self):
        """Initialize default gesture definitions."""
        # Tap gesture
        self.register_gesture({
            "id": "tap",
            "name": "Tap",
            "type": self.TYPE_TAP,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "max_duration": 300,  # ms
                "max_movement": 10    # pixels
            },
            "enabled": True
        })
        
        # Double tap gesture
        self.register_gesture({
            "id": "double_tap",
            "name": "Double Tap",
            "type": self.TYPE_DOUBLE_TAP,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "max_duration": 300,  # ms
                "max_movement": 10,   # pixels
                "max_interval": 500   # ms between taps
            },
            "enabled": True
        })
        
        # Long press gesture
        self.register_gesture({
            "id": "long_press",
            "name": "Long Press",
            "type": self.TYPE_LONG_PRESS,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "min_duration": 500,  # ms
                "max_movement": 10    # pixels
            },
            "enabled": True
        })
        
        # Swipe gesture
        self.register_gesture({
            "id": "swipe",
            "name": "Swipe",
            "type": self.TYPE_SWIPE,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "min_distance": 50,   # pixels
                "max_duration": 500,  # ms
                "min_velocity": 0.5   # pixels/ms
            },
            "enabled": True
        })
        
        # Pinch gesture
        self.register_gesture({
            "id": "pinch",
            "name": "Pinch",
            "type": self.TYPE_PINCH,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_CAMERA, self.MODALITY_LEAP_MOTION],
            "parameters": {
                "min_scale_change": 0.1,  # 10% change
                "max_duration": 1000      # ms
            },
            "enabled": True
        })
        
        # Rotate gesture
        self.register_gesture({
            "id": "rotate",
            "name": "Rotate",
            "type": self.TYPE_ROTATE,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_CAMERA, self.MODALITY_LEAP_MOTION],
            "parameters": {
                "min_angle": 15,      # degrees
                "max_duration": 1000  # ms
            },
            "enabled": True
        })
        
        # Hover gesture
        self.register_gesture({
            "id": "hover",
            "name": "Hover",
            "type": self.TYPE_HOVER,
            "modalities": [self.MODALITY_MOUSE, self.MODALITY_PEN, self.MODALITY_LEAP_MOTION],
            "parameters": {
                "min_duration": 300,  # ms
                "max_movement": 15    # pixels
            },
            "enabled": True
        })
        
        # Drag gesture
        self.register_gesture({
            "id": "drag",
            "name": "Drag",
            "type": self.TYPE_DRAG,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "min_distance": 10,   # pixels
                "min_duration": 100   # ms
            },
            "enabled": True
        })
        
        # Flick gesture
        self.register_gesture({
            "id": "flick",
            "name": "Flick",
            "type": self.TYPE_FLICK,
            "modalities": [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN],
            "parameters": {
                "min_velocity": 1.0,  # pixels/ms
                "max_duration": 300   # ms
            },
            "enabled": True
        })
        
        # Multi-touch gesture
        self.register_gesture({
            "id": "multi_touch",
            "name": "Multi-Touch",
            "type": self.TYPE_MULTI_TOUCH,
            "modalities": [self.MODALITY_TOUCH],
            "parameters": {
                "min_touches": 3,     # number of touch points
                "min_duration": 100   # ms
            },
            "enabled": True
        })
        
        # Hand pose gesture
        self.register_gesture({
            "id": "hand_pose_open",
            "name": "Open Hand",
            "type": self.TYPE_HAND_POSE,
            "modalities": [self.MODALITY_CAMERA, self.MODALITY_LEAP_MOTION],
            "parameters": {
                "pose": "open_hand",
                "min_confidence": 0.7,
                "min_duration": 300   # ms
            },
            "enabled": True
        })
        
        # Gaze gesture
        self.register_gesture({
            "id": "gaze_dwell",
            "name": "Gaze Dwell",
            "type": self.TYPE_GAZE,
            "modalities": [self.MODALITY_GAZE_TRACKER, self.MODALITY_AR_GLASSES],
            "parameters": {
                "min_duration": 800,  # ms
                "max_movement": 20    # pixels
            },
            "enabled": True
        })
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, device_adapter=None):
        """Initialize the Gesture Recognition component and connect to required services."""
        logger.info("Initializing Gesture Recognition component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.device_adapter = device_adapter
        
        # Register input handlers for different modalities
        self._register_input_handlers()
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
            self.context_engine.subscribe_to_events("device_changed", self._on_device_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.device_adapter:
            self.device_adapter.subscribe_to_events("capabilities_changed", self._on_capabilities_changed)
        
        logger.info("Gesture Recognition component initialization complete")
        return True
    
    def _register_input_handlers(self):
        """Register input handlers for different modalities."""
        # Touch input handler
        self.input_handlers[self.MODALITY_TOUCH] = self._handle_touch_input
        
        # Mouse input handler
        self.input_handlers[self.MODALITY_MOUSE] = self._handle_mouse_input
        
        # Pen input handler
        self.input_handlers[self.MODALITY_PEN] = self._handle_pen_input
        
        # Camera input handler
        self.input_handlers[self.MODALITY_CAMERA] = self._handle_camera_input
        
        # Leap Motion input handler
        self.input_handlers[self.MODALITY_LEAP_MOTION] = self._handle_leap_motion_input
        
        # VR controller input handler
        self.input_handlers[self.MODALITY_VR_CONTROLLER] = self._handle_vr_controller_input
        
        # AR glasses input handler
        self.input_handlers[self.MODALITY_AR_GLASSES] = self._handle_ar_glasses_input
        
        # Gaze tracker input handler
        self.input_handlers[self.MODALITY_GAZE_TRACKER] = self._handle_gaze_tracker_input
    
    def register_gesture(self, gesture_data: Dict[str, Any]) -> Optional[str]:
        """
        Register a new gesture.
        
        Args:
            gesture_data: Gesture data
        
        Returns:
            Optional[str]: Gesture ID if registered successfully, None otherwise
        """
        logger.info("Registering gesture: %s", gesture_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type", "modalities"]
        for field in required_fields:
            if field not in gesture_data:
                logger.warning("Missing required field in gesture: %s", field)
                return None
        
        # Generate gesture ID if not provided
        gesture_id = gesture_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "parameters" not in gesture_data:
            gesture_data["parameters"] = {}
        
        if "enabled" not in gesture_data:
            gesture_data["enabled"] = True
        
        if "metadata" not in gesture_data:
            gesture_data["metadata"] = {}
        
        if "created_at" not in gesture_data:
            gesture_data["created_at"] = datetime.now().isoformat()
        
        # Store gesture ID
        gesture_data["id"] = gesture_id
        
        # Store gesture
        self.gesture_definitions[gesture_id] = gesture_data
        
        # Add to active gestures if enabled
        if gesture_data["enabled"]:
            self.active_gestures.add(gesture_id)
        
        # Notify subscribers
        self._notify_subscribers("gesture_registered", {
            "gesture_id": gesture_id,
            "gesture": gesture_data
        })
        
        return gesture_id
    
    def update_gesture(self, gesture_id: str, gesture_data: Dict[str, Any]) -> bool:
        """
        Update an existing gesture.
        
        Args:
            gesture_id: Gesture identifier
            gesture_data: Updated gesture data
        
        Returns:
            bool: True if gesture was updated successfully, False otherwise
        """
        logger.info("Updating gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Get current gesture data
        current_data = self.gesture_definitions[gesture_id]
        
        # Update fields
        for key, value in gesture_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update active gestures
        if current_data["enabled"]:
            self.active_gestures.add(gesture_id)
        else:
            self.active_gestures.discard(gesture_id)
        
        # Notify subscribers
        self._notify_subscribers("gesture_updated", {
            "gesture_id": gesture_id,
            "gesture": current_data
        })
        
        return True
    
    def delete_gesture(self, gesture_id: str) -> bool:
        """
        Delete a gesture.
        
        Args:
            gesture_id: Gesture identifier
        
        Returns:
            bool: True if gesture was deleted successfully, False otherwise
        """
        logger.info("Deleting gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Remove gesture
        del self.gesture_definitions[gesture_id]
        
        # Remove from active gestures
        self.active_gestures.discard(gesture_id)
        
        # Notify subscribers
        self._notify_subscribers("gesture_deleted", {
            "gesture_id": gesture_id
        })
        
        return True
    
    def get_gesture(self, gesture_id: str) -> Optional[Dict[str, Any]]:
        """
        Get gesture by ID.
        
        Args:
            gesture_id: Gesture identifier
        
        Returns:
            Optional[Dict[str, Any]]: Gesture if found, None otherwise
        """
        if gesture_id in self.gesture_definitions:
            return self.gesture_definitions[gesture_id]
        else:
            logger.warning("Gesture not found: %s", gesture_id)
            return None
    
    def get_all_gestures(self, gesture_type: Optional[str] = None, 
                       modality: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all gestures, optionally filtered by type or modality.
        
        Args:
            gesture_type: Optional gesture type to filter by
            modality: Optional modality to filter by
        
        Returns:
            List[Dict[str, Any]]: List of gestures
        """
        gestures = list(self.gesture_definitions.values())
        
        if gesture_type:
            gestures = [g for g in gestures if g.get("type") == gesture_type]
        
        if modality:
            gestures = [g for g in gestures if modality in g.get("modalities", [])]
        
        return gestures
    
    def get_active_gestures(self, gesture_type: Optional[str] = None, 
                          modality: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get active gestures, optionally filtered by type or modality.
        
        Args:
            gesture_type: Optional gesture type to filter by
            modality: Optional modality to filter by
        
        Returns:
            List[Dict[str, Any]]: List of active gestures
        """
        active_gestures = [self.gesture_definitions[gid] for gid in self.active_gestures 
                         if gid in self.gesture_definitions]
        
        if gesture_type:
            active_gestures = [g for g in active_gestures if g.get("type") == gesture_type]
        
        if modality:
            active_gestures = [g for g in active_gestures if modality in g.get("modalities", [])]
        
        return active_gestures
    
    def enable_gesture(self, gesture_id: str) -> bool:
        """
        Enable a gesture.
        
        Args:
            gesture_id: Gesture identifier
        
        Returns:
            bool: True if gesture was enabled successfully, False otherwise
        """
        logger.info("Enabling gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Update gesture
        self.gesture_definitions[gesture_id]["enabled"] = True
        
        # Add to active gestures
        self.active_gestures.add(gesture_id)
        
        # Notify subscribers
        self._notify_subscribers("gesture_enabled", {
            "gesture_id": gesture_id
        })
        
        return True
    
    def disable_gesture(self, gesture_id: str) -> bool:
        """
        Disable a gesture.
        
        Args:
            gesture_id: Gesture identifier
        
        Returns:
            bool: True if gesture was disabled successfully, False otherwise
        """
        logger.info("Disabling gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Update gesture
        self.gesture_definitions[gesture_id]["enabled"] = False
        
        # Remove from active gestures
        self.active_gestures.discard(gesture_id)
        
        # Notify subscribers
        self._notify_subscribers("gesture_disabled", {
            "gesture_id": gesture_id
        })
        
        return True
    
    def enable_gestures_by_type(self, gesture_type: str) -> int:
        """
        Enable all gestures of a specific type.
        
        Args:
            gesture_type: Gesture type
        
        Returns:
            int: Number of gestures enabled
        """
        logger.info("Enabling gestures of type: %s", gesture_type)
        
        count = 0
        for gesture_id, gesture in self.gesture_definitions.items():
            if gesture.get("type") == gesture_type and not gesture.get("enabled", False):
                gesture["enabled"] = True
                self.active_gestures.add(gesture_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("gestures_enabled_by_type", {
                "gesture_type": gesture_type,
                "count": count
            })
        
        return count
    
    def disable_gestures_by_type(self, gesture_type: str) -> int:
        """
        Disable all gestures of a specific type.
        
        Args:
            gesture_type: Gesture type
        
        Returns:
            int: Number of gestures disabled
        """
        logger.info("Disabling gestures of type: %s", gesture_type)
        
        count = 0
        for gesture_id, gesture in self.gesture_definitions.items():
            if gesture.get("type") == gesture_type and gesture.get("enabled", False):
                gesture["enabled"] = False
                self.active_gestures.discard(gesture_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("gestures_disabled_by_type", {
                "gesture_type": gesture_type,
                "count": count
            })
        
        return count
    
    def enable_gestures_by_modality(self, modality: str) -> int:
        """
        Enable all gestures for a specific modality.
        
        Args:
            modality: Input modality
        
        Returns:
            int: Number of gestures enabled
        """
        logger.info("Enabling gestures for modality: %s", modality)
        
        count = 0
        for gesture_id, gesture in self.gesture_definitions.items():
            if modality in gesture.get("modalities", []) and not gesture.get("enabled", False):
                gesture["enabled"] = True
                self.active_gestures.add(gesture_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("gestures_enabled_by_modality", {
                "modality": modality,
                "count": count
            })
        
        return count
    
    def disable_gestures_by_modality(self, modality: str) -> int:
        """
        Disable all gestures for a specific modality.
        
        Args:
            modality: Input modality
        
        Returns:
            int: Number of gestures disabled
        """
        logger.info("Disabling gestures for modality: %s", modality)
        
        count = 0
        for gesture_id, gesture in self.gesture_definitions.items():
            if modality in gesture.get("modalities", []) and gesture.get("enabled", False):
                gesture["enabled"] = False
                self.active_gestures.discard(gesture_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("gestures_disabled_by_modality", {
                "modality": modality,
                "count": count
            })
        
        return count
    
    def update_gesture_parameters(self, gesture_id: str, parameters: Dict[str, Any]) -> bool:
        """
        Update parameters for a gesture.
        
        Args:
            gesture_id: Gesture identifier
            parameters: Updated parameters
        
        Returns:
            bool: True if parameters were updated successfully, False otherwise
        """
        logger.info("Updating parameters for gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Update parameters
        gesture = self.gesture_definitions[gesture_id]
        
        if "parameters" not in gesture:
            gesture["parameters"] = {}
        
        for key, value in parameters.items():
            gesture["parameters"][key] = value
        
        # Notify subscribers
        self._notify_subscribers("gesture_parameters_updated", {
            "gesture_id": gesture_id,
            "parameters": parameters
        })
        
        return True
    
    def calibrate_gesture(self, gesture_id: str, calibration_data: Dict[str, Any]) -> bool:
        """
        Calibrate a gesture with user-specific data.
        
        Args:
            gesture_id: Gesture identifier
            calibration_data: Calibration data
        
        Returns:
            bool: True if calibration was successful, False otherwise
        """
        logger.info("Calibrating gesture: %s", gesture_id)
        
        if gesture_id not in self.gesture_definitions:
            logger.warning("Gesture not found: %s", gesture_id)
            return False
        
        # Store calibration data
        if gesture_id not in self.calibration_data:
            self.calibration_data[gesture_id] = {}
        
        for key, value in calibration_data.items():
            self.calibration_data[gesture_id][key] = value
        
        # Notify subscribers
        self._notify_subscribers("gesture_calibrated", {
            "gesture_id": gesture_id,
            "calibration_data": calibration_data
        })
        
        return True
    
    def reset_calibration(self, gesture_id: Optional[str] = None) -> bool:
        """
        Reset calibration data for a gesture or all gestures.
        
        Args:
            gesture_id: Optional gesture identifier, if None, reset all calibrations
        
        Returns:
            bool: True if calibration was reset successfully, False otherwise
        """
        logger.info("Resetting calibration for gesture: %s", gesture_id or "all")
        
        if gesture_id:
            if gesture_id not in self.gesture_definitions:
                logger.warning("Gesture not found: %s", gesture_id)
                return False
            
            # Reset calibration for specific gesture
            if gesture_id in self.calibration_data:
                del self.calibration_data[gesture_id]
            
            # Notify subscribers
            self._notify_subscribers("gesture_calibration_reset", {
                "gesture_id": gesture_id
            })
        else:
            # Reset all calibrations
            self.calibration_data = {}
            
            # Notify subscribers
            self._notify_subscribers("all_calibrations_reset", {})
        
        return True
    
    def get_gesture_history(self, limit: Optional[int] = None, 
                          gesture_type: Optional[str] = None,
                          modality: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get gesture recognition history.
        
        Args:
            limit: Optional limit on number of history items to return
            gesture_type: Optional gesture type to filter by
            modality: Optional modality to filter by
        
        Returns:
            List[Dict[str, Any]]: List of gesture history items
        """
        history = self.gesture_history
        
        if gesture_type:
            history = [h for h in history if h.get("gesture_type") == gesture_type]
        
        if modality:
            history = [h for h in history if h.get("modality") == modality]
        
        if limit:
            history = history[-limit:]
        
        return history
    
    def clear_gesture_history(self) -> bool:
        """
        Clear gesture recognition history.
        
        Returns:
            bool: True if history was cleared successfully
        """
        logger.info("Clearing gesture history")
        
        self.gesture_history = []
        
        # Notify subscribers
        self._notify_subscribers("gesture_history_cleared", {})
        
        return True
    
    def process_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Process input data to recognize gestures.
        
        Args:
            input_data: Input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        logger.debug("Processing input: %s", input_data)
        
        # Get input modality
        modality = input_data.get("modality")
        if not modality:
            logger.warning("Missing modality in input data")
            return None
        
        # Get input handler for modality
        if modality not in self.input_handlers:
            logger.warning("No input handler for modality: %s", modality)
            return None
        
        # Process input with handler
        handler = self.input_handlers[modality]
        recognized_gesture = handler(input_data)
        
        if recognized_gesture:
            # Add to history
            history_item = {
                "timestamp": datetime.now().isoformat(),
                "gesture_id": recognized_gesture.get("gesture_id"),
                "gesture_type": recognized_gesture.get("gesture_type"),
                "modality": modality,
                "confidence": recognized_gesture.get("confidence", 1.0),
                "parameters": recognized_gesture.get("parameters", {})
            }
            
            self.gesture_history.append(history_item)
            
            # Limit history size
            max_history = self.config.get("max_history_size", 100)
            if len(self.gesture_history) > max_history:
                self.gesture_history = self.gesture_history[-max_history:]
            
            # Notify subscribers
            self._notify_subscribers("gesture_recognized", recognized_gesture)
            
            return recognized_gesture
        
        return None
    
    def _handle_touch_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle touch input.
        
        Args:
            input_data: Touch input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Get active gestures for touch modality
        active_gestures = self.get_active_gestures(modality=self.MODALITY_TOUCH)
        if not active_gestures:
            return None
        
        # Get touch event type
        event_type = input_data.get("event_type")
        if not event_type:
            return None
        
        # Get touch points
        touches = input_data.get("touches", [])
        if not touches:
            return None
        
        # Process based on event type
        if event_type == "touchstart":
            # Store initial touch data for later processing
            return None
        
        elif event_type == "touchmove":
            # Check for drag, swipe, pinch, rotate gestures
            for gesture in active_gestures:
                gesture_type = gesture.get("type")
                
                if gesture_type == self.TYPE_DRAG:
                    # Check for drag gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        start_pos = touch.get("start_position")
                        current_pos = touch.get("position")
                        
                        if start_pos and current_pos:
                            dx = current_pos[0] - start_pos[0]
                            dy = current_pos[1] - start_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            
                            min_distance = gesture.get("parameters", {}).get("min_distance", 10)
                            
                            if distance >= min_distance:
                                # Determine direction
                                direction = self._determine_direction(dx, dy)
                                
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture_type,
                                    "modality": self.MODALITY_TOUCH,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "direction": direction,
                                        "distance": distance,
                                        "position": current_pos,
                                        "start_position": start_pos
                                    }
                                }
                
                elif gesture_type == self.TYPE_PINCH:
                    # Check for pinch gesture
                    if len(touches) == 2:
                        touch1 = touches[0]
                        touch2 = touches[1]
                        
                        start_pos1 = touch1.get("start_position")
                        start_pos2 = touch2.get("start_position")
                        current_pos1 = touch1.get("position")
                        current_pos2 = touch2.get("position")
                        
                        if start_pos1 and start_pos2 and current_pos1 and current_pos2:
                            # Calculate start and current distances
                            start_dx = start_pos2[0] - start_pos1[0]
                            start_dy = start_pos2[1] - start_pos1[1]
                            start_distance = math.sqrt(start_dx*start_dx + start_dy*start_dy)
                            
                            current_dx = current_pos2[0] - current_pos1[0]
                            current_dy = current_pos2[1] - current_pos1[1]
                            current_distance = math.sqrt(current_dx*current_dx + current_dy*current_dy)
                            
                            # Calculate scale change
                            if start_distance > 0:
                                scale_change = current_distance / start_distance - 1.0
                                
                                min_scale_change = gesture.get("parameters", {}).get("min_scale_change", 0.1)
                                
                                if abs(scale_change) >= min_scale_change:
                                    # Determine direction
                                    direction = self.DIRECTION_IN if scale_change < 0 else self.DIRECTION_OUT
                                    
                                    return {
                                        "gesture_id": gesture.get("id"),
                                        "gesture_type": gesture_type,
                                        "modality": self.MODALITY_TOUCH,
                                        "confidence": 1.0,
                                        "parameters": {
                                            "direction": direction,
                                            "scale_change": scale_change,
                                            "center": [
                                                (current_pos1[0] + current_pos2[0]) / 2,
                                                (current_pos1[1] + current_pos2[1]) / 2
                                            ]
                                        }
                                    }
                
                elif gesture_type == self.TYPE_ROTATE:
                    # Check for rotate gesture
                    if len(touches) == 2:
                        touch1 = touches[0]
                        touch2 = touches[1]
                        
                        start_pos1 = touch1.get("start_position")
                        start_pos2 = touch2.get("start_position")
                        current_pos1 = touch1.get("position")
                        current_pos2 = touch2.get("position")
                        
                        if start_pos1 and start_pos2 and current_pos1 and current_pos2:
                            # Calculate start and current angles
                            start_angle = math.atan2(start_pos2[1] - start_pos1[1], 
                                                   start_pos2[0] - start_pos1[0])
                            current_angle = math.atan2(current_pos2[1] - current_pos1[1], 
                                                     current_pos2[0] - current_pos1[0])
                            
                            # Calculate angle change in degrees
                            angle_change = (current_angle - start_angle) * 180 / math.pi
                            
                            # Normalize to -180 to 180
                            if angle_change > 180:
                                angle_change -= 360
                            elif angle_change < -180:
                                angle_change += 360
                            
                            min_angle = gesture.get("parameters", {}).get("min_angle", 15)
                            
                            if abs(angle_change) >= min_angle:
                                # Determine direction
                                direction = self.DIRECTION_CLOCKWISE if angle_change < 0 else self.DIRECTION_COUNTERCLOCKWISE
                                
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture_type,
                                    "modality": self.MODALITY_TOUCH,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "direction": direction,
                                        "angle_change": angle_change,
                                        "center": [
                                            (current_pos1[0] + current_pos2[0]) / 2,
                                            (current_pos1[1] + current_pos2[1]) / 2
                                        ]
                                    }
                                }
                
                elif gesture_type == self.TYPE_MULTI_TOUCH:
                    # Check for multi-touch gesture
                    min_touches = gesture.get("parameters", {}).get("min_touches", 3)
                    
                    if len(touches) >= min_touches:
                        # Calculate center point
                        center_x = sum(touch.get("position", [0, 0])[0] for touch in touches) / len(touches)
                        center_y = sum(touch.get("position", [0, 0])[1] for touch in touches) / len(touches)
                        
                        return {
                            "gesture_id": gesture.get("id"),
                            "gesture_type": gesture_type,
                            "modality": self.MODALITY_TOUCH,
                            "confidence": 1.0,
                            "parameters": {
                                "touch_count": len(touches),
                                "center": [center_x, center_y]
                            }
                        }
        
        elif event_type == "touchend":
            # Check for tap, double tap, long press, swipe, flick gestures
            for gesture in active_gestures:
                gesture_type = gesture.get("type")
                
                if gesture_type == self.TYPE_TAP:
                    # Check for tap gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        start_pos = touch.get("start_position")
                        end_pos = touch.get("position")
                        start_time = touch.get("start_time")
                        end_time = touch.get("end_time")
                        
                        if start_pos and end_pos and start_time and end_time:
                            dx = end_pos[0] - start_pos[0]
                            dy = end_pos[1] - start_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            duration = end_time - start_time
                            
                            max_duration = gesture.get("parameters", {}).get("max_duration", 300)
                            max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                            
                            if duration <= max_duration and distance <= max_movement:
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture_type,
                                    "modality": self.MODALITY_TOUCH,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "position": end_pos,
                                        "duration": duration
                                    }
                                }
                
                elif gesture_type == self.TYPE_DOUBLE_TAP:
                    # Check for double tap gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        current_time = touch.get("end_time")
                        position = touch.get("position")
                        
                        # Check if there was a recent tap
                        recent_taps = [h for h in self.gesture_history 
                                     if h.get("gesture_type") == self.TYPE_TAP 
                                     and h.get("modality") == self.MODALITY_TOUCH]
                        
                        if recent_taps and position and current_time:
                            last_tap = recent_taps[-1]
                            last_tap_time = datetime.fromisoformat(last_tap.get("timestamp")).timestamp() * 1000
                            last_tap_pos = last_tap.get("parameters", {}).get("position")
                            
                            if last_tap_pos:
                                dx = position[0] - last_tap_pos[0]
                                dy = position[1] - last_tap_pos[1]
                                distance = math.sqrt(dx*dx + dy*dy)
                                interval = current_time - last_tap_time
                                
                                max_interval = gesture.get("parameters", {}).get("max_interval", 500)
                                max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                                
                                if interval <= max_interval and distance <= max_movement:
                                    return {
                                        "gesture_id": gesture.get("id"),
                                        "gesture_type": gesture_type,
                                        "modality": self.MODALITY_TOUCH,
                                        "confidence": 1.0,
                                        "parameters": {
                                            "position": position,
                                            "interval": interval
                                        }
                                    }
                
                elif gesture_type == self.TYPE_LONG_PRESS:
                    # Check for long press gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        start_pos = touch.get("start_position")
                        end_pos = touch.get("position")
                        start_time = touch.get("start_time")
                        end_time = touch.get("end_time")
                        
                        if start_pos and end_pos and start_time and end_time:
                            dx = end_pos[0] - start_pos[0]
                            dy = end_pos[1] - start_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            duration = end_time - start_time
                            
                            min_duration = gesture.get("parameters", {}).get("min_duration", 500)
                            max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                            
                            if duration >= min_duration and distance <= max_movement:
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture_type,
                                    "modality": self.MODALITY_TOUCH,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "position": end_pos,
                                        "duration": duration
                                    }
                                }
                
                elif gesture_type == self.TYPE_SWIPE:
                    # Check for swipe gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        start_pos = touch.get("start_position")
                        end_pos = touch.get("position")
                        start_time = touch.get("start_time")
                        end_time = touch.get("end_time")
                        
                        if start_pos and end_pos and start_time and end_time:
                            dx = end_pos[0] - start_pos[0]
                            dy = end_pos[1] - start_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            duration = end_time - start_time
                            
                            if duration > 0:
                                velocity = distance / duration
                                
                                min_distance = gesture.get("parameters", {}).get("min_distance", 50)
                                max_duration = gesture.get("parameters", {}).get("max_duration", 500)
                                min_velocity = gesture.get("parameters", {}).get("min_velocity", 0.5)
                                
                                if distance >= min_distance and duration <= max_duration and velocity >= min_velocity:
                                    # Determine direction
                                    direction = self._determine_direction(dx, dy)
                                    
                                    return {
                                        "gesture_id": gesture.get("id"),
                                        "gesture_type": gesture_type,
                                        "modality": self.MODALITY_TOUCH,
                                        "confidence": 1.0,
                                        "parameters": {
                                            "direction": direction,
                                            "distance": distance,
                                            "duration": duration,
                                            "velocity": velocity,
                                            "start_position": start_pos,
                                            "end_position": end_pos
                                        }
                                    }
                
                elif gesture_type == self.TYPE_FLICK:
                    # Check for flick gesture
                    if len(touches) == 1:
                        touch = touches[0]
                        start_pos = touch.get("start_position")
                        end_pos = touch.get("position")
                        start_time = touch.get("start_time")
                        end_time = touch.get("end_time")
                        
                        if start_pos and end_pos and start_time and end_time:
                            dx = end_pos[0] - start_pos[0]
                            dy = end_pos[1] - start_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            duration = end_time - start_time
                            
                            if duration > 0:
                                velocity = distance / duration
                                
                                min_velocity = gesture.get("parameters", {}).get("min_velocity", 1.0)
                                max_duration = gesture.get("parameters", {}).get("max_duration", 300)
                                
                                if velocity >= min_velocity and duration <= max_duration:
                                    # Determine direction
                                    direction = self._determine_direction(dx, dy)
                                    
                                    return {
                                        "gesture_id": gesture.get("id"),
                                        "gesture_type": gesture_type,
                                        "modality": self.MODALITY_TOUCH,
                                        "confidence": 1.0,
                                        "parameters": {
                                            "direction": direction,
                                            "distance": distance,
                                            "duration": duration,
                                            "velocity": velocity,
                                            "start_position": start_pos,
                                            "end_position": end_pos
                                        }
                                    }
        
        return None
    
    def _handle_mouse_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle mouse input.
        
        Args:
            input_data: Mouse input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Get active gestures for mouse modality
        active_gestures = self.get_active_gestures(modality=self.MODALITY_MOUSE)
        if not active_gestures:
            return None
        
        # Get mouse event type
        event_type = input_data.get("event_type")
        if not event_type:
            return None
        
        # Get mouse position and button
        position = input_data.get("position")
        button = input_data.get("button")
        
        if not position:
            return None
        
        # Process based on event type
        if event_type == "mousemove":
            # Check for hover gesture
            if not input_data.get("buttons"):  # No buttons pressed
                for gesture in active_gestures:
                    if gesture.get("type") == self.TYPE_HOVER:
                        # Check if position has been stable
                        hover_start = input_data.get("hover_start")
                        hover_positions = input_data.get("hover_positions", [])
                        
                        if hover_start and hover_positions:
                            current_time = time.time() * 1000
                            duration = current_time - hover_start
                            
                            # Calculate max movement
                            max_movement = 0
                            if len(hover_positions) > 1:
                                for i in range(1, len(hover_positions)):
                                    dx = hover_positions[i][0] - hover_positions[i-1][0]
                                    dy = hover_positions[i][1] - hover_positions[i-1][1]
                                    movement = math.sqrt(dx*dx + dy*dy)
                                    max_movement = max(max_movement, movement)
                            
                            min_duration = gesture.get("parameters", {}).get("min_duration", 300)
                            max_allowed_movement = gesture.get("parameters", {}).get("max_movement", 15)
                            
                            if duration >= min_duration and max_movement <= max_allowed_movement:
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture.get("type"),
                                    "modality": self.MODALITY_MOUSE,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "position": position,
                                        "duration": duration
                                    }
                                }
            
            # Check for drag gesture
            elif input_data.get("buttons"):  # Buttons pressed
                for gesture in active_gestures:
                    if gesture.get("type") == self.TYPE_DRAG:
                        drag_start = input_data.get("drag_start_position")
                        
                        if drag_start:
                            dx = position[0] - drag_start[0]
                            dy = position[1] - drag_start[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            
                            min_distance = gesture.get("parameters", {}).get("min_distance", 10)
                            
                            if distance >= min_distance:
                                # Determine direction
                                direction = self._determine_direction(dx, dy)
                                
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture.get("type"),
                                    "modality": self.MODALITY_MOUSE,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "direction": direction,
                                        "distance": distance,
                                        "position": position,
                                        "start_position": drag_start,
                                        "button": button
                                    }
                                }
        
        elif event_type == "mousedown":
            # Store start position for potential gestures
            return None
        
        elif event_type == "mouseup":
            # Check for click, double click gestures
            for gesture in active_gestures:
                gesture_type = gesture.get("type")
                
                if gesture_type == self.TYPE_TAP:
                    # Check for click gesture
                    click_start = input_data.get("click_start_position")
                    click_start_time = input_data.get("click_start_time")
                    
                    if click_start and click_start_time:
                        dx = position[0] - click_start[0]
                        dy = position[1] - click_start[1]
                        distance = math.sqrt(dx*dx + dy*dy)
                        duration = time.time() * 1000 - click_start_time
                        
                        max_duration = gesture.get("parameters", {}).get("max_duration", 300)
                        max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                        
                        if duration <= max_duration and distance <= max_movement:
                            return {
                                "gesture_id": gesture.get("id"),
                                "gesture_type": gesture_type,
                                "modality": self.MODALITY_MOUSE,
                                "confidence": 1.0,
                                "parameters": {
                                    "position": position,
                                    "duration": duration,
                                    "button": button
                                }
                            }
                
                elif gesture_type == self.TYPE_DOUBLE_TAP:
                    # Check for double click gesture
                    current_time = time.time() * 1000
                    
                    # Check if there was a recent click
                    recent_clicks = [h for h in self.gesture_history 
                                   if h.get("gesture_type") == self.TYPE_TAP 
                                   and h.get("modality") == self.MODALITY_MOUSE]
                    
                    if recent_clicks:
                        last_click = recent_clicks[-1]
                        last_click_time = datetime.fromisoformat(last_click.get("timestamp")).timestamp() * 1000
                        last_click_pos = last_click.get("parameters", {}).get("position")
                        
                        if last_click_pos:
                            dx = position[0] - last_click_pos[0]
                            dy = position[1] - last_click_pos[1]
                            distance = math.sqrt(dx*dx + dy*dy)
                            interval = current_time - last_click_time
                            
                            max_interval = gesture.get("parameters", {}).get("max_interval", 500)
                            max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                            
                            if interval <= max_interval and distance <= max_movement:
                                return {
                                    "gesture_id": gesture.get("id"),
                                    "gesture_type": gesture_type,
                                    "modality": self.MODALITY_MOUSE,
                                    "confidence": 1.0,
                                    "parameters": {
                                        "position": position,
                                        "interval": interval,
                                        "button": button
                                    }
                                }
                
                elif gesture_type == self.TYPE_LONG_PRESS:
                    # Check for long press gesture
                    click_start = input_data.get("click_start_position")
                    click_start_time = input_data.get("click_start_time")
                    
                    if click_start and click_start_time:
                        dx = position[0] - click_start[0]
                        dy = position[1] - click_start[1]
                        distance = math.sqrt(dx*dx + dy*dy)
                        duration = time.time() * 1000 - click_start_time
                        
                        min_duration = gesture.get("parameters", {}).get("min_duration", 500)
                        max_movement = gesture.get("parameters", {}).get("max_movement", 10)
                        
                        if duration >= min_duration and distance <= max_movement:
                            return {
                                "gesture_id": gesture.get("id"),
                                "gesture_type": gesture_type,
                                "modality": self.MODALITY_MOUSE,
                                "confidence": 1.0,
                                "parameters": {
                                    "position": position,
                                    "duration": duration,
                                    "button": button
                                }
                            }
        
        elif event_type == "wheel":
            # Handle wheel events
            # TODO: Implement wheel gesture recognition
            pass
        
        return None
    
    def _handle_pen_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle pen input.
        
        Args:
            input_data: Pen input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Similar to mouse input handling, but with pen-specific parameters
        # TODO: Implement pen gesture recognition
        return None
    
    def _handle_camera_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle camera input.
        
        Args:
            input_data: Camera input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Get active gestures for camera modality
        active_gestures = self.get_active_gestures(modality=self.MODALITY_CAMERA)
        if not active_gestures:
            return None
        
        # Get hand pose data
        hand_poses = input_data.get("hand_poses", [])
        if not hand_poses:
            return None
        
        # Process hand poses
        for gesture in active_gestures:
            gesture_type = gesture.get("type")
            
            if gesture_type == self.TYPE_HAND_POSE:
                # Check for hand pose gesture
                target_pose = gesture.get("parameters", {}).get("pose")
                min_confidence = gesture.get("parameters", {}).get("min_confidence", 0.7)
                
                for pose in hand_poses:
                    pose_type = pose.get("pose")
                    confidence = pose.get("confidence", 0)
                    
                    if pose_type == target_pose and confidence >= min_confidence:
                        return {
                            "gesture_id": gesture.get("id"),
                            "gesture_type": gesture_type,
                            "modality": self.MODALITY_CAMERA,
                            "confidence": confidence,
                            "parameters": {
                                "pose": pose_type,
                                "hand": pose.get("hand", "right"),
                                "position": pose.get("position")
                            }
                        }
        
        return None
    
    def _handle_leap_motion_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle Leap Motion input.
        
        Args:
            input_data: Leap Motion input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Similar to camera input handling, but with Leap Motion specific data
        # TODO: Implement Leap Motion gesture recognition
        return None
    
    def _handle_vr_controller_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle VR controller input.
        
        Args:
            input_data: VR controller input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # TODO: Implement VR controller gesture recognition
        return None
    
    def _handle_ar_glasses_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle AR glasses input.
        
        Args:
            input_data: AR glasses input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # TODO: Implement AR glasses gesture recognition
        return None
    
    def _handle_gaze_tracker_input(self, input_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Handle gaze tracker input.
        
        Args:
            input_data: Gaze tracker input data
        
        Returns:
            Optional[Dict[str, Any]]: Recognized gesture if any, None otherwise
        """
        # Get active gestures for gaze tracker modality
        active_gestures = self.get_active_gestures(modality=self.MODALITY_GAZE_TRACKER)
        if not active_gestures:
            return None
        
        # Get gaze data
        gaze_position = input_data.get("gaze_position")
        if not gaze_position:
            return None
        
        # Process gaze data
        for gesture in active_gestures:
            gesture_type = gesture.get("type")
            
            if gesture_type == self.TYPE_GAZE:
                # Check for gaze dwell gesture
                dwell_start = input_data.get("dwell_start")
                dwell_positions = input_data.get("dwell_positions", [])
                
                if dwell_start and dwell_positions:
                    current_time = time.time() * 1000
                    duration = current_time - dwell_start
                    
                    # Calculate max movement
                    max_movement = 0
                    if len(dwell_positions) > 1:
                        for i in range(1, len(dwell_positions)):
                            dx = dwell_positions[i][0] - dwell_positions[i-1][0]
                            dy = dwell_positions[i][1] - dwell_positions[i-1][1]
                            movement = math.sqrt(dx*dx + dy*dy)
                            max_movement = max(max_movement, movement)
                    
                    min_duration = gesture.get("parameters", {}).get("min_duration", 800)
                    max_allowed_movement = gesture.get("parameters", {}).get("max_movement", 20)
                    
                    if duration >= min_duration and max_movement <= max_allowed_movement:
                        return {
                            "gesture_id": gesture.get("id"),
                            "gesture_type": gesture_type,
                            "modality": self.MODALITY_GAZE_TRACKER,
                            "confidence": 1.0,
                            "parameters": {
                                "position": gaze_position,
                                "duration": duration
                            }
                        }
        
        return None
    
    def _determine_direction(self, dx: float, dy: float) -> str:
        """
        Determine direction based on delta x and delta y.
        
        Args:
            dx: Delta x
            dy: Delta y
        
        Returns:
            str: Direction constant
        """
        # Calculate angle in degrees
        angle = math.atan2(dy, dx) * 180 / math.pi
        
        # Determine direction based on angle
        if -45 <= angle <= 45:
            return self.DIRECTION_RIGHT
        elif 45 < angle <= 135:
            return self.DIRECTION_DOWN
        elif -135 <= angle < -45:
            return self.DIRECTION_UP
        else:
            return self.DIRECTION_LEFT
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Adjust gesture recognition based on context
        if context_type == "user_context":
            # Adjust for user preferences
            user_id = context_data.get("user_id")
            if user_id and user_id in self.calibration_data:
                logger.info("Applying user calibration for user: %s", user_id)
                # Apply user calibration
        
        elif context_type == "application_context":
            # Adjust for application needs
            app_id = context_data.get("app_id")
            if app_id:
                logger.info("Adjusting gestures for application: %s", app_id)
                # Enable/disable gestures based on application needs
        
        elif context_type == "task_context":
            # Adjust for current task
            task_type = context_data.get("task_type")
            if task_type:
                logger.info("Adjusting gestures for task: %s", task_type)
                # Enable/disable gestures based on task requirements
    
    def _on_device_changed(self, event_data: Dict[str, Any]):
        """
        Handle device changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Device changed: %s", event_data)
        
        device_type = event_data.get("device_type")
        device_capabilities = event_data.get("capabilities", {})
        
        # Adjust available gestures based on device capabilities
        if device_type:
            logger.info("Adjusting gestures for device: %s", device_type)
            
            # Enable/disable modalities based on device capabilities
            for modality in [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN, 
                           self.MODALITY_CAMERA, self.MODALITY_LEAP_MOTION, 
                           self.MODALITY_VR_CONTROLLER, self.MODALITY_AR_GLASSES, 
                           self.MODALITY_GAZE_TRACKER]:
                
                if modality in device_capabilities:
                    self.enable_gestures_by_modality(modality)
                else:
                    self.disable_gestures_by_modality(modality)
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        # Process input for gesture recognition
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        if input_type == "touch":
            modality = self.MODALITY_TOUCH
        elif input_type == "mouse":
            modality = self.MODALITY_MOUSE
        elif input_type == "pen":
            modality = self.MODALITY_PEN
        elif input_type == "camera":
            modality = self.MODALITY_CAMERA
        elif input_type == "leap_motion":
            modality = self.MODALITY_LEAP_MOTION
        elif input_type == "vr_controller":
            modality = self.MODALITY_VR_CONTROLLER
        elif input_type == "ar_glasses":
            modality = self.MODALITY_AR_GLASSES
        elif input_type == "gaze_tracker":
            modality = self.MODALITY_GAZE_TRACKER
        else:
            return
        
        # Add modality to input data
        input_data["modality"] = modality
        
        # Process input
        self.process_input(input_data)
    
    def _on_capabilities_changed(self, event_data: Dict[str, Any]):
        """
        Handle capabilities changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capabilities changed: %s", event_data)
        
        capabilities = event_data.get("capabilities", {})
        
        # Adjust available gestures based on capabilities
        for modality in [self.MODALITY_TOUCH, self.MODALITY_MOUSE, self.MODALITY_PEN, 
                       self.MODALITY_CAMERA, self.MODALITY_LEAP_MOTION, 
                       self.MODALITY_VR_CONTROLLER, self.MODALITY_AR_GLASSES, 
                       self.MODALITY_GAZE_TRACKER]:
            
            if modality in capabilities and capabilities[modality]:
                self.enable_gestures_by_modality(modality)
            else:
                self.disable_gestures_by_modality(modality)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Gesture Recognition events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Gesture Recognition events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
