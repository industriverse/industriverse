"""
Context Panel Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Context Panel, which provides contextual information
and controls based on the current user focus, active agents, and system state.
The panel adapts its content dynamically to provide the most relevant information
and actions for the current context.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union
import json
import os
import time
import math
import re
import uuid

# Initialize logger
logger = logging.getLogger(__name__)

class ContextPanel:
    """
    Context Panel component for providing contextual information and controls
    based on the current user focus, active agents, and system state.
    """
    
    # Context type constants
    CONTEXT_AGENT = "agent"
    CONTEXT_WORKFLOW = "workflow"
    CONTEXT_TASK = "task"
    CONTEXT_RESOURCE = "resource"
    CONTEXT_ALERT = "alert"
    CONTEXT_SYSTEM = "system"
    CONTEXT_USER = "user"
    
    # Panel section constants
    SECTION_HEADER = "header"
    SECTION_SUMMARY = "summary"
    SECTION_DETAILS = "details"
    SECTION_ACTIONS = "actions"
    SECTION_RELATED = "related"
    SECTION_HISTORY = "history"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Context Panel component with optional configuration."""
        self.config = config or {}
        self.current_context = None
        self.context_history = []
        self.panel_sections = {}
        self.panel_visibility = True
        self.panel_size = "medium"  # small, medium, large
        self.panel_position = "right"  # left, right, top, bottom
        self.panel_theme = "default"
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.capsule_manager = None
        self.avatar_manager = None
        self.rendering_engine = None
        
        # Initialize panel sections
        self._initialize_panel_sections()
        
        logger.info("Context Panel component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  capsule_manager=None, avatar_manager=None, rendering_engine=None):
        """Initialize the Context Panel component and connect to required services."""
        logger.info("Initializing Context Panel component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.capsule_manager = capsule_manager
        self.avatar_manager = avatar_manager
        self.rendering_engine = rendering_engine
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
            self.context_engine.subscribe_to_events("focus_changed", self._on_focus_changed)
        
        if self.capsule_manager:
            self.capsule_manager.subscribe_to_events("capsule_activated", self._on_capsule_activated)
            self.capsule_manager.subscribe_to_events("capsule_deactivated", self._on_capsule_deactivated)
        
        if self.avatar_manager:
            self.avatar_manager.subscribe_to_events("avatar_state_changed", self._on_avatar_state_changed)
            self.avatar_manager.subscribe_to_events("avatar_message_added", self._on_avatar_message_added)
        
        logger.info("Context Panel component initialization complete")
        return True
    
    def _initialize_panel_sections(self):
        """Initialize panel sections with default content."""
        logger.info("Initializing panel sections")
        
        # Initialize each section with empty content
        self.panel_sections = {
            self.SECTION_HEADER: {
                "visible": True,
                "content": {},
                "order": 0
            },
            self.SECTION_SUMMARY: {
                "visible": True,
                "content": {},
                "order": 1
            },
            self.SECTION_DETAILS: {
                "visible": True,
                "content": {},
                "order": 2
            },
            self.SECTION_ACTIONS: {
                "visible": True,
                "content": {},
                "order": 3
            },
            self.SECTION_RELATED: {
                "visible": True,
                "content": {},
                "order": 4
            },
            self.SECTION_HISTORY: {
                "visible": True,
                "content": {},
                "order": 5
            }
        }
    
    def set_context(self, context_type: str, context_data: Dict[str, Any]) -> bool:
        """
        Set the current context for the panel.
        
        Args:
            context_type: Type of context (agent, workflow, task, etc.)
            context_data: Context data
        
        Returns:
            bool: True if context was set successfully, False otherwise
        """
        logger.info("Setting context: %s", context_type)
        
        valid_context_types = [
            self.CONTEXT_AGENT,
            self.CONTEXT_WORKFLOW,
            self.CONTEXT_TASK,
            self.CONTEXT_RESOURCE,
            self.CONTEXT_ALERT,
            self.CONTEXT_SYSTEM,
            self.CONTEXT_USER
        ]
        
        if context_type not in valid_context_types:
            logger.warning("Invalid context type: %s", context_type)
            return False
        
        # Store previous context in history
        if self.current_context:
            self.context_history.append(self.current_context)
            
            # Limit history size
            max_history = 20
            if len(self.context_history) > max_history:
                self.context_history = self.context_history[-max_history:]
        
        # Set new context
        self.current_context = {
            "type": context_type,
            "data": context_data,
            "timestamp": time.time()
        }
        
        # Update panel sections based on new context
        self._update_panel_for_context(context_type, context_data)
        
        # Notify subscribers
        self._notify_subscribers("context_changed", {
            "context_type": context_type,
            "context_data": context_data
        })
        
        return True
    
    def get_current_context(self) -> Optional[Dict[str, Any]]:
        """
        Get the current context.
        
        Returns:
            Optional[Dict[str, Any]]: Current context if set, None otherwise
        """
        return self.current_context
    
    def get_context_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get context history.
        
        Args:
            limit: Maximum number of history items to return
        
        Returns:
            List[Dict[str, Any]]: List of recent contexts
        """
        return self.context_history[-limit:]
    
    def set_panel_visibility(self, visible: bool) -> bool:
        """
        Set panel visibility.
        
        Args:
            visible: Whether panel should be visible
        
        Returns:
            bool: True if visibility was set successfully, False otherwise
        """
        logger.info("Setting panel visibility: %s", visible)
        
        self.panel_visibility = visible
        
        # Notify subscribers
        self._notify_subscribers("visibility_changed", {
            "visible": visible
        })
        
        return True
    
    def get_panel_visibility(self) -> bool:
        """
        Get panel visibility.
        
        Returns:
            bool: Whether panel is visible
        """
        return self.panel_visibility
    
    def set_panel_size(self, size: str) -> bool:
        """
        Set panel size.
        
        Args:
            size: Panel size (small, medium, large)
        
        Returns:
            bool: True if size was set successfully, False otherwise
        """
        logger.info("Setting panel size: %s", size)
        
        valid_sizes = ["small", "medium", "large"]
        
        if size not in valid_sizes:
            logger.warning("Invalid panel size: %s", size)
            return False
        
        self.panel_size = size
        
        # Notify subscribers
        self._notify_subscribers("size_changed", {
            "size": size
        })
        
        return True
    
    def get_panel_size(self) -> str:
        """
        Get panel size.
        
        Returns:
            str: Panel size
        """
        return self.panel_size
    
    def set_panel_position(self, position: str) -> bool:
        """
        Set panel position.
        
        Args:
            position: Panel position (left, right, top, bottom)
        
        Returns:
            bool: True if position was set successfully, False otherwise
        """
        logger.info("Setting panel position: %s", position)
        
        valid_positions = ["left", "right", "top", "bottom"]
        
        if position not in valid_positions:
            logger.warning("Invalid panel position: %s", position)
            return False
        
        self.panel_position = position
        
        # Notify subscribers
        self._notify_subscribers("position_changed", {
            "position": position
        })
        
        return True
    
    def get_panel_position(self) -> str:
        """
        Get panel position.
        
        Returns:
            str: Panel position
        """
        return self.panel_position
    
    def set_panel_theme(self, theme: str) -> bool:
        """
        Set panel theme.
        
        Args:
            theme: Panel theme
        
        Returns:
            bool: True if theme was set successfully, False otherwise
        """
        logger.info("Setting panel theme: %s", theme)
        
        self.panel_theme = theme
        
        # Notify subscribers
        self._notify_subscribers("theme_changed", {
            "theme": theme
        })
        
        return True
    
    def get_panel_theme(self) -> str:
        """
        Get panel theme.
        
        Returns:
            str: Panel theme
        """
        return self.panel_theme
    
    def set_section_visibility(self, section: str, visible: bool) -> bool:
        """
        Set visibility of a panel section.
        
        Args:
            section: Section identifier
            visible: Whether section should be visible
        
        Returns:
            bool: True if visibility was set successfully, False otherwise
        """
        logger.info("Setting section visibility: %s -> %s", section, visible)
        
        if section not in self.panel_sections:
            logger.warning("Invalid panel section: %s", section)
            return False
        
        self.panel_sections[section]["visible"] = visible
        
        # Notify subscribers
        self._notify_subscribers("section_visibility_changed", {
            "section": section,
            "visible": visible
        })
        
        return True
    
    def get_section_visibility(self, section: str) -> Optional[bool]:
        """
        Get visibility of a panel section.
        
        Args:
            section: Section identifier
        
        Returns:
            Optional[bool]: Whether section is visible if found, None otherwise
        """
        if section not in self.panel_sections:
            logger.warning("Invalid panel section: %s", section)
            return None
        
        return self.panel_sections[section]["visible"]
    
    def update_section_content(self, section: str, content: Dict[str, Any]) -> bool:
        """
        Update content of a panel section.
        
        Args:
            section: Section identifier
            content: Section content
        
        Returns:
            bool: True if content was updated successfully, False otherwise
        """
        logger.info("Updating section content: %s", section)
        
        if section not in self.panel_sections:
            logger.warning("Invalid panel section: %s", section)
            return False
        
        self.panel_sections[section]["content"] = content
        
        # Notify subscribers
        self._notify_subscribers("section_content_updated", {
            "section": section,
            "content": content
        })
        
        return True
    
    def get_section_content(self, section: str) -> Optional[Dict[str, Any]]:
        """
        Get content of a panel section.
        
        Args:
            section: Section identifier
        
        Returns:
            Optional[Dict[str, Any]]: Section content if found, None otherwise
        """
        if section not in self.panel_sections:
            logger.warning("Invalid panel section: %s", section)
            return None
        
        return self.panel_sections[section]["content"]
    
    def get_all_sections(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all panel sections.
        
        Returns:
            Dict[str, Dict[str, Any]]: Dictionary of all panel sections
        """
        return self.panel_sections
    
    def _update_panel_for_context(self, context_type: str, context_data: Dict[str, Any]):
        """
        Update panel sections based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        """
        logger.info("Updating panel for context: %s", context_type)
        
        # Update header section
        header_content = self._generate_header_content(context_type, context_data)
        self.update_section_content(self.SECTION_HEADER, header_content)
        
        # Update summary section
        summary_content = self._generate_summary_content(context_type, context_data)
        self.update_section_content(self.SECTION_SUMMARY, summary_content)
        
        # Update details section
        details_content = self._generate_details_content(context_type, context_data)
        self.update_section_content(self.SECTION_DETAILS, details_content)
        
        # Update actions section
        actions_content = self._generate_actions_content(context_type, context_data)
        self.update_section_content(self.SECTION_ACTIONS, actions_content)
        
        # Update related section
        related_content = self._generate_related_content(context_type, context_data)
        self.update_section_content(self.SECTION_RELATED, related_content)
        
        # Update history section
        history_content = self._generate_history_content(context_type, context_data)
        self.update_section_content(self.SECTION_HISTORY, history_content)
    
    def _generate_header_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate header content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: Header content
        """
        header_content = {
            "title": "",
            "subtitle": "",
            "icon": "",
            "color": "",
            "actions": []
        }
        
        if context_type == self.CONTEXT_AGENT:
            agent_id = context_data.get("id", "Unknown Agent")
            agent_name = context_data.get("name", agent_id)
            agent_type = context_data.get("type", "Unknown Type")
            
            header_content["title"] = agent_name
            header_content["subtitle"] = f"Agent • {agent_type}"
            header_content["icon"] = "agent_icon"
            header_content["color"] = "#4CAF50"  # Green
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_WORKFLOW:
            workflow_id = context_data.get("id", "Unknown Workflow")
            workflow_name = context_data.get("name", workflow_id)
            workflow_status = context_data.get("status", "Unknown Status")
            
            header_content["title"] = workflow_name
            header_content["subtitle"] = f"Workflow • {workflow_status}"
            header_content["icon"] = "workflow_icon"
            header_content["color"] = "#2196F3"  # Blue
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_TASK:
            task_id = context_data.get("id", "Unknown Task")
            task_name = context_data.get("name", task_id)
            task_status = context_data.get("status", "Unknown Status")
            
            header_content["title"] = task_name
            header_content["subtitle"] = f"Task • {task_status}"
            header_content["icon"] = "task_icon"
            header_content["color"] = "#FF9800"  # Orange
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_RESOURCE:
            resource_id = context_data.get("id", "Unknown Resource")
            resource_name = context_data.get("name", resource_id)
            resource_type = context_data.get("type", "Unknown Type")
            
            header_content["title"] = resource_name
            header_content["subtitle"] = f"Resource • {resource_type}"
            header_content["icon"] = "resource_icon"
            header_content["color"] = "#9C27B0"  # Purple
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_ALERT:
            alert_id = context_data.get("id", "Unknown Alert")
            alert_name = context_data.get("name", alert_id)
            alert_severity = context_data.get("severity", "Unknown Severity")
            
            header_content["title"] = alert_name
            header_content["subtitle"] = f"Alert • {alert_severity}"
            header_content["icon"] = "alert_icon"
            header_content["color"] = "#F44336"  # Red
            header_content["actions"] = [
                {"id": "acknowledge", "label": "Acknowledge", "icon": "acknowledge_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_SYSTEM:
            system_id = context_data.get("id", "System")
            system_name = context_data.get("name", system_id)
            system_status = context_data.get("status", "Unknown Status")
            
            header_content["title"] = system_name
            header_content["subtitle"] = f"System • {system_status}"
            header_content["icon"] = "system_icon"
            header_content["color"] = "#607D8B"  # Blue Grey
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        elif context_type == self.CONTEXT_USER:
            user_id = context_data.get("id", "Unknown User")
            user_name = context_data.get("name", user_id)
            user_role = context_data.get("role", "Unknown Role")
            
            header_content["title"] = user_name
            header_content["subtitle"] = f"User • {user_role}"
            header_content["icon"] = "user_icon"
            header_content["color"] = "#00BCD4"  # Cyan
            header_content["actions"] = [
                {"id": "pin", "label": "Pin", "icon": "pin_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "close", "label": "Close", "icon": "close_icon"}
            ]
        
        return header_content
    
    def _generate_summary_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate summary content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: Summary content
        """
        summary_content = {
            "items": []
        }
        
        if context_type == self.CONTEXT_AGENT:
            # Add agent summary items
            agent_status = context_data.get("status", "Unknown")
            agent_trust = context_data.get("trust_score", 0.0)
            agent_layer = context_data.get("layer", "Unknown")
            agent_created = context_data.get("created_at", 0)
            
            summary_content["items"] = [
                {"label": "Status", "value": agent_status, "icon": "status_icon"},
                {"label": "Trust Score", "value": f"{agent_trust:.2f}", "icon": "trust_icon"},
                {"label": "Layer", "value": agent_layer, "icon": "layer_icon"},
                {"label": "Created", "value": self._format_timestamp(agent_created), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_WORKFLOW:
            # Add workflow summary items
            workflow_status = context_data.get("status", "Unknown")
            workflow_progress = context_data.get("progress", 0)
            workflow_owner = context_data.get("owner", "Unknown")
            workflow_created = context_data.get("created_at", 0)
            
            summary_content["items"] = [
                {"label": "Status", "value": workflow_status, "icon": "status_icon"},
                {"label": "Progress", "value": f"{workflow_progress}%", "icon": "progress_icon"},
                {"label": "Owner", "value": workflow_owner, "icon": "owner_icon"},
                {"label": "Created", "value": self._format_timestamp(workflow_created), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_TASK:
            # Add task summary items
            task_status = context_data.get("status", "Unknown")
            task_priority = context_data.get("priority", "Unknown")
            task_assignee = context_data.get("assignee", "Unknown")
            task_due = context_data.get("due_at", 0)
            
            summary_content["items"] = [
                {"label": "Status", "value": task_status, "icon": "status_icon"},
                {"label": "Priority", "value": task_priority, "icon": "priority_icon"},
                {"label": "Assignee", "value": task_assignee, "icon": "assignee_icon"},
                {"label": "Due", "value": self._format_timestamp(task_due), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_RESOURCE:
            # Add resource summary items
            resource_type = context_data.get("type", "Unknown")
            resource_status = context_data.get("status", "Unknown")
            resource_owner = context_data.get("owner", "Unknown")
            resource_created = context_data.get("created_at", 0)
            
            summary_content["items"] = [
                {"label": "Type", "value": resource_type, "icon": "type_icon"},
                {"label": "Status", "value": resource_status, "icon": "status_icon"},
                {"label": "Owner", "value": resource_owner, "icon": "owner_icon"},
                {"label": "Created", "value": self._format_timestamp(resource_created), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_ALERT:
            # Add alert summary items
            alert_severity = context_data.get("severity", "Unknown")
            alert_source = context_data.get("source", "Unknown")
            alert_category = context_data.get("category", "Unknown")
            alert_time = context_data.get("timestamp", 0)
            
            summary_content["items"] = [
                {"label": "Severity", "value": alert_severity, "icon": "severity_icon"},
                {"label": "Source", "value": alert_source, "icon": "source_icon"},
                {"label": "Category", "value": alert_category, "icon": "category_icon"},
                {"label": "Time", "value": self._format_timestamp(alert_time), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_SYSTEM:
            # Add system summary items
            system_status = context_data.get("status", "Unknown")
            system_version = context_data.get("version", "Unknown")
            system_uptime = context_data.get("uptime", 0)
            system_last_updated = context_data.get("last_updated", 0)
            
            summary_content["items"] = [
                {"label": "Status", "value": system_status, "icon": "status_icon"},
                {"label": "Version", "value": system_version, "icon": "version_icon"},
                {"label": "Uptime", "value": self._format_duration(system_uptime), "icon": "uptime_icon"},
                {"label": "Last Updated", "value": self._format_timestamp(system_last_updated), "icon": "time_icon"}
            ]
        
        elif context_type == self.CONTEXT_USER:
            # Add user summary items
            user_role = context_data.get("role", "Unknown")
            user_status = context_data.get("status", "Unknown")
            user_last_active = context_data.get("last_active", 0)
            user_joined = context_data.get("joined_at", 0)
            
            summary_content["items"] = [
                {"label": "Role", "value": user_role, "icon": "role_icon"},
                {"label": "Status", "value": user_status, "icon": "status_icon"},
                {"label": "Last Active", "value": self._format_timestamp(user_last_active), "icon": "active_icon"},
                {"label": "Joined", "value": self._format_timestamp(user_joined), "icon": "time_icon"}
            ]
        
        return summary_content
    
    def _generate_details_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate details content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: Details content
        """
        details_content = {
            "sections": []
        }
        
        if context_type == self.CONTEXT_AGENT:
            # Add agent details sections
            agent_description = context_data.get("description", "No description available.")
            agent_capabilities = context_data.get("capabilities", [])
            agent_protocols = context_data.get("protocols", [])
            agent_metrics = context_data.get("metrics", {})
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": agent_description,
                    "type": "text"
                },
                {
                    "title": "Capabilities",
                    "content": agent_capabilities,
                    "type": "list"
                },
                {
                    "title": "Protocols",
                    "content": agent_protocols,
                    "type": "list"
                },
                {
                    "title": "Metrics",
                    "content": agent_metrics,
                    "type": "metrics"
                }
            ]
        
        elif context_type == self.CONTEXT_WORKFLOW:
            # Add workflow details sections
            workflow_description = context_data.get("description", "No description available.")
            workflow_steps = context_data.get("steps", [])
            workflow_inputs = context_data.get("inputs", {})
            workflow_outputs = context_data.get("outputs", {})
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": workflow_description,
                    "type": "text"
                },
                {
                    "title": "Steps",
                    "content": workflow_steps,
                    "type": "steps"
                },
                {
                    "title": "Inputs",
                    "content": workflow_inputs,
                    "type": "key_value"
                },
                {
                    "title": "Outputs",
                    "content": workflow_outputs,
                    "type": "key_value"
                }
            ]
        
        elif context_type == self.CONTEXT_TASK:
            # Add task details sections
            task_description = context_data.get("description", "No description available.")
            task_subtasks = context_data.get("subtasks", [])
            task_dependencies = context_data.get("dependencies", [])
            task_comments = context_data.get("comments", [])
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": task_description,
                    "type": "text"
                },
                {
                    "title": "Subtasks",
                    "content": task_subtasks,
                    "type": "tasks"
                },
                {
                    "title": "Dependencies",
                    "content": task_dependencies,
                    "type": "list"
                },
                {
                    "title": "Comments",
                    "content": task_comments,
                    "type": "comments"
                }
            ]
        
        elif context_type == self.CONTEXT_RESOURCE:
            # Add resource details sections
            resource_description = context_data.get("description", "No description available.")
            resource_metadata = context_data.get("metadata", {})
            resource_permissions = context_data.get("permissions", [])
            resource_history = context_data.get("history", [])
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": resource_description,
                    "type": "text"
                },
                {
                    "title": "Metadata",
                    "content": resource_metadata,
                    "type": "key_value"
                },
                {
                    "title": "Permissions",
                    "content": resource_permissions,
                    "type": "permissions"
                },
                {
                    "title": "History",
                    "content": resource_history,
                    "type": "history"
                }
            ]
        
        elif context_type == self.CONTEXT_ALERT:
            # Add alert details sections
            alert_description = context_data.get("description", "No description available.")
            alert_details = context_data.get("details", {})
            alert_impact = context_data.get("impact", "Unknown impact.")
            alert_recommendations = context_data.get("recommendations", [])
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": alert_description,
                    "type": "text"
                },
                {
                    "title": "Details",
                    "content": alert_details,
                    "type": "key_value"
                },
                {
                    "title": "Impact",
                    "content": alert_impact,
                    "type": "text"
                },
                {
                    "title": "Recommendations",
                    "content": alert_recommendations,
                    "type": "list"
                }
            ]
        
        elif context_type == self.CONTEXT_SYSTEM:
            # Add system details sections
            system_description = context_data.get("description", "No description available.")
            system_components = context_data.get("components", [])
            system_metrics = context_data.get("metrics", {})
            system_logs = context_data.get("logs", [])
            
            details_content["sections"] = [
                {
                    "title": "Description",
                    "content": system_description,
                    "type": "text"
                },
                {
                    "title": "Components",
                    "content": system_components,
                    "type": "components"
                },
                {
                    "title": "Metrics",
                    "content": system_metrics,
                    "type": "metrics"
                },
                {
                    "title": "Logs",
                    "content": system_logs,
                    "type": "logs"
                }
            ]
        
        elif context_type == self.CONTEXT_USER:
            # Add user details sections
            user_bio = context_data.get("bio", "No bio available.")
            user_preferences = context_data.get("preferences", {})
            user_permissions = context_data.get("permissions", [])
            user_activity = context_data.get("activity", [])
            
            details_content["sections"] = [
                {
                    "title": "Bio",
                    "content": user_bio,
                    "type": "text"
                },
                {
                    "title": "Preferences",
                    "content": user_preferences,
                    "type": "key_value"
                },
                {
                    "title": "Permissions",
                    "content": user_permissions,
                    "type": "permissions"
                },
                {
                    "title": "Activity",
                    "content": user_activity,
                    "type": "activity"
                }
            ]
        
        return details_content
    
    def _generate_actions_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate actions content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: Actions content
        """
        actions_content = {
            "primary_actions": [],
            "secondary_actions": []
        }
        
        if context_type == self.CONTEXT_AGENT:
            # Add agent actions
            actions_content["primary_actions"] = [
                {"id": "message", "label": "Message", "icon": "message_icon"},
                {"id": "assign_task", "label": "Assign Task", "icon": "task_icon"},
                {"id": "view_capsule", "label": "View Capsule", "icon": "capsule_icon"}
            ]
            
            actions_content["secondary_actions"] = [
                {"id": "configure", "label": "Configure", "icon": "configure_icon"},
                {"id": "pause", "label": "Pause", "icon": "pause_icon"},
                {"id": "restart", "label": "Restart", "icon": "restart_icon"},
                {"id": "export", "label": "Export", "icon": "export_icon"}
            ]
        
        elif context_type == self.CONTEXT_WORKFLOW:
            # Add workflow actions
            workflow_status = context_data.get("status", "").lower()
            
            if workflow_status == "running":
                actions_content["primary_actions"] = [
                    {"id": "pause", "label": "Pause", "icon": "pause_icon"},
                    {"id": "stop", "label": "Stop", "icon": "stop_icon"},
                    {"id": "view_details", "label": "View Details", "icon": "details_icon"}
                ]
            elif workflow_status == "paused":
                actions_content["primary_actions"] = [
                    {"id": "resume", "label": "Resume", "icon": "resume_icon"},
                    {"id": "stop", "label": "Stop", "icon": "stop_icon"},
                    {"id": "view_details", "label": "View Details", "icon": "details_icon"}
                ]
            else:
                actions_content["primary_actions"] = [
                    {"id": "start", "label": "Start", "icon": "start_icon"},
                    {"id": "edit", "label": "Edit", "icon": "edit_icon"},
                    {"id": "view_details", "label": "View Details", "icon": "details_icon"}
                ]
            
            actions_content["secondary_actions"] = [
                {"id": "duplicate", "label": "Duplicate", "icon": "duplicate_icon"},
                {"id": "export", "label": "Export", "icon": "export_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"},
                {"id": "delete", "label": "Delete", "icon": "delete_icon"}
            ]
        
        elif context_type == self.CONTEXT_TASK:
            # Add task actions
            task_status = context_data.get("status", "").lower()
            
            if task_status == "in_progress":
                actions_content["primary_actions"] = [
                    {"id": "complete", "label": "Complete", "icon": "complete_icon"},
                    {"id": "pause", "label": "Pause", "icon": "pause_icon"},
                    {"id": "add_comment", "label": "Add Comment", "icon": "comment_icon"}
                ]
            elif task_status == "paused":
                actions_content["primary_actions"] = [
                    {"id": "resume", "label": "Resume", "icon": "resume_icon"},
                    {"id": "complete", "label": "Complete", "icon": "complete_icon"},
                    {"id": "add_comment", "label": "Add Comment", "icon": "comment_icon"}
                ]
            else:
                actions_content["primary_actions"] = [
                    {"id": "start", "label": "Start", "icon": "start_icon"},
                    {"id": "assign", "label": "Assign", "icon": "assign_icon"},
                    {"id": "add_comment", "label": "Add Comment", "icon": "comment_icon"}
                ]
            
            actions_content["secondary_actions"] = [
                {"id": "edit", "label": "Edit", "icon": "edit_icon"},
                {"id": "add_subtask", "label": "Add Subtask", "icon": "subtask_icon"},
                {"id": "set_priority", "label": "Set Priority", "icon": "priority_icon"},
                {"id": "delete", "label": "Delete", "icon": "delete_icon"}
            ]
        
        elif context_type == self.CONTEXT_RESOURCE:
            # Add resource actions
            actions_content["primary_actions"] = [
                {"id": "open", "label": "Open", "icon": "open_icon"},
                {"id": "download", "label": "Download", "icon": "download_icon"},
                {"id": "share", "label": "Share", "icon": "share_icon"}
            ]
            
            actions_content["secondary_actions"] = [
                {"id": "edit", "label": "Edit", "icon": "edit_icon"},
                {"id": "permissions", "label": "Permissions", "icon": "permissions_icon"},
                {"id": "version_history", "label": "Version History", "icon": "history_icon"},
                {"id": "delete", "label": "Delete", "icon": "delete_icon"}
            ]
        
        elif context_type == self.CONTEXT_ALERT:
            # Add alert actions
            alert_status = context_data.get("status", "").lower()
            
            if alert_status == "new":
                actions_content["primary_actions"] = [
                    {"id": "acknowledge", "label": "Acknowledge", "icon": "acknowledge_icon"},
                    {"id": "investigate", "label": "Investigate", "icon": "investigate_icon"},
                    {"id": "dismiss", "label": "Dismiss", "icon": "dismiss_icon"}
                ]
            elif alert_status == "acknowledged":
                actions_content["primary_actions"] = [
                    {"id": "resolve", "label": "Resolve", "icon": "resolve_icon"},
                    {"id": "escalate", "label": "Escalate", "icon": "escalate_icon"},
                    {"id": "assign", "label": "Assign", "icon": "assign_icon"}
                ]
            else:
                actions_content["primary_actions"] = [
                    {"id": "reopen", "label": "Reopen", "icon": "reopen_icon"},
                    {"id": "view_details", "label": "View Details", "icon": "details_icon"},
                    {"id": "create_report", "label": "Create Report", "icon": "report_icon"}
                ]
            
            actions_content["secondary_actions"] = [
                {"id": "add_comment", "label": "Add Comment", "icon": "comment_icon"},
                {"id": "related_alerts", "label": "Related Alerts", "icon": "related_icon"},
                {"id": "view_history", "label": "View History", "icon": "history_icon"},
                {"id": "mute", "label": "Mute", "icon": "mute_icon"}
            ]
        
        elif context_type == self.CONTEXT_SYSTEM:
            # Add system actions
            actions_content["primary_actions"] = [
                {"id": "view_dashboard", "label": "View Dashboard", "icon": "dashboard_icon"},
                {"id": "view_logs", "label": "View Logs", "icon": "logs_icon"},
                {"id": "view_metrics", "label": "View Metrics", "icon": "metrics_icon"}
            ]
            
            actions_content["secondary_actions"] = [
                {"id": "configure", "label": "Configure", "icon": "configure_icon"},
                {"id": "restart", "label": "Restart", "icon": "restart_icon"},
                {"id": "update", "label": "Update", "icon": "update_icon"},
                {"id": "backup", "label": "Backup", "icon": "backup_icon"}
            ]
        
        elif context_type == self.CONTEXT_USER:
            # Add user actions
            actions_content["primary_actions"] = [
                {"id": "message", "label": "Message", "icon": "message_icon"},
                {"id": "call", "label": "Call", "icon": "call_icon"},
                {"id": "view_profile", "label": "View Profile", "icon": "profile_icon"}
            ]
            
            actions_content["secondary_actions"] = [
                {"id": "assign_task", "label": "Assign Task", "icon": "task_icon"},
                {"id": "share_resource", "label": "Share Resource", "icon": "share_icon"},
                {"id": "add_to_team", "label": "Add to Team", "icon": "team_icon"},
                {"id": "permissions", "label": "Permissions", "icon": "permissions_icon"}
            ]
        
        return actions_content
    
    def _generate_related_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate related content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: Related content
        """
        related_content = {
            "items": []
        }
        
        # Get related items from context data
        related_items = context_data.get("related_items", [])
        
        # Process related items
        for item in related_items:
            related_item = {
                "id": item.get("id", ""),
                "name": item.get("name", "Unknown"),
                "type": item.get("type", "Unknown"),
                "icon": item.get("icon", "default_icon"),
                "status": item.get("status", "Unknown"),
                "timestamp": item.get("timestamp", 0)
            }
            
            related_content["items"].append(related_item)
        
        # If no related items provided, generate placeholder based on context type
        if not related_items:
            if context_type == self.CONTEXT_AGENT:
                related_content["items"] = [
                    {
                        "id": "workflow_1",
                        "name": "Data Processing Workflow",
                        "type": "workflow",
                        "icon": "workflow_icon",
                        "status": "Running",
                        "timestamp": time.time() - 3600
                    },
                    {
                        "id": "task_1",
                        "name": "Analyze Sensor Data",
                        "type": "task",
                        "icon": "task_icon",
                        "status": "In Progress",
                        "timestamp": time.time() - 1800
                    }
                ]
            
            elif context_type == self.CONTEXT_WORKFLOW:
                related_content["items"] = [
                    {
                        "id": "agent_1",
                        "name": "Data Processor Agent",
                        "type": "agent",
                        "icon": "agent_icon",
                        "status": "Active",
                        "timestamp": time.time() - 3600
                    },
                    {
                        "id": "resource_1",
                        "name": "Sensor Data Feed",
                        "type": "resource",
                        "icon": "resource_icon",
                        "status": "Available",
                        "timestamp": time.time() - 7200
                    }
                ]
        
        return related_content
    
    def _generate_history_content(self, context_type: str, context_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate history content based on context.
        
        Args:
            context_type: Type of context
            context_data: Context data
        
        Returns:
            Dict[str, Any]: History content
        """
        history_content = {
            "events": []
        }
        
        # Get history events from context data
        history_events = context_data.get("history_events", [])
        
        # Process history events
        for event in history_events:
            history_event = {
                "id": event.get("id", ""),
                "type": event.get("type", "Unknown"),
                "description": event.get("description", "Unknown event"),
                "timestamp": event.get("timestamp", 0),
                "actor": event.get("actor", "Unknown"),
                "icon": event.get("icon", "default_icon")
            }
            
            history_content["events"].append(history_event)
        
        # If no history events provided, generate placeholder based on context type
        if not history_events:
            if context_type == self.CONTEXT_AGENT:
                history_content["events"] = [
                    {
                        "id": "event_1",
                        "type": "created",
                        "description": "Agent was created",
                        "timestamp": time.time() - 86400,
                        "actor": "System",
                        "icon": "created_icon"
                    },
                    {
                        "id": "event_2",
                        "type": "activated",
                        "description": "Agent was activated",
                        "timestamp": time.time() - 43200,
                        "actor": "System",
                        "icon": "activated_icon"
                    },
                    {
                        "id": "event_3",
                        "type": "task_assigned",
                        "description": "Task 'Analyze Sensor Data' was assigned",
                        "timestamp": time.time() - 3600,
                        "actor": "User",
                        "icon": "task_icon"
                    }
                ]
            
            elif context_type == self.CONTEXT_WORKFLOW:
                history_content["events"] = [
                    {
                        "id": "event_1",
                        "type": "created",
                        "description": "Workflow was created",
                        "timestamp": time.time() - 86400,
                        "actor": "User",
                        "icon": "created_icon"
                    },
                    {
                        "id": "event_2",
                        "type": "modified",
                        "description": "Workflow was modified",
                        "timestamp": time.time() - 43200,
                        "actor": "User",
                        "icon": "modified_icon"
                    },
                    {
                        "id": "event_3",
                        "type": "started",
                        "description": "Workflow was started",
                        "timestamp": time.time() - 3600,
                        "actor": "User",
                        "icon": "started_icon"
                    }
                ]
        
        return history_content
    
    def _format_timestamp(self, timestamp: float) -> str:
        """
        Format timestamp as human-readable string.
        
        Args:
            timestamp: Unix timestamp
        
        Returns:
            str: Formatted timestamp
        """
        if timestamp == 0:
            return "Unknown"
        
        # Calculate time difference
        now = time.time()
        diff = now - timestamp
        
        # Format based on time difference
        if diff < 60:
            return "Just now"
        elif diff < 3600:
            minutes = int(diff / 60)
            return f"{minutes}m ago"
        elif diff < 86400:
            hours = int(diff / 3600)
            return f"{hours}h ago"
        elif diff < 604800:
            days = int(diff / 86400)
            return f"{days}d ago"
        else:
            # Format as date
            import datetime
            dt = datetime.datetime.fromtimestamp(timestamp)
            return dt.strftime("%b %d, %Y")
    
    def _format_duration(self, seconds: float) -> str:
        """
        Format duration as human-readable string.
        
        Args:
            seconds: Duration in seconds
        
        Returns:
            str: Formatted duration
        """
        if seconds == 0:
            return "0s"
        
        # Format based on duration
        if seconds < 60:
            return f"{int(seconds)}s"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            return f"{minutes}m"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            minutes = int((seconds % 3600) / 60)
            return f"{hours}h {minutes}m"
        else:
            days = int(seconds / 86400)
            hours = int((seconds % 86400) / 3600)
            return f"{days}d {hours}h"
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        if context_type:
            self.set_context(context_type, context_data)
    
    def _on_focus_changed(self, event_data: Dict[str, Any]):
        """
        Handle focus changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Focus changed: %s", event_data)
        
        focus_type = event_data.get("focus_type")
        focus_data = event_data.get("focus_data", {})
        
        if focus_type:
            # Map focus type to context type
            focus_to_context = {
                "agent": self.CONTEXT_AGENT,
                "workflow": self.CONTEXT_WORKFLOW,
                "task": self.CONTEXT_TASK,
                "resource": self.CONTEXT_RESOURCE,
                "alert": self.CONTEXT_ALERT,
                "system": self.CONTEXT_SYSTEM,
                "user": self.CONTEXT_USER
            }
            
            if focus_type in focus_to_context:
                self.set_context(focus_to_context[focus_type], focus_data)
    
    def _on_capsule_activated(self, event_data: Dict[str, Any]):
        """
        Handle capsule activated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule activated: %s", event_data)
        
        capsule_type = event_data.get("capsule_type")
        capsule_data = event_data.get("capsule_data", {})
        
        if capsule_type == "agent":
            self.set_context(self.CONTEXT_AGENT, capsule_data)
        elif capsule_type == "workflow":
            self.set_context(self.CONTEXT_WORKFLOW, capsule_data)
        elif capsule_type == "task":
            self.set_context(self.CONTEXT_TASK, capsule_data)
    
    def _on_capsule_deactivated(self, event_data: Dict[str, Any]):
        """
        Handle capsule deactivated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule deactivated: %s", event_data)
        
        # If current context is related to the deactivated capsule, clear it
        if self.current_context:
            capsule_id = event_data.get("capsule_id")
            current_context_id = self.current_context.get("data", {}).get("id")
            
            if capsule_id and capsule_id == current_context_id:
                # Set context to system
                self.set_context(self.CONTEXT_SYSTEM, {
                    "id": "system",
                    "name": "System",
                    "status": "Active"
                })
    
    def _on_avatar_state_changed(self, event_data: Dict[str, Any]):
        """
        Handle avatar state changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Avatar state changed: %s", event_data)
        
        # If current context is related to the avatar, update it
        if self.current_context and self.current_context["type"] == self.CONTEXT_AGENT:
            layer_id = event_data.get("layer_id")
            current_layer_id = self.current_context.get("data", {}).get("layer_id")
            
            if layer_id and layer_id == current_layer_id:
                # Update context data
                context_data = self.current_context["data"].copy()
                context_data["status"] = event_data.get("new_state")
                
                # Set updated context
                self.set_context(self.CONTEXT_AGENT, context_data)
    
    def _on_avatar_message_added(self, event_data: Dict[str, Any]):
        """
        Handle avatar message added event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Avatar message added: %s", event_data)
        
        # If current context is related to the avatar, update it
        if self.current_context and self.current_context["type"] == self.CONTEXT_AGENT:
            layer_id = event_data.get("layer_id")
            current_layer_id = self.current_context.get("data", {}).get("layer_id")
            
            if layer_id and layer_id == current_layer_id:
                # Update context data
                context_data = self.current_context["data"].copy()
                
                # Add message to history events
                if "history_events" not in context_data:
                    context_data["history_events"] = []
                
                message = event_data.get("message", {})
                
                history_event = {
                    "id": message.get("id", str(uuid.uuid4())),
                    "type": "message",
                    "description": message.get("content", "New message"),
                    "timestamp": message.get("timestamp", time.time()),
                    "actor": message.get("source", "Avatar"),
                    "icon": "message_icon"
                }
                
                context_data["history_events"].insert(0, history_event)
                
                # Set updated context
                self.set_context(self.CONTEXT_AGENT, context_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Context Panel events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Context Panel events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def to_json(self) -> str:
        """
        Serialize Context Panel state to JSON.
        
        Returns:
            str: JSON string representation of Context Panel state
        """
        import json
        
        state = {
            "current_context": self.current_context,
            "panel_visibility": self.panel_visibility,
            "panel_size": self.panel_size,
            "panel_position": self.panel_position,
            "panel_theme": self.panel_theme,
            "panel_sections": self.panel_sections
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize Context Panel state from JSON.
        
        Args:
            json_str: JSON string representation of Context Panel state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        import json
        
        try:
            state = json.loads(json_str)
            
            self.current_context = state.get("current_context")
            self.panel_visibility = state.get("panel_visibility", True)
            self.panel_size = state.get("panel_size", "medium")
            self.panel_position = state.get("panel_position", "right")
            self.panel_theme = state.get("panel_theme", "default")
            self.panel_sections = state.get("panel_sections", {})
            
            return True
        except Exception as e:
            logger.error("Error deserializing Context Panel state: %s", e)
            return False
