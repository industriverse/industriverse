"""
Adaptive Form Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements an adaptive form system that morphs based on context, trust level,
and user role, providing a fluid interface for data input and decision-making that adapts
to the current situation and available information.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import math
import uuid
from datetime import datetime

# Initialize logger
logger = logging.getLogger(__name__)

class AdaptiveForm:
    """
    Adaptive Form component for providing context-aware, trust-weighted forms
    that adapt to user roles, device capabilities, and interaction patterns.
    """
    
    # Form type constants
    TYPE_INPUT = "input"
    TYPE_DECISION = "decision"
    TYPE_WORKFLOW = "workflow"
    TYPE_CONFIGURATION = "configuration"
    TYPE_SURVEY = "survey"
    
    # Field type constants
    FIELD_TEXT = "text"
    FIELD_NUMBER = "number"
    FIELD_BOOLEAN = "boolean"
    FIELD_SELECT = "select"
    FIELD_MULTISELECT = "multiselect"
    FIELD_DATE = "date"
    FIELD_TIME = "time"
    FIELD_DATETIME = "datetime"
    FIELD_FILE = "file"
    FIELD_IMAGE = "image"
    FIELD_LOCATION = "location"
    FIELD_SLIDER = "slider"
    FIELD_RATING = "rating"
    FIELD_RICH_TEXT = "rich_text"
    FIELD_SIGNATURE = "signature"
    FIELD_CUSTOM = "custom"
    
    # Validation type constants
    VALIDATION_REQUIRED = "required"
    VALIDATION_MIN_LENGTH = "min_length"
    VALIDATION_MAX_LENGTH = "max_length"
    VALIDATION_MIN_VALUE = "min_value"
    VALIDATION_MAX_VALUE = "max_value"
    VALIDATION_PATTERN = "pattern"
    VALIDATION_EMAIL = "email"
    VALIDATION_URL = "url"
    VALIDATION_CUSTOM = "custom"
    
    # Layout type constants
    LAYOUT_LINEAR = "linear"
    LAYOUT_GRID = "grid"
    LAYOUT_TABS = "tabs"
    LAYOUT_WIZARD = "wizard"
    LAYOUT_ACCORDION = "accordion"
    LAYOUT_ADAPTIVE = "adaptive"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Adaptive Form component with optional configuration."""
        self.config = config or {}
        self.forms = {}
        self.active_form_id = None
        self.form_submissions = {}
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.protocol_bridge = None
        self.rendering_engine = None
        
        logger.info("Adaptive Form component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, protocol_bridge=None, 
                  rendering_engine=None):
        """Initialize the Adaptive Form component and connect to required services."""
        logger.info("Initializing Adaptive Form component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.protocol_bridge = protocol_bridge
        self.rendering_engine = rendering_engine
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
            self.context_engine.subscribe_to_events("user_role_changed", self._on_user_role_changed)
            self.context_engine.subscribe_to_events("trust_level_changed", self._on_trust_level_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        logger.info("Adaptive Form component initialization complete")
        return True
    
    def create_form(self, form_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new form.
        
        Args:
            form_data: Form data
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating form: %s", form_data.get("title", ""))
        
        # Validate required fields
        required_fields = ["title", "type", "fields"]
        for field in required_fields:
            if field not in form_data:
                logger.warning("Missing required field in form: %s", field)
                return None
        
        # Generate form ID
        form_id = form_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in form_data:
            form_data["description"] = ""
        
        if "layout" not in form_data:
            form_data["layout"] = self.LAYOUT_LINEAR
        
        if "sections" not in form_data:
            form_data["sections"] = []
        
        if "validation" not in form_data:
            form_data["validation"] = {}
        
        if "trust_levels" not in form_data:
            form_data["trust_levels"] = {}
        
        if "roles" not in form_data:
            form_data["roles"] = []
        
        if "adaptive_rules" not in form_data:
            form_data["adaptive_rules"] = []
        
        if "metadata" not in form_data:
            form_data["metadata"] = {}
        
        if "created_at" not in form_data:
            form_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in form_data:
            form_data["updated_at"] = datetime.now().isoformat()
        
        # Store form
        form_data["id"] = form_id
        self.forms[form_id] = form_data
        
        # Set as active form if this is the first one
        if len(self.forms) == 1:
            self.active_form_id = form_id
        
        # Notify subscribers
        self._notify_subscribers("form_created", {
            "form_id": form_id,
            "form": form_data
        })
        
        return form_id
    
    def update_form(self, form_id: str, form_data: Dict[str, Any]) -> bool:
        """
        Update an existing form.
        
        Args:
            form_id: Form identifier
            form_data: Updated form data
        
        Returns:
            bool: True if form was updated successfully, False otherwise
        """
        logger.info("Updating form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        # Get current form data
        current_data = self.forms[form_id]
        
        # Update fields
        for key, value in form_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("form_updated", {
            "form_id": form_id,
            "form": current_data
        })
        
        return True
    
    def delete_form(self, form_id: str) -> bool:
        """
        Delete a form.
        
        Args:
            form_id: Form identifier
        
        Returns:
            bool: True if form was deleted successfully, False otherwise
        """
        logger.info("Deleting form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        # Remove form
        del self.forms[form_id]
        
        # Update active form if this was the active one
        if self.active_form_id == form_id:
            if self.forms:
                self.active_form_id = next(iter(self.forms))
            else:
                self.active_form_id = None
        
        # Notify subscribers
        self._notify_subscribers("form_deleted", {
            "form_id": form_id
        })
        
        return True
    
    def get_form(self, form_id: str) -> Optional[Dict[str, Any]]:
        """
        Get form by ID.
        
        Args:
            form_id: Form identifier
        
        Returns:
            Optional[Dict[str, Any]]: Form if found, None otherwise
        """
        if form_id in self.forms:
            return self.forms[form_id]
        else:
            logger.warning("Form not found: %s", form_id)
            return None
    
    def get_all_forms(self, form_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all forms, optionally filtered by type.
        
        Args:
            form_type: Optional form type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of forms
        """
        if form_type:
            return [form for form in self.forms.values() if form.get("type") == form_type]
        else:
            return list(self.forms.values())
    
    def set_active_form(self, form_id: Optional[str]) -> bool:
        """
        Set the active form.
        
        Args:
            form_id: Form identifier, or None to clear active form
        
        Returns:
            bool: True if active form was set successfully, False otherwise
        """
        logger.info("Setting active form: %s", form_id)
        
        if form_id is not None and form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        previous_form_id = self.active_form_id
        self.active_form_id = form_id
        
        # Notify subscribers
        self._notify_subscribers("active_form_changed", {
            "previous_form_id": previous_form_id,
            "form_id": form_id
        })
        
        return True
    
    def get_active_form(self) -> Optional[Dict[str, Any]]:
        """
        Get the active form.
        
        Returns:
            Optional[Dict[str, Any]]: Active form if set, None otherwise
        """
        if self.active_form_id is not None and self.active_form_id in self.forms:
            return self.forms[self.active_form_id]
        else:
            return None
    
    def add_field(self, form_id: str, field_data: Dict[str, Any], 
                section_id: Optional[str] = None) -> Optional[str]:
        """
        Add a field to a form.
        
        Args:
            form_id: Form identifier
            field_data: Field data
            section_id: Optional section identifier
        
        Returns:
            Optional[str]: Field ID if added successfully, None otherwise
        """
        logger.info("Adding field to form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return None
        
        # Validate required fields
        required_fields = ["name", "type", "label"]
        for field in required_fields:
            if field not in field_data:
                logger.warning("Missing required field in field data: %s", field)
                return None
        
        # Generate field ID
        field_id = field_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in field_data:
            field_data["description"] = ""
        
        if "required" not in field_data:
            field_data["required"] = False
        
        if "default_value" not in field_data:
            field_data["default_value"] = None
        
        if "validation" not in field_data:
            field_data["validation"] = {}
        
        if "options" not in field_data and field_data["type"] in [self.FIELD_SELECT, self.FIELD_MULTISELECT]:
            field_data["options"] = []
        
        if "trust_levels" not in field_data:
            field_data["trust_levels"] = {}
        
        if "roles" not in field_data:
            field_data["roles"] = []
        
        if "metadata" not in field_data:
            field_data["metadata"] = {}
        
        # Store field ID
        field_data["id"] = field_id
        
        # Add field to form
        form = self.forms[form_id]
        
        if section_id:
            # Find section
            section_found = False
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    if "fields" not in section:
                        section["fields"] = []
                    
                    section["fields"].append(field_data)
                    section_found = True
                    break
            
            if not section_found:
                logger.warning("Section not found: %s", section_id)
                return None
        else:
            # Add to form fields
            form["fields"].append(field_data)
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("field_added", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id,
            "field": field_data
        })
        
        return field_id
    
    def update_field(self, form_id: str, field_id: str, 
                   field_data: Dict[str, Any], section_id: Optional[str] = None) -> bool:
        """
        Update a field in a form.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            field_data: Updated field data
            section_id: Optional section identifier
        
        Returns:
            bool: True if field was updated successfully, False otherwise
        """
        logger.info("Updating field %s in form %s", field_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    for i, field in enumerate(section.get("fields", [])):
                        if field.get("id") == field_id:
                            # Update fields
                            for key, value in field_data.items():
                                # Don't update id
                                if key == "id":
                                    continue
                                
                                field[key] = value
                            
                            # Update section
                            section["fields"][i] = field
                            field_found = True
                            break
                    
                    break
        else:
            # Find in form fields
            for i, field in enumerate(form.get("fields", [])):
                if field.get("id") == field_id:
                    # Update fields
                    for key, value in field_data.items():
                        # Don't update id
                        if key == "id":
                            continue
                        
                        field[key] = value
                    
                    # Update form
                    form["fields"][i] = field
                    field_found = True
                    break
        
        if not field_found:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("field_updated", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id,
            "field": field_data
        })
        
        return True
    
    def remove_field(self, form_id: str, field_id: str, 
                   section_id: Optional[str] = None) -> bool:
        """
        Remove a field from a form.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            section_id: Optional section identifier
        
        Returns:
            bool: True if field was removed successfully, False otherwise
        """
        logger.info("Removing field %s from form %s", field_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    fields = section.get("fields", [])
                    updated_fields = [f for f in fields if f.get("id") != field_id]
                    
                    if len(fields) != len(updated_fields):
                        section["fields"] = updated_fields
                        field_found = True
                    
                    break
        else:
            # Find in form fields
            fields = form.get("fields", [])
            updated_fields = [f for f in fields if f.get("id") != field_id]
            
            if len(fields) != len(updated_fields):
                form["fields"] = updated_fields
                field_found = True
        
        if not field_found:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("field_removed", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id
        })
        
        return True
    
    def add_section(self, form_id: str, section_data: Dict[str, Any]) -> Optional[str]:
        """
        Add a section to a form.
        
        Args:
            form_id: Form identifier
            section_data: Section data
        
        Returns:
            Optional[str]: Section ID if added successfully, None otherwise
        """
        logger.info("Adding section to form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return None
        
        # Validate required fields
        required_fields = ["title"]
        for field in required_fields:
            if field not in section_data:
                logger.warning("Missing required field in section data: %s", field)
                return None
        
        # Generate section ID
        section_id = section_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in section_data:
            section_data["description"] = ""
        
        if "fields" not in section_data:
            section_data["fields"] = []
        
        if "order" not in section_data:
            # Set order to end of sections list
            form = self.forms[form_id]
            section_data["order"] = len(form.get("sections", []))
        
        if "collapsed" not in section_data:
            section_data["collapsed"] = False
        
        if "trust_levels" not in section_data:
            section_data["trust_levels"] = {}
        
        if "roles" not in section_data:
            section_data["roles"] = []
        
        if "metadata" not in section_data:
            section_data["metadata"] = {}
        
        # Store section ID
        section_data["id"] = section_id
        
        # Add section to form
        form = self.forms[form_id]
        
        if "sections" not in form:
            form["sections"] = []
        
        form["sections"].append(section_data)
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("section_added", {
            "form_id": form_id,
            "section_id": section_id,
            "section": section_data
        })
        
        return section_id
    
    def update_section(self, form_id: str, section_id: str, 
                     section_data: Dict[str, Any]) -> bool:
        """
        Update a section in a form.
        
        Args:
            form_id: Form identifier
            section_id: Section identifier
            section_data: Updated section data
        
        Returns:
            bool: True if section was updated successfully, False otherwise
        """
        logger.info("Updating section %s in form %s", section_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find section
        section_found = False
        for i, section in enumerate(form.get("sections", [])):
            if section.get("id") == section_id:
                # Update fields
                for key, value in section_data.items():
                    # Don't update id
                    if key == "id":
                        continue
                    
                    section[key] = value
                
                # Update form
                form["sections"][i] = section
                section_found = True
                break
        
        if not section_found:
            logger.warning("Section not found: %s", section_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("section_updated", {
            "form_id": form_id,
            "section_id": section_id,
            "section": section_data
        })
        
        return True
    
    def remove_section(self, form_id: str, section_id: str) -> bool:
        """
        Remove a section from a form.
        
        Args:
            form_id: Form identifier
            section_id: Section identifier
        
        Returns:
            bool: True if section was removed successfully, False otherwise
        """
        logger.info("Removing section %s from form %s", section_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find section
        sections = form.get("sections", [])
        updated_sections = [s for s in sections if s.get("id") != section_id]
        
        if len(sections) == len(updated_sections):
            logger.warning("Section not found: %s", section_id)
            return False
        
        # Update form
        form["sections"] = updated_sections
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("section_removed", {
            "form_id": form_id,
            "section_id": section_id
        })
        
        return True
    
    def add_validation(self, form_id: str, field_id: str, 
                     validation_type: str, validation_data: Any,
                     section_id: Optional[str] = None) -> bool:
        """
        Add validation to a field.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            validation_type: Validation type
            validation_data: Validation data
            section_id: Optional section identifier
        
        Returns:
            bool: True if validation was added successfully, False otherwise
        """
        logger.info("Adding validation to field %s in form %s", field_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        field = None
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    for f in section.get("fields", []):
                        if f.get("id") == field_id:
                            field = f
                            field_found = True
                            break
                    
                    break
        else:
            # Find in form fields
            for f in form.get("fields", []):
                if f.get("id") == field_id:
                    field = f
                    field_found = True
                    break
        
        if not field_found or not field:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Add validation
        if "validation" not in field:
            field["validation"] = {}
        
        field["validation"][validation_type] = validation_data
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("validation_added", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id,
            "validation_type": validation_type,
            "validation_data": validation_data
        })
        
        return True
    
    def remove_validation(self, form_id: str, field_id: str, 
                        validation_type: str, section_id: Optional[str] = None) -> bool:
        """
        Remove validation from a field.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            validation_type: Validation type
            section_id: Optional section identifier
        
        Returns:
            bool: True if validation was removed successfully, False otherwise
        """
        logger.info("Removing validation from field %s in form %s", field_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        field = None
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    for f in section.get("fields", []):
                        if f.get("id") == field_id:
                            field = f
                            field_found = True
                            break
                    
                    break
        else:
            # Find in form fields
            for f in form.get("fields", []):
                if f.get("id") == field_id:
                    field = f
                    field_found = True
                    break
        
        if not field_found or not field:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Remove validation
        if "validation" in field and validation_type in field["validation"]:
            del field["validation"][validation_type]
            
            # Update form timestamp
            form["updated_at"] = datetime.now().isoformat()
            
            # Notify subscribers
            self._notify_subscribers("validation_removed", {
                "form_id": form_id,
                "field_id": field_id,
                "section_id": section_id,
                "validation_type": validation_type
            })
            
            return True
        else:
            logger.warning("Validation not found: %s", validation_type)
            return False
    
    def add_adaptive_rule(self, form_id: str, rule_data: Dict[str, Any]) -> Optional[str]:
        """
        Add an adaptive rule to a form.
        
        Args:
            form_id: Form identifier
            rule_data: Rule data
        
        Returns:
            Optional[str]: Rule ID if added successfully, None otherwise
        """
        logger.info("Adding adaptive rule to form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return None
        
        # Validate required fields
        required_fields = ["condition", "actions"]
        for field in required_fields:
            if field not in rule_data:
                logger.warning("Missing required field in rule data: %s", field)
                return None
        
        # Generate rule ID
        rule_id = rule_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "name" not in rule_data:
            rule_data["name"] = f"Rule {rule_id[:8]}"
        
        if "description" not in rule_data:
            rule_data["description"] = ""
        
        if "priority" not in rule_data:
            rule_data["priority"] = 0
        
        if "metadata" not in rule_data:
            rule_data["metadata"] = {}
        
        # Store rule ID
        rule_data["id"] = rule_id
        
        # Add rule to form
        form = self.forms[form_id]
        
        if "adaptive_rules" not in form:
            form["adaptive_rules"] = []
        
        form["adaptive_rules"].append(rule_data)
        
        # Sort rules by priority
        form["adaptive_rules"].sort(key=lambda r: r.get("priority", 0), reverse=True)
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("adaptive_rule_added", {
            "form_id": form_id,
            "rule_id": rule_id,
            "rule": rule_data
        })
        
        return rule_id
    
    def update_adaptive_rule(self, form_id: str, rule_id: str, 
                           rule_data: Dict[str, Any]) -> bool:
        """
        Update an adaptive rule in a form.
        
        Args:
            form_id: Form identifier
            rule_id: Rule identifier
            rule_data: Updated rule data
        
        Returns:
            bool: True if rule was updated successfully, False otherwise
        """
        logger.info("Updating adaptive rule %s in form %s", rule_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find rule
        rule_found = False
        for i, rule in enumerate(form.get("adaptive_rules", [])):
            if rule.get("id") == rule_id:
                # Update fields
                for key, value in rule_data.items():
                    # Don't update id
                    if key == "id":
                        continue
                    
                    rule[key] = value
                
                # Update form
                form["adaptive_rules"][i] = rule
                rule_found = True
                break
        
        if not rule_found:
            logger.warning("Adaptive rule not found: %s", rule_id)
            return False
        
        # Sort rules by priority
        form["adaptive_rules"].sort(key=lambda r: r.get("priority", 0), reverse=True)
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("adaptive_rule_updated", {
            "form_id": form_id,
            "rule_id": rule_id,
            "rule": rule_data
        })
        
        return True
    
    def remove_adaptive_rule(self, form_id: str, rule_id: str) -> bool:
        """
        Remove an adaptive rule from a form.
        
        Args:
            form_id: Form identifier
            rule_id: Rule identifier
        
        Returns:
            bool: True if rule was removed successfully, False otherwise
        """
        logger.info("Removing adaptive rule %s from form %s", rule_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find rule
        rules = form.get("adaptive_rules", [])
        updated_rules = [r for r in rules if r.get("id") != rule_id]
        
        if len(rules) == len(updated_rules):
            logger.warning("Adaptive rule not found: %s", rule_id)
            return False
        
        # Update form
        form["adaptive_rules"] = updated_rules
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("adaptive_rule_removed", {
            "form_id": form_id,
            "rule_id": rule_id
        })
        
        return True
    
    def set_trust_level_visibility(self, form_id: str, entity_id: str, 
                                 entity_type: str, trust_level: str, 
                                 visible: bool, section_id: Optional[str] = None) -> bool:
        """
        Set trust level visibility for a form entity.
        
        Args:
            form_id: Form identifier
            entity_id: Entity identifier (form, field, or section)
            entity_type: Entity type ("form", "field", or "section")
            trust_level: Trust level
            visible: Whether entity is visible at this trust level
            section_id: Optional section identifier (for fields)
        
        Returns:
            bool: True if trust level visibility was set successfully, False otherwise
        """
        logger.info("Setting trust level visibility for %s %s in form %s", 
                  entity_type, entity_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find entity
        entity = None
        
        if entity_type == "form":
            entity = form
        elif entity_type == "section":
            for section in form.get("sections", []):
                if section.get("id") == entity_id:
                    entity = section
                    break
        elif entity_type == "field":
            if section_id:
                # Find section
                for section in form.get("sections", []):
                    if section.get("id") == section_id:
                        for field in section.get("fields", []):
                            if field.get("id") == entity_id:
                                entity = field
                                break
                        
                        break
            else:
                # Find in form fields
                for field in form.get("fields", []):
                    if field.get("id") == entity_id:
                        entity = field
                        break
        
        if not entity:
            logger.warning("%s not found: %s", entity_type.capitalize(), entity_id)
            return False
        
        # Set trust level visibility
        if "trust_levels" not in entity:
            entity["trust_levels"] = {}
        
        entity["trust_levels"][trust_level] = visible
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("trust_level_visibility_set", {
            "form_id": form_id,
            "entity_id": entity_id,
            "entity_type": entity_type,
            "section_id": section_id,
            "trust_level": trust_level,
            "visible": visible
        })
        
        return True
    
    def set_role_visibility(self, form_id: str, entity_id: str, 
                          entity_type: str, role: str, 
                          visible: bool, section_id: Optional[str] = None) -> bool:
        """
        Set role visibility for a form entity.
        
        Args:
            form_id: Form identifier
            entity_id: Entity identifier (form, field, or section)
            entity_type: Entity type ("form", "field", or "section")
            role: User role
            visible: Whether entity is visible for this role
            section_id: Optional section identifier (for fields)
        
        Returns:
            bool: True if role visibility was set successfully, False otherwise
        """
        logger.info("Setting role visibility for %s %s in form %s", 
                  entity_type, entity_id, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find entity
        entity = None
        
        if entity_type == "form":
            entity = form
        elif entity_type == "section":
            for section in form.get("sections", []):
                if section.get("id") == entity_id:
                    entity = section
                    break
        elif entity_type == "field":
            if section_id:
                # Find section
                for section in form.get("sections", []):
                    if section.get("id") == section_id:
                        for field in section.get("fields", []):
                            if field.get("id") == entity_id:
                                entity = field
                                break
                        
                        break
            else:
                # Find in form fields
                for field in form.get("fields", []):
                    if field.get("id") == entity_id:
                        entity = field
                        break
        
        if not entity:
            logger.warning("%s not found: %s", entity_type.capitalize(), entity_id)
            return False
        
        # Set role visibility
        if "roles" not in entity:
            entity["roles"] = []
        
        if visible and role not in entity["roles"]:
            entity["roles"].append(role)
        elif not visible and role in entity["roles"]:
            entity["roles"].remove(role)
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("role_visibility_set", {
            "form_id": form_id,
            "entity_id": entity_id,
            "entity_type": entity_type,
            "section_id": section_id,
            "role": role,
            "visible": visible
        })
        
        return True
    
    def submit_form(self, form_id: str, form_data: Dict[str, Any]) -> Optional[str]:
        """
        Submit a form.
        
        Args:
            form_id: Form identifier
            form_data: Form submission data
        
        Returns:
            Optional[str]: Submission ID if successful, None otherwise
        """
        logger.info("Submitting form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return None
        
        form = self.forms[form_id]
        
        # Validate form data
        validation_errors = self.validate_form_data(form_id, form_data)
        if validation_errors:
            logger.warning("Form validation failed: %s", validation_errors)
            
            # Notify subscribers
            self._notify_subscribers("form_validation_failed", {
                "form_id": form_id,
                "errors": validation_errors
            })
            
            return None
        
        # Generate submission ID
        submission_id = str(uuid.uuid4())
        
        # Create submission record
        submission = {
            "id": submission_id,
            "form_id": form_id,
            "data": form_data,
            "submitted_at": datetime.now().isoformat(),
            "status": "submitted",
            "processed": False,
            "metadata": {}
        }
        
        # Store submission
        if form_id not in self.form_submissions:
            self.form_submissions[form_id] = []
        
        self.form_submissions[form_id].append(submission)
        
        # Notify subscribers
        self._notify_subscribers("form_submitted", {
            "form_id": form_id,
            "submission_id": submission_id,
            "submission": submission
        })
        
        return submission_id
    
    def validate_form_data(self, form_id: str, form_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """
        Validate form data.
        
        Args:
            form_id: Form identifier
            form_data: Form data to validate
        
        Returns:
            Dict[str, List[str]]: Validation errors by field, empty if no errors
        """
        logger.info("Validating form data for form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return {"_form": ["Form not found"]}
        
        form = self.forms[form_id]
        errors = {}
        
        # Collect all fields from form and sections
        all_fields = []
        all_fields.extend(form.get("fields", []))
        
        for section in form.get("sections", []):
            all_fields.extend(section.get("fields", []))
        
        # Validate each field
        for field in all_fields:
            field_name = field.get("name")
            field_type = field.get("type")
            field_required = field.get("required", False)
            field_validation = field.get("validation", {})
            
            # Skip fields that are not in the form data
            if field_name not in form_data:
                if field_required:
                    errors[field_name] = ["This field is required"]
                continue
            
            field_value = form_data[field_name]
            field_errors = []
            
            # Required validation
            if field_required and (field_value is None or field_value == "" or 
                                 (isinstance(field_value, list) and len(field_value) == 0)):
                field_errors.append("This field is required")
            
            # Type-specific validation
            if field_value is not None and field_value != "":
                if field_type == self.FIELD_TEXT:
                    # String validation
                    if not isinstance(field_value, str):
                        field_errors.append("Value must be a string")
                    else:
                        # Min length
                        min_length = field_validation.get(self.VALIDATION_MIN_LENGTH)
                        if min_length is not None and len(field_value) < min_length:
                            field_errors.append(f"Minimum length is {min_length} characters")
                        
                        # Max length
                        max_length = field_validation.get(self.VALIDATION_MAX_LENGTH)
                        if max_length is not None and len(field_value) > max_length:
                            field_errors.append(f"Maximum length is {max_length} characters")
                        
                        # Pattern
                        pattern = field_validation.get(self.VALIDATION_PATTERN)
                        if pattern is not None:
                            import re
                            if not re.match(pattern, field_value):
                                field_errors.append("Value does not match required pattern")
                        
                        # Email
                        if self.VALIDATION_EMAIL in field_validation and field_validation[self.VALIDATION_EMAIL]:
                            import re
                            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
                            if not re.match(email_pattern, field_value):
                                field_errors.append("Invalid email address")
                        
                        # URL
                        if self.VALIDATION_URL in field_validation and field_validation[self.VALIDATION_URL]:
                            import re
                            url_pattern = r'^(https?|ftp)://[^\s/$.?#].[^\s]*$'
                            if not re.match(url_pattern, field_value):
                                field_errors.append("Invalid URL")
                
                elif field_type == self.FIELD_NUMBER:
                    # Number validation
                    try:
                        num_value = float(field_value)
                        
                        # Min value
                        min_value = field_validation.get(self.VALIDATION_MIN_VALUE)
                        if min_value is not None and num_value < min_value:
                            field_errors.append(f"Minimum value is {min_value}")
                        
                        # Max value
                        max_value = field_validation.get(self.VALIDATION_MAX_VALUE)
                        if max_value is not None and num_value > max_value:
                            field_errors.append(f"Maximum value is {max_value}")
                    except (ValueError, TypeError):
                        field_errors.append("Value must be a number")
                
                elif field_type == self.FIELD_BOOLEAN:
                    # Boolean validation
                    if not isinstance(field_value, bool):
                        field_errors.append("Value must be a boolean")
                
                elif field_type in [self.FIELD_SELECT, self.FIELD_MULTISELECT]:
                    # Select validation
                    options = [opt.get("value") for opt in field.get("options", [])]
                    
                    if field_type == self.FIELD_SELECT:
                        if field_value not in options:
                            field_errors.append("Invalid option selected")
                    else:  # FIELD_MULTISELECT
                        if not isinstance(field_value, list):
                            field_errors.append("Value must be a list")
                        else:
                            for val in field_value:
                                if val not in options:
                                    field_errors.append("Invalid option selected")
                                    break
                
                elif field_type == self.FIELD_DATE:
                    # Date validation
                    try:
                        from datetime import datetime
                        datetime.strptime(field_value, "%Y-%m-%d")
                    except ValueError:
                        field_errors.append("Invalid date format (YYYY-MM-DD)")
                
                elif field_type == self.FIELD_TIME:
                    # Time validation
                    try:
                        from datetime import datetime
                        datetime.strptime(field_value, "%H:%M:%S")
                    except ValueError:
                        field_errors.append("Invalid time format (HH:MM:SS)")
                
                elif field_type == self.FIELD_DATETIME:
                    # Datetime validation
                    try:
                        from datetime import datetime
                        datetime.fromisoformat(field_value)
                    except ValueError:
                        field_errors.append("Invalid datetime format (ISO format)")
                
                elif field_type == self.FIELD_SLIDER:
                    # Slider validation
                    try:
                        num_value = float(field_value)
                        min_value = field.get("min", 0)
                        max_value = field.get("max", 100)
                        
                        if num_value < min_value or num_value > max_value:
                            field_errors.append(f"Value must be between {min_value} and {max_value}")
                    except (ValueError, TypeError):
                        field_errors.append("Value must be a number")
                
                elif field_type == self.FIELD_RATING:
                    # Rating validation
                    try:
                        num_value = int(field_value)
                        max_rating = field.get("max_rating", 5)
                        
                        if num_value < 1 or num_value > max_rating:
                            field_errors.append(f"Rating must be between 1 and {max_rating}")
                    except (ValueError, TypeError):
                        field_errors.append("Rating must be a number")
            
            # Custom validation
            custom_validation = field_validation.get(self.VALIDATION_CUSTOM)
            if custom_validation and callable(custom_validation):
                try:
                    custom_result = custom_validation(field_value)
                    if custom_result is not True:
                        field_errors.append(custom_result or "Custom validation failed")
                except Exception as e:
                    logger.error("Error in custom validation: %s", e)
                    field_errors.append("Validation error")
            
            # Add errors for this field
            if field_errors:
                errors[field_name] = field_errors
        
        # Form-level validation
        form_validation = form.get("validation", {})
        custom_validation = form_validation.get(self.VALIDATION_CUSTOM)
        if custom_validation and callable(custom_validation):
            try:
                custom_result = custom_validation(form_data)
                if custom_result is not True:
                    if "_form" not in errors:
                        errors["_form"] = []
                    
                    errors["_form"].append(custom_result or "Form validation failed")
            except Exception as e:
                logger.error("Error in form custom validation: %s", e)
                if "_form" not in errors:
                    errors["_form"] = []
                
                errors["_form"].append("Form validation error")
        
        return errors
    
    def get_form_submission(self, form_id: str, submission_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a form submission.
        
        Args:
            form_id: Form identifier
            submission_id: Submission identifier
        
        Returns:
            Optional[Dict[str, Any]]: Submission if found, None otherwise
        """
        logger.info("Getting form submission %s for form %s", submission_id, form_id)
        
        if form_id not in self.form_submissions:
            logger.warning("No submissions found for form: %s", form_id)
            return None
        
        for submission in self.form_submissions[form_id]:
            if submission.get("id") == submission_id:
                return submission
        
        logger.warning("Submission not found: %s", submission_id)
        return None
    
    def get_form_submissions(self, form_id: str) -> List[Dict[str, Any]]:
        """
        Get all submissions for a form.
        
        Args:
            form_id: Form identifier
        
        Returns:
            List[Dict[str, Any]]: List of submissions
        """
        logger.info("Getting all submissions for form: %s", form_id)
        
        if form_id not in self.form_submissions:
            return []
        
        return self.form_submissions[form_id]
    
    def mark_submission_processed(self, form_id: str, submission_id: str, 
                                processed: bool = True) -> bool:
        """
        Mark a form submission as processed.
        
        Args:
            form_id: Form identifier
            submission_id: Submission identifier
            processed: Whether submission is processed
        
        Returns:
            bool: True if submission was marked successfully, False otherwise
        """
        logger.info("Marking submission %s as %sprocessed", 
                  submission_id, "" if processed else "not ")
        
        if form_id not in self.form_submissions:
            logger.warning("No submissions found for form: %s", form_id)
            return False
        
        for submission in self.form_submissions[form_id]:
            if submission.get("id") == submission_id:
                submission["processed"] = processed
                
                # Notify subscribers
                self._notify_subscribers("submission_processed", {
                    "form_id": form_id,
                    "submission_id": submission_id,
                    "processed": processed
                })
                
                return True
        
        logger.warning("Submission not found: %s", submission_id)
        return False
    
    def delete_submission(self, form_id: str, submission_id: str) -> bool:
        """
        Delete a form submission.
        
        Args:
            form_id: Form identifier
            submission_id: Submission identifier
        
        Returns:
            bool: True if submission was deleted successfully, False otherwise
        """
        logger.info("Deleting submission %s for form %s", submission_id, form_id)
        
        if form_id not in self.form_submissions:
            logger.warning("No submissions found for form: %s", form_id)
            return False
        
        submissions = self.form_submissions[form_id]
        updated_submissions = [s for s in submissions if s.get("id") != submission_id]
        
        if len(submissions) == len(updated_submissions):
            logger.warning("Submission not found: %s", submission_id)
            return False
        
        # Update submissions
        self.form_submissions[form_id] = updated_submissions
        
        # Notify subscribers
        self._notify_subscribers("submission_deleted", {
            "form_id": form_id,
            "submission_id": submission_id
        })
        
        return True
    
    def create_input_form(self, title: str, fields: List[Dict[str, Any]],
                        description: Optional[str] = None,
                        layout: Optional[str] = None) -> Optional[str]:
        """
        Create an input form.
        
        Args:
            title: Form title
            fields: Form fields
            description: Optional form description
            layout: Optional form layout
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating input form: %s", title)
        
        # Create form data
        form_data = {
            "title": title,
            "type": self.TYPE_INPUT,
            "fields": fields
        }
        
        if description:
            form_data["description"] = description
        
        if layout:
            form_data["layout"] = layout
        
        # Create form
        return self.create_form(form_data)
    
    def create_decision_form(self, title: str, options: List[Dict[str, Any]],
                           description: Optional[str] = None,
                           layout: Optional[str] = None) -> Optional[str]:
        """
        Create a decision form.
        
        Args:
            title: Form title
            options: Decision options
            description: Optional form description
            layout: Optional form layout
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating decision form: %s", title)
        
        # Create decision field
        decision_field = {
            "name": "decision",
            "type": self.FIELD_SELECT,
            "label": "Decision",
            "required": True,
            "options": options
        }
        
        # Create comment field
        comment_field = {
            "name": "comment",
            "type": self.FIELD_TEXT,
            "label": "Comment",
            "required": False
        }
        
        # Create form data
        form_data = {
            "title": title,
            "type": self.TYPE_DECISION,
            "fields": [decision_field, comment_field]
        }
        
        if description:
            form_data["description"] = description
        
        if layout:
            form_data["layout"] = layout
        
        # Create form
        return self.create_form(form_data)
    
    def create_workflow_form(self, title: str, workflow_id: str,
                           fields: List[Dict[str, Any]],
                           description: Optional[str] = None,
                           layout: Optional[str] = None) -> Optional[str]:
        """
        Create a workflow form.
        
        Args:
            title: Form title
            workflow_id: Workflow identifier
            fields: Form fields
            description: Optional form description
            layout: Optional form layout
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating workflow form: %s", title)
        
        # Create form data
        form_data = {
            "title": title,
            "type": self.TYPE_WORKFLOW,
            "fields": fields,
            "metadata": {
                "workflow_id": workflow_id
            }
        }
        
        if description:
            form_data["description"] = description
        
        if layout:
            form_data["layout"] = layout
        
        # Create form
        return self.create_form(form_data)
    
    def create_configuration_form(self, title: str, config_fields: List[Dict[str, Any]],
                                description: Optional[str] = None,
                                layout: Optional[str] = None) -> Optional[str]:
        """
        Create a configuration form.
        
        Args:
            title: Form title
            config_fields: Configuration fields
            description: Optional form description
            layout: Optional form layout
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating configuration form: %s", title)
        
        # Create form data
        form_data = {
            "title": title,
            "type": self.TYPE_CONFIGURATION,
            "fields": config_fields
        }
        
        if description:
            form_data["description"] = description
        
        if layout:
            form_data["layout"] = layout
        
        # Create form
        return self.create_form(form_data)
    
    def create_survey_form(self, title: str, questions: List[Dict[str, Any]],
                         description: Optional[str] = None,
                         layout: Optional[str] = None) -> Optional[str]:
        """
        Create a survey form.
        
        Args:
            title: Form title
            questions: Survey questions
            description: Optional form description
            layout: Optional form layout
        
        Returns:
            Optional[str]: Form ID if created successfully, None otherwise
        """
        logger.info("Creating survey form: %s", title)
        
        # Create form data
        form_data = {
            "title": title,
            "type": self.TYPE_SURVEY,
            "fields": questions
        }
        
        if description:
            form_data["description"] = description
        
        if layout:
            form_data["layout"] = layout
        
        # Create form
        return self.create_form(form_data)
    
    def export_form(self, form_id: str) -> Optional[Dict[str, Any]]:
        """
        Export a form to a serializable format.
        
        Args:
            form_id: Form identifier
        
        Returns:
            Optional[Dict[str, Any]]: Exported form if successful, None otherwise
        """
        logger.info("Exporting form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return None
        
        form = self.forms[form_id]
        
        # Create export data
        export_data = {
            "form": form,
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }
        
        return export_data
    
    def import_form(self, import_data: Dict[str, Any]) -> Optional[str]:
        """
        Import a form from a serialized format.
        
        Args:
            import_data: Imported form data
        
        Returns:
            Optional[str]: Form ID if import was successful, None otherwise
        """
        logger.info("Importing form")
        
        # Validate import data
        if "form" not in import_data:
            logger.warning("Invalid import data")
            return None
        
        # Import form
        form_data = import_data["form"]
        form_id = form_data.get("id", str(uuid.uuid4()))
        form_data["id"] = form_id
        
        # Store form
        self.forms[form_id] = form_data
        
        # Set as active form
        self.set_active_form(form_id)
        
        # Notify subscribers
        self._notify_subscribers("form_imported", {
            "form_id": form_id,
            "metadata": import_data.get("metadata", {})
        })
        
        return form_id
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Check if context includes a form
        form_id = context_data.get("form_id")
        if form_id and form_id in self.forms:
            self.set_active_form(form_id)
    
    def _on_user_role_changed(self, event_data: Dict[str, Any]):
        """
        Handle user role changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("User role changed: %s", event_data)
        
        role = event_data.get("role")
        if not role:
            return
        
        # Apply adaptive rules for active form
        if self.active_form_id:
            self._apply_adaptive_rules(self.active_form_id, {"role": role})
    
    def _on_trust_level_changed(self, event_data: Dict[str, Any]):
        """
        Handle trust level changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Trust level changed: %s", event_data)
        
        trust_level = event_data.get("trust_level")
        if not trust_level:
            return
        
        # Apply adaptive rules for active form
        if self.active_form_id:
            self._apply_adaptive_rules(self.active_form_id, {"trust_level": trust_level})
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        # Handle form-related inputs
        if self.active_form_id:
            # Handle form submission shortcut
            if input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+Enter":
                # Notify subscribers
                self._notify_subscribers("form_submit_requested", {
                    "form_id": self.active_form_id
                })
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        # Handle form-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "form_request":
            # Create new form
            form_data = message.get("form_data", {})
            
            if form_data:
                form_id = self.create_form(form_data)
                
                if form_id:
                    # Set as active form
                    self.set_active_form(form_id)
        
        elif message_type == "form_submission_request":
            # Submit form
            form_id = message.get("form_id")
            form_data = message.get("form_data", {})
            
            if form_id and form_data and form_id in self.forms:
                self.submit_form(form_id, form_data)
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        # Handle form-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "form_update":
            # Update form
            form_id = message.get("form_id")
            form_data = message.get("form_data", {})
            
            if form_id and form_data and form_id in self.forms:
                self.update_form(form_id, form_data)
    
    def _apply_adaptive_rules(self, form_id: str, context: Dict[str, Any]) -> bool:
        """
        Apply adaptive rules to a form based on context.
        
        Args:
            form_id: Form identifier
            context: Context data
        
        Returns:
            bool: True if rules were applied successfully, False otherwise
        """
        logger.info("Applying adaptive rules to form: %s", form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        rules = form.get("adaptive_rules", [])
        
        if not rules:
            return True
        
        # Apply rules in priority order
        for rule in rules:
            condition = rule.get("condition")
            actions = rule.get("actions", [])
            
            # Evaluate condition
            condition_met = self._evaluate_condition(condition, context)
            
            if condition_met:
                # Apply actions
                for action in actions:
                    action_type = action.get("type")
                    action_params = action.get("params", {})
                    
                    if action_type == "show_field":
                        field_id = action_params.get("field_id")
                        section_id = action_params.get("section_id")
                        
                        if field_id:
                            self._set_field_visibility(form_id, field_id, True, section_id)
                    
                    elif action_type == "hide_field":
                        field_id = action_params.get("field_id")
                        section_id = action_params.get("section_id")
                        
                        if field_id:
                            self._set_field_visibility(form_id, field_id, False, section_id)
                    
                    elif action_type == "show_section":
                        section_id = action_params.get("section_id")
                        
                        if section_id:
                            self._set_section_visibility(form_id, section_id, True)
                    
                    elif action_type == "hide_section":
                        section_id = action_params.get("section_id")
                        
                        if section_id:
                            self._set_section_visibility(form_id, section_id, False)
                    
                    elif action_type == "set_required":
                        field_id = action_params.get("field_id")
                        section_id = action_params.get("section_id")
                        required = action_params.get("required", True)
                        
                        if field_id:
                            self._set_field_required(form_id, field_id, required, section_id)
                    
                    elif action_type == "set_validation":
                        field_id = action_params.get("field_id")
                        section_id = action_params.get("section_id")
                        validation_type = action_params.get("validation_type")
                        validation_data = action_params.get("validation_data")
                        
                        if field_id and validation_type:
                            self.add_validation(form_id, field_id, validation_type, validation_data, section_id)
                    
                    elif action_type == "set_layout":
                        layout = action_params.get("layout")
                        
                        if layout:
                            form["layout"] = layout
                            form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("adaptive_rules_applied", {
            "form_id": form_id,
            "context": context
        })
        
        return True
    
    def _evaluate_condition(self, condition: Dict[str, Any], context: Dict[str, Any]) -> bool:
        """
        Evaluate a condition based on context.
        
        Args:
            condition: Condition to evaluate
            context: Context data
        
        Returns:
            bool: True if condition is met, False otherwise
        """
        condition_type = condition.get("type")
        
        if condition_type == "role":
            # Role condition
            role = condition.get("role")
            return context.get("role") == role
        
        elif condition_type == "trust_level":
            # Trust level condition
            trust_level = condition.get("trust_level")
            operator = condition.get("operator", "==")
            
            if operator == "==":
                return context.get("trust_level") == trust_level
            elif operator == ">=":
                return context.get("trust_level") >= trust_level
            elif operator == "<=":
                return context.get("trust_level") <= trust_level
            else:
                return False
        
        elif condition_type == "field_value":
            # Field value condition
            field_name = condition.get("field_name")
            field_value = condition.get("field_value")
            operator = condition.get("operator", "==")
            
            if field_name not in context:
                return False
            
            if operator == "==":
                return context[field_name] == field_value
            elif operator == "!=":
                return context[field_name] != field_value
            elif operator == ">":
                return context[field_name] > field_value
            elif operator == ">=":
                return context[field_name] >= field_value
            elif operator == "<":
                return context[field_name] < field_value
            elif operator == "<=":
                return context[field_name] <= field_value
            elif operator == "in":
                return field_value in context[field_name]
            elif operator == "not_in":
                return field_value not in context[field_name]
            else:
                return False
        
        elif condition_type == "and":
            # AND condition
            subconditions = condition.get("conditions", [])
            return all(self._evaluate_condition(subcond, context) for subcond in subconditions)
        
        elif condition_type == "or":
            # OR condition
            subconditions = condition.get("conditions", [])
            return any(self._evaluate_condition(subcond, context) for subcond in subconditions)
        
        elif condition_type == "not":
            # NOT condition
            subcondition = condition.get("condition", {})
            return not self._evaluate_condition(subcondition, context)
        
        return False
    
    def _set_field_visibility(self, form_id: str, field_id: str, 
                            visible: bool, section_id: Optional[str] = None) -> bool:
        """
        Set field visibility.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            visible: Whether field is visible
            section_id: Optional section identifier
        
        Returns:
            bool: True if field visibility was set successfully, False otherwise
        """
        logger.info("Setting field %s visibility to %s in form %s", 
                  field_id, visible, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    for field in section.get("fields", []):
                        if field.get("id") == field_id:
                            field["hidden"] = not visible
                            field_found = True
                            break
                    
                    break
        else:
            # Find in form fields
            for field in form.get("fields", []):
                if field.get("id") == field_id:
                    field["hidden"] = not visible
                    field_found = True
                    break
        
        if not field_found:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("field_visibility_set", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id,
            "visible": visible
        })
        
        return True
    
    def _set_section_visibility(self, form_id: str, section_id: str, visible: bool) -> bool:
        """
        Set section visibility.
        
        Args:
            form_id: Form identifier
            section_id: Section identifier
            visible: Whether section is visible
        
        Returns:
            bool: True if section visibility was set successfully, False otherwise
        """
        logger.info("Setting section %s visibility to %s in form %s", 
                  section_id, visible, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find section
        section_found = False
        for section in form.get("sections", []):
            if section.get("id") == section_id:
                section["hidden"] = not visible
                section_found = True
                break
        
        if not section_found:
            logger.warning("Section not found: %s", section_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("section_visibility_set", {
            "form_id": form_id,
            "section_id": section_id,
            "visible": visible
        })
        
        return True
    
    def _set_field_required(self, form_id: str, field_id: str, 
                          required: bool, section_id: Optional[str] = None) -> bool:
        """
        Set field required status.
        
        Args:
            form_id: Form identifier
            field_id: Field identifier
            required: Whether field is required
            section_id: Optional section identifier
        
        Returns:
            bool: True if field required status was set successfully, False otherwise
        """
        logger.info("Setting field %s required status to %s in form %s", 
                  field_id, required, form_id)
        
        if form_id not in self.forms:
            logger.warning("Form not found: %s", form_id)
            return False
        
        form = self.forms[form_id]
        
        # Find field
        field_found = False
        
        if section_id:
            # Find section
            for section in form.get("sections", []):
                if section.get("id") == section_id:
                    for field in section.get("fields", []):
                        if field.get("id") == field_id:
                            field["required"] = required
                            field_found = True
                            break
                    
                    break
        else:
            # Find in form fields
            for field in form.get("fields", []):
                if field.get("id") == field_id:
                    field["required"] = required
                    field_found = True
                    break
        
        if not field_found:
            logger.warning("Field not found: %s", field_id)
            return False
        
        # Update form timestamp
        form["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("field_required_set", {
            "form_id": form_id,
            "field_id": field_id,
            "section_id": section_id,
            "required": required
        })
        
        return True
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Adaptive Form events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Adaptive Form events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
