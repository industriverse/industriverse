"""
Notification Center Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Notification Center, which provides a centralized hub for
system notifications, alerts, and messages. It supports different notification types,
priority levels, and interactive actions, with adaptive display modes based on context.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union
import json
import os
import time
import math
import uuid
from datetime import datetime

# Initialize logger
logger = logging.getLogger(__name__)

class NotificationCenter:
    """
    Notification Center component for managing and displaying system notifications,
    alerts, and messages with support for different priority levels and interactive actions.
    """
    
    # Notification priority constants
    PRIORITY_LOW = "low"
    PRIORITY_NORMAL = "normal"
    PRIORITY_HIGH = "high"
    PRIORITY_CRITICAL = "critical"
    
    # Notification type constants
    TYPE_INFO = "info"
    TYPE_SUCCESS = "success"
    TYPE_WARNING = "warning"
    TYPE_ERROR = "error"
    TYPE_SYSTEM = "system"
    TYPE_AGENT = "agent"
    TYPE_WORKFLOW = "workflow"
    TYPE_SECURITY = "security"
    
    # Notification display mode constants
    DISPLAY_TOAST = "toast"
    DISPLAY_BANNER = "banner"
    DISPLAY_MODAL = "modal"
    DISPLAY_AMBIENT = "ambient"
    DISPLAY_CAPSULE = "capsule"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Notification Center component with optional configuration."""
        self.config = config or {}
        self.notifications = {}
        self.notification_groups = {}
        self.notification_history = []
        self.unread_count = 0
        self.notification_visibility = False
        self.notification_position = {"x": 0, "y": 0}
        self.notification_anchor = "top-right"  # top-right, top-left, bottom-right, bottom-left, center
        self.notification_mode = self.DISPLAY_TOAST
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.capsule_manager = None
        self.avatar_manager = None
        self.protocol_bridge = None
        
        # Initialize notification groups
        self._initialize_groups()
        
        logger.info("Notification Center component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, capsule_manager=None, 
                  avatar_manager=None, protocol_bridge=None):
        """Initialize the Notification Center component and connect to required services."""
        logger.info("Initializing Notification Center component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.capsule_manager = capsule_manager
        self.avatar_manager = avatar_manager
        self.protocol_bridge = protocol_bridge
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        logger.info("Notification Center component initialization complete")
        return True
    
    def _initialize_groups(self):
        """Initialize notification groups with default settings."""
        logger.info("Initializing notification groups")
        
        self.notification_groups = {
            self.TYPE_INFO: {
                "id": self.TYPE_INFO,
                "name": "Information",
                "icon": "info_icon",
                "order": 0,
                "visible": True,
                "notifications": []
            },
            self.TYPE_SUCCESS: {
                "id": self.TYPE_SUCCESS,
                "name": "Success",
                "icon": "success_icon",
                "order": 1,
                "visible": True,
                "notifications": []
            },
            self.TYPE_WARNING: {
                "id": self.TYPE_WARNING,
                "name": "Warnings",
                "icon": "warning_icon",
                "order": 2,
                "visible": True,
                "notifications": []
            },
            self.TYPE_ERROR: {
                "id": self.TYPE_ERROR,
                "name": "Errors",
                "icon": "error_icon",
                "order": 3,
                "visible": True,
                "notifications": []
            },
            self.TYPE_SYSTEM: {
                "id": self.TYPE_SYSTEM,
                "name": "System",
                "icon": "system_icon",
                "order": 4,
                "visible": True,
                "notifications": []
            },
            self.TYPE_AGENT: {
                "id": self.TYPE_AGENT,
                "name": "Agents",
                "icon": "agent_icon",
                "order": 5,
                "visible": True,
                "notifications": []
            },
            self.TYPE_WORKFLOW: {
                "id": self.TYPE_WORKFLOW,
                "name": "Workflows",
                "icon": "workflow_icon",
                "order": 6,
                "visible": True,
                "notifications": []
            },
            self.TYPE_SECURITY: {
                "id": self.TYPE_SECURITY,
                "name": "Security",
                "icon": "security_icon",
                "order": 7,
                "visible": True,
                "notifications": []
            }
        }
    
    def create_notification(self, notification_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new notification.
        
        Args:
            notification_data: Notification data
        
        Returns:
            Optional[str]: Notification ID if created successfully, None otherwise
        """
        logger.info("Creating notification: %s", notification_data.get("title", ""))
        
        # Validate required fields
        required_fields = ["title", "type"]
        for field in required_fields:
            if field not in notification_data:
                logger.warning("Missing required field in notification: %s", field)
                return None
        
        # Generate notification ID
        notification_id = notification_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "message" not in notification_data:
            notification_data["message"] = ""
        
        if "priority" not in notification_data:
            notification_data["priority"] = self.PRIORITY_NORMAL
        
        if "timestamp" not in notification_data:
            notification_data["timestamp"] = datetime.now().isoformat()
        
        if "read" not in notification_data:
            notification_data["read"] = False
        
        if "dismissed" not in notification_data:
            notification_data["dismissed"] = False
        
        if "actions" not in notification_data:
            notification_data["actions"] = []
        
        if "display_mode" not in notification_data:
            # Set display mode based on priority
            if notification_data["priority"] == self.PRIORITY_CRITICAL:
                notification_data["display_mode"] = self.DISPLAY_MODAL
            elif notification_data["priority"] == self.PRIORITY_HIGH:
                notification_data["display_mode"] = self.DISPLAY_BANNER
            else:
                notification_data["display_mode"] = self.DISPLAY_TOAST
        
        if "duration" not in notification_data:
            # Set duration based on priority and display mode
            if notification_data["display_mode"] == self.DISPLAY_TOAST:
                if notification_data["priority"] == self.PRIORITY_LOW:
                    notification_data["duration"] = 3000  # 3 seconds
                elif notification_data["priority"] == self.PRIORITY_NORMAL:
                    notification_data["duration"] = 5000  # 5 seconds
                else:
                    notification_data["duration"] = 8000  # 8 seconds
            else:
                notification_data["duration"] = 0  # No auto-dismiss
        
        if "source" not in notification_data:
            notification_data["source"] = "system"
        
        if "source_id" not in notification_data:
            notification_data["source_id"] = ""
        
        if "group_id" not in notification_data:
            notification_data["group_id"] = ""
        
        if "metadata" not in notification_data:
            notification_data["metadata"] = {}
        
        # Store notification
        notification_data["id"] = notification_id
        self.notifications[notification_id] = notification_data
        
        # Add to notification history
        self.notification_history.append(notification_id)
        
        # Limit history size
        max_history = 100
        if len(self.notification_history) > max_history:
            old_notification_id = self.notification_history.pop(0)
            if old_notification_id in self.notifications:
                # Only remove from history, not from active notifications
                pass
        
        # Add to notification group
        notification_type = notification_data["type"]
        if notification_type in self.notification_groups:
            self.notification_groups[notification_type]["notifications"].append(notification_id)
        
        # Update unread count
        if not notification_data["read"]:
            self.unread_count += 1
        
        # Notify subscribers
        self._notify_subscribers("notification_created", {
            "notification_id": notification_id,
            "notification": notification_data
        })
        
        # Display notification based on display mode
        self._display_notification(notification_id)
        
        return notification_id
    
    def update_notification(self, notification_id: str, update_data: Dict[str, Any]) -> bool:
        """
        Update an existing notification.
        
        Args:
            notification_id: Notification identifier
            update_data: Data to update
        
        Returns:
            bool: True if notification was updated successfully, False otherwise
        """
        logger.info("Updating notification: %s", notification_id)
        
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        
        # Update fields
        for key, value in update_data.items():
            # Special handling for read status
            if key == "read" and value and not notification["read"]:
                self.unread_count = max(0, self.unread_count - 1)
            
            notification[key] = value
        
        # Notify subscribers
        self._notify_subscribers("notification_updated", {
            "notification_id": notification_id,
            "notification": notification,
            "update_data": update_data
        })
        
        return True
    
    def delete_notification(self, notification_id: str) -> bool:
        """
        Delete a notification.
        
        Args:
            notification_id: Notification identifier
        
        Returns:
            bool: True if notification was deleted successfully, False otherwise
        """
        logger.info("Deleting notification: %s", notification_id)
        
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        
        # Update unread count
        if not notification["read"]:
            self.unread_count = max(0, self.unread_count - 1)
        
        # Remove from notification group
        notification_type = notification["type"]
        if notification_type in self.notification_groups:
            if notification_id in self.notification_groups[notification_type]["notifications"]:
                self.notification_groups[notification_type]["notifications"].remove(notification_id)
        
        # Remove from notifications
        del self.notifications[notification_id]
        
        # Notify subscribers
        self._notify_subscribers("notification_deleted", {
            "notification_id": notification_id
        })
        
        return True
    
    def get_notification(self, notification_id: str) -> Optional[Dict[str, Any]]:
        """
        Get notification by ID.
        
        Args:
            notification_id: Notification identifier
        
        Returns:
            Optional[Dict[str, Any]]: Notification if found, None otherwise
        """
        if notification_id in self.notifications:
            return self.notifications[notification_id]
        else:
            logger.warning("Notification not found: %s", notification_id)
            return None
    
    def get_notifications_by_type(self, notification_type: str) -> List[Dict[str, Any]]:
        """
        Get notifications by type.
        
        Args:
            notification_type: Notification type
        
        Returns:
            List[Dict[str, Any]]: List of notifications of the specified type
        """
        if notification_type not in self.notification_groups:
            logger.warning("Notification type not found: %s", notification_type)
            return []
        
        # Get notification IDs in group
        notification_ids = self.notification_groups[notification_type]["notifications"]
        
        # Get notifications
        notifications = []
        for notification_id in notification_ids:
            if notification_id in self.notifications:
                notifications.append(self.notifications[notification_id])
        
        # Sort by timestamp (newest first)
        notifications.sort(key=lambda n: n.get("timestamp", ""), reverse=True)
        
        return notifications
    
    def get_notifications_by_priority(self, priority: str) -> List[Dict[str, Any]]:
        """
        Get notifications by priority.
        
        Args:
            priority: Notification priority
        
        Returns:
            List[Dict[str, Any]]: List of notifications with the specified priority
        """
        # Get notifications with matching priority
        notifications = [n for n in self.notifications.values() if n.get("priority") == priority]
        
        # Sort by timestamp (newest first)
        notifications.sort(key=lambda n: n.get("timestamp", ""), reverse=True)
        
        return notifications
    
    def get_all_notifications(self) -> List[Dict[str, Any]]:
        """
        Get all notifications.
        
        Returns:
            List[Dict[str, Any]]: List of all notifications
        """
        # Get all notifications
        notifications = list(self.notifications.values())
        
        # Sort by timestamp (newest first)
        notifications.sort(key=lambda n: n.get("timestamp", ""), reverse=True)
        
        return notifications
    
    def get_unread_notifications(self) -> List[Dict[str, Any]]:
        """
        Get unread notifications.
        
        Returns:
            List[Dict[str, Any]]: List of unread notifications
        """
        # Get unread notifications
        notifications = [n for n in self.notifications.values() if not n.get("read", False)]
        
        # Sort by timestamp (newest first)
        notifications.sort(key=lambda n: n.get("timestamp", ""), reverse=True)
        
        return notifications
    
    def get_notification_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get notification history.
        
        Args:
            limit: Maximum number of notifications to return
        
        Returns:
            List[Dict[str, Any]]: List of notifications in history
        """
        # Get notification IDs from history
        notification_ids = self.notification_history[-limit:]
        
        # Get notifications
        notifications = []
        for notification_id in reversed(notification_ids):
            if notification_id in self.notifications:
                notifications.append(self.notifications[notification_id])
        
        return notifications
    
    def mark_as_read(self, notification_id: str) -> bool:
        """
        Mark a notification as read.
        
        Args:
            notification_id: Notification identifier
        
        Returns:
            bool: True if notification was marked as read successfully, False otherwise
        """
        logger.info("Marking notification as read: %s", notification_id)
        
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        
        # Check if already read
        if notification.get("read", False):
            return True
        
        # Update read status
        notification["read"] = True
        
        # Update unread count
        self.unread_count = max(0, self.unread_count - 1)
        
        # Notify subscribers
        self._notify_subscribers("notification_read", {
            "notification_id": notification_id,
            "notification": notification
        })
        
        return True
    
    def mark_all_as_read(self) -> bool:
        """
        Mark all notifications as read.
        
        Returns:
            bool: True if all notifications were marked as read successfully, False otherwise
        """
        logger.info("Marking all notifications as read")
        
        # Update read status for all notifications
        for notification_id, notification in self.notifications.items():
            if not notification.get("read", False):
                notification["read"] = True
        
        # Reset unread count
        self.unread_count = 0
        
        # Notify subscribers
        self._notify_subscribers("all_notifications_read", {})
        
        return True
    
    def dismiss_notification(self, notification_id: str) -> bool:
        """
        Dismiss a notification.
        
        Args:
            notification_id: Notification identifier
        
        Returns:
            bool: True if notification was dismissed successfully, False otherwise
        """
        logger.info("Dismissing notification: %s", notification_id)
        
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        
        # Check if already dismissed
        if notification.get("dismissed", False):
            return True
        
        # Update dismissed status
        notification["dismissed"] = True
        
        # Mark as read if not already
        if not notification.get("read", False):
            notification["read"] = True
            self.unread_count = max(0, self.unread_count - 1)
        
        # Notify subscribers
        self._notify_subscribers("notification_dismissed", {
            "notification_id": notification_id,
            "notification": notification
        })
        
        return True
    
    def dismiss_all_notifications(self) -> bool:
        """
        Dismiss all notifications.
        
        Returns:
            bool: True if all notifications were dismissed successfully, False otherwise
        """
        logger.info("Dismissing all notifications")
        
        # Update dismissed status for all notifications
        for notification_id, notification in self.notifications.items():
            if not notification.get("dismissed", False):
                notification["dismissed"] = True
                
                # Mark as read if not already
                if not notification.get("read", False):
                    notification["read"] = True
        
        # Reset unread count
        self.unread_count = 0
        
        # Notify subscribers
        self._notify_subscribers("all_notifications_dismissed", {})
        
        return True
    
    def execute_notification_action(self, notification_id: str, action_id: str, 
                                   params: Optional[Dict[str, Any]] = None) -> bool:
        """
        Execute a notification action.
        
        Args:
            notification_id: Notification identifier
            action_id: Action identifier
            params: Optional parameters for the action
        
        Returns:
            bool: True if action was executed successfully, False otherwise
        """
        logger.info("Executing notification action: %s -> %s", notification_id, action_id)
        
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        
        # Find action with matching ID
        action = None
        for a in notification.get("actions", []):
            if a.get("id") == action_id:
                action = a
                break
        
        if not action:
            logger.warning("Action not found: %s", action_id)
            return False
        
        # Execute action handler
        handler = action.get("handler")
        if not handler:
            logger.warning("Action handler not found: %s", action_id)
            return False
        
        try:
            result = handler(params or {})
            
            # Notify subscribers
            self._notify_subscribers("notification_action_executed", {
                "notification_id": notification_id,
                "action_id": action_id,
                "params": params,
                "result": result
            })
            
            return True
        except Exception as e:
            logger.error("Error executing notification action: %s - %s", action_id, e)
            return False
    
    def show_notification_center(self, position: Optional[Dict[str, float]] = None, 
                               anchor: Optional[str] = None) -> bool:
        """
        Show the notification center.
        
        Args:
            position: Optional position for the notification center
            anchor: Optional anchor point for the notification center
        
        Returns:
            bool: True if notification center was shown successfully, False otherwise
        """
        logger.info("Showing notification center")
        
        # Update notification center properties
        if position:
            self.notification_position = position
        
        if anchor:
            self.notification_anchor = anchor
        
        # Show notification center
        self.notification_visibility = True
        
        # Notify subscribers
        self._notify_subscribers("notification_center_shown", {
            "position": self.notification_position,
            "anchor": self.notification_anchor
        })
        
        return True
    
    def hide_notification_center(self) -> bool:
        """
        Hide the notification center.
        
        Returns:
            bool: True if notification center was hidden successfully, False otherwise
        """
        logger.info("Hiding notification center")
        
        # Hide notification center
        self.notification_visibility = False
        
        # Notify subscribers
        self._notify_subscribers("notification_center_hidden", {})
        
        return True
    
    def is_notification_center_visible(self) -> bool:
        """
        Check if notification center is visible.
        
        Returns:
            bool: True if notification center is visible, False otherwise
        """
        return self.notification_visibility
    
    def get_unread_count(self) -> int:
        """
        Get unread notification count.
        
        Returns:
            int: Number of unread notifications
        """
        return self.unread_count
    
    def set_notification_group_visibility(self, group_id: str, visible: bool) -> bool:
        """
        Set visibility of a notification group.
        
        Args:
            group_id: Group identifier
            visible: Whether group should be visible
        
        Returns:
            bool: True if visibility was set successfully, False otherwise
        """
        logger.info("Setting notification group visibility: %s -> %s", group_id, visible)
        
        if group_id not in self.notification_groups:
            logger.warning("Notification group not found: %s", group_id)
            return False
        
        self.notification_groups[group_id]["visible"] = visible
        
        # Notify subscribers
        self._notify_subscribers("notification_group_visibility_changed", {
            "group_id": group_id,
            "visible": visible
        })
        
        return True
    
    def get_notification_group_visibility(self, group_id: str) -> Optional[bool]:
        """
        Get visibility of a notification group.
        
        Args:
            group_id: Group identifier
        
        Returns:
            Optional[bool]: Whether group is visible if found, None otherwise
        """
        if group_id not in self.notification_groups:
            logger.warning("Notification group not found: %s", group_id)
            return None
        
        return self.notification_groups[group_id]["visible"]
    
    def get_all_notification_groups(self) -> List[Dict[str, Any]]:
        """
        Get all notification groups.
        
        Returns:
            List[Dict[str, Any]]: List of all notification groups
        """
        # Convert to list and sort by order
        groups = list(self.notification_groups.values())
        groups.sort(key=lambda g: g.get("order", 0))
        
        return groups
    
    def _display_notification(self, notification_id: str) -> bool:
        """
        Display a notification based on its display mode.
        
        Args:
            notification_id: Notification identifier
        
        Returns:
            bool: True if notification was displayed successfully, False otherwise
        """
        if notification_id not in self.notifications:
            logger.warning("Notification not found: %s", notification_id)
            return False
        
        notification = self.notifications[notification_id]
        display_mode = notification.get("display_mode", self.DISPLAY_TOAST)
        
        # Notify subscribers
        self._notify_subscribers("notification_displayed", {
            "notification_id": notification_id,
            "notification": notification,
            "display_mode": display_mode
        })
        
        # Handle different display modes
        if display_mode == self.DISPLAY_TOAST:
            # Auto-dismiss after duration
            duration = notification.get("duration", 5000)
            if duration > 0:
                # Schedule auto-dismiss
                # In a real implementation, this would use a timer or similar mechanism
                pass
        
        elif display_mode == self.DISPLAY_MODAL:
            # Show modal dialog
            if self.universal_skin_shell:
                self.universal_skin_shell.show_modal("notification", {
                    "notification_id": notification_id,
                    "notification": notification
                })
        
        elif display_mode == self.DISPLAY_CAPSULE:
            # Create notification capsule
            if self.capsule_manager:
                self.capsule_manager.create_capsule("notification", {
                    "notification_id": notification_id,
                    "notification": notification
                })
        
        return True
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        # Adapt notification display based on context
        context_type = event_data.get("context_type")
        
        if context_type == "focused":
            # In focused context, use ambient notifications
            self.notification_mode = self.DISPLAY_AMBIENT
        elif context_type == "alert":
            # In alert context, use banner notifications
            self.notification_mode = self.DISPLAY_BANNER
        else:
            # Default to toast notifications
            self.notification_mode = self.DISPLAY_TOAST
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        # Handle notification center toggle
        if input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+N":
            if self.notification_visibility:
                self.hide_notification_center()
            else:
                self.show_notification_center()
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        # Check if message is a notification
        if message_type == "notification":
            # Create notification from message
            notification_data = {
                "title": message.get("title", "MCP Notification"),
                "message": message.get("content", ""),
                "type": message.get("notification_type", self.TYPE_SYSTEM),
                "priority": message.get("priority", self.PRIORITY_NORMAL),
                "source": "mcp",
                "source_id": message.get("source_id", ""),
                "metadata": message.get("metadata", {})
            }
            
            self.create_notification(notification_data)
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        # Check if message is a notification
        if message_type == "notification":
            # Create notification from message
            notification_data = {
                "title": message.get("title", "Agent Notification"),
                "message": message.get("content", ""),
                "type": self.TYPE_AGENT,
                "priority": message.get("priority", self.PRIORITY_NORMAL),
                "source": "a2a",
                "source_id": message.get("agent_id", ""),
                "metadata": message.get("metadata", {})
            }
            
            self.create_notification(notification_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Notification Center events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Notification Center events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
