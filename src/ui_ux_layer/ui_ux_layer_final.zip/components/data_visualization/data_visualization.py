"""
Data Visualization Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Data Visualization system, which provides interactive,
context-aware data visualizations that adapt to user roles, device capabilities,
and trust levels. It supports multiple visualization types and integrates with
the Data Layer and Core AI Layer for real-time data processing and insights.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import math
import uuid
from datetime import datetime

# Initialize logger
logger = logging.getLogger(__name__)

class DataVisualization:
    """
    Data Visualization component for creating interactive, context-aware data
    visualizations that adapt to user roles, device capabilities, and trust levels.
    """
    
    # Visualization type constants
    TYPE_CHART = "chart"
    TYPE_GRAPH = "graph"
    TYPE_MAP = "map"
    TYPE_TABLE = "table"
    TYPE_MATRIX = "matrix"
    TYPE_TIMELINE = "timeline"
    TYPE_DASHBOARD = "dashboard"
    
    # Chart type constants
    CHART_LINE = "line"
    CHART_BAR = "bar"
    CHART_PIE = "pie"
    CHART_SCATTER = "scatter"
    CHART_AREA = "area"
    CHART_RADAR = "radar"
    CHART_HEATMAP = "heatmap"
    CHART_CANDLESTICK = "candlestick"
    
    # Interaction mode constants
    MODE_VIEW = "view"
    MODE_EXPLORE = "explore"
    MODE_ANALYZE = "analyze"
    MODE_EDIT = "edit"
    
    # Data source type constants
    SOURCE_STATIC = "static"
    SOURCE_STREAMING = "streaming"
    SOURCE_API = "api"
    SOURCE_DATABASE = "database"
    SOURCE_FILE = "file"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Data Visualization component with optional configuration."""
        self.config = config or {}
        self.visualizations = {}
        self.active_visualization_id = None
        self.data_sources = {}
        self.datasets = {}
        self.interaction_mode = self.MODE_VIEW
        self.trust_threshold = 0.7  # 0.0 to 1.0
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.protocol_bridge = None
        self.rendering_engine = None
        self.data_layer = None
        self.core_ai_layer = None
        
        logger.info("Data Visualization component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, protocol_bridge=None, 
                  rendering_engine=None, data_layer=None, core_ai_layer=None):
        """Initialize the Data Visualization component and connect to required services."""
        logger.info("Initializing Data Visualization component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.protocol_bridge = protocol_bridge
        self.rendering_engine = rendering_engine
        self.data_layer = data_layer
        self.core_ai_layer = core_ai_layer
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        if self.data_layer:
            self.data_layer.subscribe_to_events("data_updated", self._on_data_updated)
        
        logger.info("Data Visualization component initialization complete")
        return True
    
    def create_visualization(self, visualization_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new visualization.
        
        Args:
            visualization_data: Visualization data
        
        Returns:
            Optional[str]: Visualization ID if created successfully, None otherwise
        """
        logger.info("Creating visualization: %s", visualization_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type"]
        for field in required_fields:
            if field not in visualization_data:
                logger.warning("Missing required field in visualization: %s", field)
                return None
        
        # Generate visualization ID
        visualization_id = visualization_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in visualization_data:
            visualization_data["description"] = ""
        
        if "config" not in visualization_data:
            visualization_data["config"] = {}
        
        if "data_source_id" not in visualization_data:
            visualization_data["data_source_id"] = None
        
        if "dataset_id" not in visualization_data:
            visualization_data["dataset_id"] = None
        
        if "created_at" not in visualization_data:
            visualization_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in visualization_data:
            visualization_data["updated_at"] = datetime.now().isoformat()
        
        if "metadata" not in visualization_data:
            visualization_data["metadata"] = {}
        
        if "trust_level" not in visualization_data:
            visualization_data["trust_level"] = 0.5
        
        # Store visualization
        visualization_data["id"] = visualization_id
        self.visualizations[visualization_id] = visualization_data
        
        # Set as active visualization if this is the first one
        if len(self.visualizations) == 1:
            self.active_visualization_id = visualization_id
        
        # Notify subscribers
        self._notify_subscribers("visualization_created", {
            "visualization_id": visualization_id,
            "visualization": visualization_data
        })
        
        return visualization_id
    
    def update_visualization(self, visualization_id: str, visualization_data: Dict[str, Any]) -> bool:
        """
        Update an existing visualization.
        
        Args:
            visualization_id: Visualization identifier
            visualization_data: Updated visualization data
        
        Returns:
            bool: True if visualization was updated successfully, False otherwise
        """
        logger.info("Updating visualization: %s", visualization_id)
        
        if visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return False
        
        # Get current visualization data
        current_data = self.visualizations[visualization_id]
        
        # Update fields
        for key, value in visualization_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("visualization_updated", {
            "visualization_id": visualization_id,
            "visualization": current_data
        })
        
        return True
    
    def delete_visualization(self, visualization_id: str) -> bool:
        """
        Delete a visualization.
        
        Args:
            visualization_id: Visualization identifier
        
        Returns:
            bool: True if visualization was deleted successfully, False otherwise
        """
        logger.info("Deleting visualization: %s", visualization_id)
        
        if visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return False
        
        # Remove visualization
        del self.visualizations[visualization_id]
        
        # Update active visualization if this was the active one
        if self.active_visualization_id == visualization_id:
            if self.visualizations:
                self.active_visualization_id = next(iter(self.visualizations))
            else:
                self.active_visualization_id = None
        
        # Notify subscribers
        self._notify_subscribers("visualization_deleted", {
            "visualization_id": visualization_id
        })
        
        return True
    
    def get_visualization(self, visualization_id: str) -> Optional[Dict[str, Any]]:
        """
        Get visualization by ID.
        
        Args:
            visualization_id: Visualization identifier
        
        Returns:
            Optional[Dict[str, Any]]: Visualization if found, None otherwise
        """
        if visualization_id in self.visualizations:
            return self.visualizations[visualization_id]
        else:
            logger.warning("Visualization not found: %s", visualization_id)
            return None
    
    def get_all_visualizations(self) -> List[Dict[str, Any]]:
        """
        Get all visualizations.
        
        Returns:
            List[Dict[str, Any]]: List of all visualizations
        """
        return list(self.visualizations.values())
    
    def set_active_visualization(self, visualization_id: Optional[str]) -> bool:
        """
        Set the active visualization.
        
        Args:
            visualization_id: Visualization identifier, or None to clear active visualization
        
        Returns:
            bool: True if active visualization was set successfully, False otherwise
        """
        logger.info("Setting active visualization: %s", visualization_id)
        
        if visualization_id is not None and visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return False
        
        previous_visualization_id = self.active_visualization_id
        self.active_visualization_id = visualization_id
        
        # Notify subscribers
        self._notify_subscribers("active_visualization_changed", {
            "previous_visualization_id": previous_visualization_id,
            "visualization_id": visualization_id
        })
        
        return True
    
    def get_active_visualization(self) -> Optional[Dict[str, Any]]:
        """
        Get the active visualization.
        
        Returns:
            Optional[Dict[str, Any]]: Active visualization if set, None otherwise
        """
        if self.active_visualization_id is not None and self.active_visualization_id in self.visualizations:
            return self.visualizations[self.active_visualization_id]
        else:
            return None
    
    def register_data_source(self, data_source: Dict[str, Any]) -> Optional[str]:
        """
        Register a new data source.
        
        Args:
            data_source: Data source configuration
        
        Returns:
            Optional[str]: Data source ID if registered successfully, None otherwise
        """
        logger.info("Registering data source: %s", data_source.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type"]
        for field in required_fields:
            if field not in data_source:
                logger.warning("Missing required field in data source: %s", field)
                return None
        
        # Generate data source ID
        data_source_id = data_source.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in data_source:
            data_source["description"] = ""
        
        if "config" not in data_source:
            data_source["config"] = {}
        
        if "created_at" not in data_source:
            data_source["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in data_source:
            data_source["updated_at"] = datetime.now().isoformat()
        
        if "metadata" not in data_source:
            data_source["metadata"] = {}
        
        if "trust_level" not in data_source:
            data_source["trust_level"] = 0.5
        
        # Store data source
        data_source["id"] = data_source_id
        self.data_sources[data_source_id] = data_source
        
        # Notify subscribers
        self._notify_subscribers("data_source_registered", {
            "data_source_id": data_source_id,
            "data_source": data_source
        })
        
        return data_source_id
    
    def unregister_data_source(self, data_source_id: str) -> bool:
        """
        Unregister a data source.
        
        Args:
            data_source_id: Data source identifier
        
        Returns:
            bool: True if data source was unregistered successfully, False otherwise
        """
        logger.info("Unregistering data source: %s", data_source_id)
        
        if data_source_id not in self.data_sources:
            logger.warning("Data source not found: %s", data_source_id)
            return False
        
        # Remove data source
        del self.data_sources[data_source_id]
        
        # Update visualizations using this data source
        for viz_id, viz in self.visualizations.items():
            if viz.get("data_source_id") == data_source_id:
                viz["data_source_id"] = None
        
        # Notify subscribers
        self._notify_subscribers("data_source_unregistered", {
            "data_source_id": data_source_id
        })
        
        return True
    
    def get_data_source(self, data_source_id: str) -> Optional[Dict[str, Any]]:
        """
        Get data source by ID.
        
        Args:
            data_source_id: Data source identifier
        
        Returns:
            Optional[Dict[str, Any]]: Data source if found, None otherwise
        """
        if data_source_id in self.data_sources:
            return self.data_sources[data_source_id]
        else:
            logger.warning("Data source not found: %s", data_source_id)
            return None
    
    def get_all_data_sources(self) -> List[Dict[str, Any]]:
        """
        Get all data sources.
        
        Returns:
            List[Dict[str, Any]]: List of all data sources
        """
        return list(self.data_sources.values())
    
    def create_dataset(self, dataset_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new dataset.
        
        Args:
            dataset_data: Dataset data
        
        Returns:
            Optional[str]: Dataset ID if created successfully, None otherwise
        """
        logger.info("Creating dataset: %s", dataset_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "data"]
        for field in required_fields:
            if field not in dataset_data:
                logger.warning("Missing required field in dataset: %s", field)
                return None
        
        # Generate dataset ID
        dataset_id = dataset_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in dataset_data:
            dataset_data["description"] = ""
        
        if "schema" not in dataset_data:
            dataset_data["schema"] = {}
        
        if "created_at" not in dataset_data:
            dataset_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in dataset_data:
            dataset_data["updated_at"] = datetime.now().isoformat()
        
        if "metadata" not in dataset_data:
            dataset_data["metadata"] = {}
        
        if "trust_level" not in dataset_data:
            dataset_data["trust_level"] = 0.5
        
        # Store dataset
        dataset_data["id"] = dataset_id
        self.datasets[dataset_id] = dataset_data
        
        # Notify subscribers
        self._notify_subscribers("dataset_created", {
            "dataset_id": dataset_id,
            "dataset": dataset_data
        })
        
        return dataset_id
    
    def update_dataset(self, dataset_id: str, dataset_data: Dict[str, Any]) -> bool:
        """
        Update an existing dataset.
        
        Args:
            dataset_id: Dataset identifier
            dataset_data: Updated dataset data
        
        Returns:
            bool: True if dataset was updated successfully, False otherwise
        """
        logger.info("Updating dataset: %s", dataset_id)
        
        if dataset_id not in self.datasets:
            logger.warning("Dataset not found: %s", dataset_id)
            return False
        
        # Get current dataset data
        current_data = self.datasets[dataset_id]
        
        # Update fields
        for key, value in dataset_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("dataset_updated", {
            "dataset_id": dataset_id,
            "dataset": current_data
        })
        
        return True
    
    def delete_dataset(self, dataset_id: str) -> bool:
        """
        Delete a dataset.
        
        Args:
            dataset_id: Dataset identifier
        
        Returns:
            bool: True if dataset was deleted successfully, False otherwise
        """
        logger.info("Deleting dataset: %s", dataset_id)
        
        if dataset_id not in self.datasets:
            logger.warning("Dataset not found: %s", dataset_id)
            return False
        
        # Remove dataset
        del self.datasets[dataset_id]
        
        # Update visualizations using this dataset
        for viz_id, viz in self.visualizations.items():
            if viz.get("dataset_id") == dataset_id:
                viz["dataset_id"] = None
        
        # Notify subscribers
        self._notify_subscribers("dataset_deleted", {
            "dataset_id": dataset_id
        })
        
        return True
    
    def get_dataset(self, dataset_id: str) -> Optional[Dict[str, Any]]:
        """
        Get dataset by ID.
        
        Args:
            dataset_id: Dataset identifier
        
        Returns:
            Optional[Dict[str, Any]]: Dataset if found, None otherwise
        """
        if dataset_id in self.datasets:
            return self.datasets[dataset_id]
        else:
            logger.warning("Dataset not found: %s", dataset_id)
            return None
    
    def get_all_datasets(self) -> List[Dict[str, Any]]:
        """
        Get all datasets.
        
        Returns:
            List[Dict[str, Any]]: List of all datasets
        """
        return list(self.datasets.values())
    
    def fetch_data_from_source(self, data_source_id: str, query: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Fetch data from a data source.
        
        Args:
            data_source_id: Data source identifier
            query: Optional query parameters
        
        Returns:
            Optional[Dict[str, Any]]: Fetched data if successful, None otherwise
        """
        logger.info("Fetching data from source: %s", data_source_id)
        
        if data_source_id not in self.data_sources:
            logger.warning("Data source not found: %s", data_source_id)
            return None
        
        data_source = self.data_sources[data_source_id]
        source_type = data_source.get("type")
        
        # Check trust level
        trust_level = data_source.get("trust_level", 0.0)
        if trust_level < self.trust_threshold:
            logger.warning("Insufficient trust level for data source: %.2f < %.2f",
                         trust_level, self.trust_threshold)
            return None
        
        # Fetch data based on source type
        if source_type == self.SOURCE_STATIC:
            # Static data is stored in the data source config
            return data_source.get("config", {}).get("data", {})
        
        elif source_type == self.SOURCE_API:
            # Fetch data from API
            if not self.data_layer:
                logger.warning("Data Layer not available")
                return None
            
            try:
                api_config = data_source.get("config", {})
                result = self.data_layer.fetch_from_api(
                    api_config.get("url"),
                    api_config.get("method", "GET"),
                    api_config.get("headers", {}),
                    query or {}
                )
                
                return {"data": result}
            except Exception as e:
                logger.error("Error fetching data from API: %s", e)
                return None
        
        elif source_type == self.SOURCE_DATABASE:
            # Fetch data from database
            if not self.data_layer:
                logger.warning("Data Layer not available")
                return None
            
            try:
                db_config = data_source.get("config", {})
                result = self.data_layer.fetch_from_database(
                    db_config.get("connection_string"),
                    db_config.get("query"),
                    query or {}
                )
                
                return {"data": result}
            except Exception as e:
                logger.error("Error fetching data from database: %s", e)
                return None
        
        elif source_type == self.SOURCE_FILE:
            # Fetch data from file
            if not self.data_layer:
                logger.warning("Data Layer not available")
                return None
            
            try:
                file_config = data_source.get("config", {})
                result = self.data_layer.fetch_from_file(
                    file_config.get("path"),
                    file_config.get("format", "json")
                )
                
                return {"data": result}
            except Exception as e:
                logger.error("Error fetching data from file: %s", e)
                return None
        
        elif source_type == self.SOURCE_STREAMING:
            # Streaming data sources are handled through events
            logger.warning("Streaming data sources must be handled through events")
            return None
        
        else:
            logger.warning("Unsupported data source type: %s", source_type)
            return None
    
    def process_data_with_ai(self, data: Dict[str, Any], processing_type: str, 
                           params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Process data using the Core AI Layer.
        
        Args:
            data: Data to process
            processing_type: Type of processing to perform
            params: Optional processing parameters
        
        Returns:
            Optional[Dict[str, Any]]: Processed data if successful, None otherwise
        """
        logger.info("Processing data with AI: %s", processing_type)
        
        if not self.core_ai_layer:
            logger.warning("Core AI Layer not available")
            return None
        
        try:
            result = self.core_ai_layer.process_data(data, processing_type, params or {})
            return result
        except Exception as e:
            logger.error("Error processing data with AI: %s", e)
            return None
    
    def render_visualization(self, visualization_id: str, 
                           params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Render a visualization.
        
        Args:
            visualization_id: Visualization identifier
            params: Optional rendering parameters
        
        Returns:
            Optional[Dict[str, Any]]: Rendering result if successful, None otherwise
        """
        logger.info("Rendering visualization: %s", visualization_id)
        
        if visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return None
        
        visualization = self.visualizations[visualization_id]
        
        # Get data
        data = None
        
        # Try to get data from dataset
        dataset_id = visualization.get("dataset_id")
        if dataset_id:
            dataset = self.get_dataset(dataset_id)
            if dataset:
                data = dataset.get("data")
        
        # If no data from dataset, try to fetch from data source
        if not data:
            data_source_id = visualization.get("data_source_id")
            if data_source_id:
                result = self.fetch_data_from_source(data_source_id, params)
                if result:
                    data = result.get("data")
        
        if not data:
            logger.warning("No data available for visualization: %s", visualization_id)
            return None
        
        # Process data with AI if needed
        if params and params.get("apply_ai_processing"):
            processing_type = params.get("ai_processing_type", "analyze")
            processed_data = self.process_data_with_ai(data, processing_type, params)
            if processed_data:
                data = processed_data
        
        # Prepare rendering result
        viz_type = visualization.get("type")
        viz_config = visualization.get("config", {})
        
        # Combine with rendering parameters
        if params:
            for key, value in params.items():
                if key not in ["apply_ai_processing", "ai_processing_type"]:
                    viz_config[key] = value
        
        result = {
            "id": visualization_id,
            "type": viz_type,
            "config": viz_config,
            "data": data
        }
        
        # Notify subscribers
        self._notify_subscribers("visualization_rendered", {
            "visualization_id": visualization_id,
            "result": result
        })
        
        return result
    
    def set_interaction_mode(self, mode: str) -> bool:
        """
        Set the interaction mode.
        
        Args:
            mode: Interaction mode
        
        Returns:
            bool: True if interaction mode was set successfully, False otherwise
        """
        logger.info("Setting interaction mode: %s", mode)
        
        valid_modes = [
            self.MODE_VIEW,
            self.MODE_EXPLORE,
            self.MODE_ANALYZE,
            self.MODE_EDIT
        ]
        
        if mode not in valid_modes:
            logger.warning("Invalid interaction mode: %s", mode)
            return False
        
        self.interaction_mode = mode
        
        # Notify subscribers
        self._notify_subscribers("interaction_mode_changed", {
            "mode": mode
        })
        
        return True
    
    def get_interaction_mode(self) -> str:
        """
        Get the current interaction mode.
        
        Returns:
            str: Current interaction mode
        """
        return self.interaction_mode
    
    def set_trust_threshold(self, threshold: float) -> bool:
        """
        Set the trust threshold for data sources.
        
        Args:
            threshold: Trust threshold (0.0 to 1.0)
        
        Returns:
            bool: True if trust threshold was set successfully, False otherwise
        """
        logger.info("Setting trust threshold: %s", threshold)
        
        # Clamp threshold to valid range
        threshold = max(0.0, min(1.0, threshold))
        
        self.trust_threshold = threshold
        
        # Notify subscribers
        self._notify_subscribers("trust_threshold_changed", {
            "threshold": threshold
        })
        
        return True
    
    def get_trust_threshold(self) -> float:
        """
        Get the current trust threshold.
        
        Returns:
            float: Current trust threshold
        """
        return self.trust_threshold
    
    def export_visualization(self, visualization_id: str) -> Optional[Dict[str, Any]]:
        """
        Export a visualization to a serializable format.
        
        Args:
            visualization_id: Visualization identifier
        
        Returns:
            Optional[Dict[str, Any]]: Exported visualization if successful, None otherwise
        """
        logger.info("Exporting visualization: %s", visualization_id)
        
        if visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return None
        
        visualization = self.visualizations[visualization_id]
        
        # Get associated dataset
        dataset = None
        dataset_id = visualization.get("dataset_id")
        if dataset_id and dataset_id in self.datasets:
            dataset = self.datasets[dataset_id]
        
        # Get associated data source
        data_source = None
        data_source_id = visualization.get("data_source_id")
        if data_source_id and data_source_id in self.data_sources:
            data_source = self.data_sources[data_source_id]
        
        # Create export data
        export_data = {
            "visualization": visualization,
            "dataset": dataset,
            "data_source": data_source
        }
        
        return export_data
    
    def import_visualization(self, import_data: Dict[str, Any]) -> Optional[str]:
        """
        Import a visualization from a serialized format.
        
        Args:
            import_data: Imported visualization data
        
        Returns:
            Optional[str]: Visualization ID if import was successful, None otherwise
        """
        logger.info("Importing visualization")
        
        # Validate import data
        if "visualization" not in import_data:
            logger.warning("Missing visualization in import data")
            return None
        
        # Import dataset if present
        dataset_id = None
        if "dataset" in import_data and import_data["dataset"]:
            dataset_data = import_data["dataset"]
            dataset_id = self.create_dataset(dataset_data)
        
        # Import data source if present
        data_source_id = None
        if "data_source" in import_data and import_data["data_source"]:
            data_source = import_data["data_source"]
            data_source_id = self.register_data_source(data_source)
        
        # Import visualization
        visualization_data = import_data["visualization"]
        
        # Update dataset and data source IDs
        if dataset_id:
            visualization_data["dataset_id"] = dataset_id
        
        if data_source_id:
            visualization_data["data_source_id"] = data_source_id
        
        # Create visualization
        visualization_id = self.create_visualization(visualization_data)
        
        if not visualization_id:
            logger.warning("Failed to create visualization")
            return None
        
        # Set as active visualization
        self.set_active_visualization(visualization_id)
        
        # Notify subscribers
        self._notify_subscribers("visualization_imported", {
            "visualization_id": visualization_id
        })
        
        return visualization_id
    
    def create_dashboard(self, dashboard_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new dashboard with multiple visualizations.
        
        Args:
            dashboard_data: Dashboard data
        
        Returns:
            Optional[str]: Dashboard ID if created successfully, None otherwise
        """
        logger.info("Creating dashboard: %s", dashboard_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "layout"]
        for field in required_fields:
            if field not in dashboard_data:
                logger.warning("Missing required field in dashboard: %s", field)
                return None
        
        # Create dashboard as a special type of visualization
        dashboard_data["type"] = self.TYPE_DASHBOARD
        
        # Generate dashboard ID
        dashboard_id = dashboard_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in dashboard_data:
            dashboard_data["description"] = ""
        
        if "visualizations" not in dashboard_data:
            dashboard_data["visualizations"] = []
        
        if "config" not in dashboard_data:
            dashboard_data["config"] = {}
        
        if "created_at" not in dashboard_data:
            dashboard_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in dashboard_data:
            dashboard_data["updated_at"] = datetime.now().isoformat()
        
        if "metadata" not in dashboard_data:
            dashboard_data["metadata"] = {}
        
        if "trust_level" not in dashboard_data:
            dashboard_data["trust_level"] = 0.5
        
        # Store dashboard
        dashboard_data["id"] = dashboard_id
        self.visualizations[dashboard_id] = dashboard_data
        
        # Notify subscribers
        self._notify_subscribers("dashboard_created", {
            "dashboard_id": dashboard_id,
            "dashboard": dashboard_data
        })
        
        return dashboard_id
    
    def add_visualization_to_dashboard(self, dashboard_id: str, visualization_id: str, 
                                     position: Dict[str, Any]) -> bool:
        """
        Add a visualization to a dashboard.
        
        Args:
            dashboard_id: Dashboard identifier
            visualization_id: Visualization identifier
            position: Position and size in the dashboard layout
        
        Returns:
            bool: True if visualization was added successfully, False otherwise
        """
        logger.info("Adding visualization %s to dashboard %s", visualization_id, dashboard_id)
        
        if dashboard_id not in self.visualizations:
            logger.warning("Dashboard not found: %s", dashboard_id)
            return False
        
        if visualization_id not in self.visualizations:
            logger.warning("Visualization not found: %s", visualization_id)
            return False
        
        dashboard = self.visualizations[dashboard_id]
        
        # Validate dashboard type
        if dashboard.get("type") != self.TYPE_DASHBOARD:
            logger.warning("Not a dashboard: %s", dashboard_id)
            return False
        
        # Add visualization to dashboard
        visualizations = dashboard.get("visualizations", [])
        
        # Check if visualization is already in dashboard
        for i, viz in enumerate(visualizations):
            if viz.get("id") == visualization_id:
                # Update position
                visualizations[i]["position"] = position
                dashboard["updated_at"] = datetime.now().isoformat()
                
                # Notify subscribers
                self._notify_subscribers("dashboard_visualization_updated", {
                    "dashboard_id": dashboard_id,
                    "visualization_id": visualization_id,
                    "position": position
                })
                
                return True
        
        # Add new visualization
        visualizations.append({
            "id": visualization_id,
            "position": position
        })
        
        dashboard["visualizations"] = visualizations
        dashboard["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("dashboard_visualization_added", {
            "dashboard_id": dashboard_id,
            "visualization_id": visualization_id,
            "position": position
        })
        
        return True
    
    def remove_visualization_from_dashboard(self, dashboard_id: str, visualization_id: str) -> bool:
        """
        Remove a visualization from a dashboard.
        
        Args:
            dashboard_id: Dashboard identifier
            visualization_id: Visualization identifier
        
        Returns:
            bool: True if visualization was removed successfully, False otherwise
        """
        logger.info("Removing visualization %s from dashboard %s", visualization_id, dashboard_id)
        
        if dashboard_id not in self.visualizations:
            logger.warning("Dashboard not found: %s", dashboard_id)
            return False
        
        dashboard = self.visualizations[dashboard_id]
        
        # Validate dashboard type
        if dashboard.get("type") != self.TYPE_DASHBOARD:
            logger.warning("Not a dashboard: %s", dashboard_id)
            return False
        
        # Remove visualization from dashboard
        visualizations = dashboard.get("visualizations", [])
        
        # Find visualization
        for i, viz in enumerate(visualizations):
            if viz.get("id") == visualization_id:
                # Remove visualization
                visualizations.pop(i)
                dashboard["visualizations"] = visualizations
                dashboard["updated_at"] = datetime.now().isoformat()
                
                # Notify subscribers
                self._notify_subscribers("dashboard_visualization_removed", {
                    "dashboard_id": dashboard_id,
                    "visualization_id": visualization_id
                })
                
                return True
        
        logger.warning("Visualization not found in dashboard: %s", visualization_id)
        return False
    
    def render_dashboard(self, dashboard_id: str, 
                       params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Render a dashboard.
        
        Args:
            dashboard_id: Dashboard identifier
            params: Optional rendering parameters
        
        Returns:
            Optional[Dict[str, Any]]: Rendering result if successful, None otherwise
        """
        logger.info("Rendering dashboard: %s", dashboard_id)
        
        if dashboard_id not in self.visualizations:
            logger.warning("Dashboard not found: %s", dashboard_id)
            return None
        
        dashboard = self.visualizations[dashboard_id]
        
        # Validate dashboard type
        if dashboard.get("type") != self.TYPE_DASHBOARD:
            logger.warning("Not a dashboard: %s", dashboard_id)
            return None
        
        # Render each visualization in the dashboard
        visualizations = []
        for viz_item in dashboard.get("visualizations", []):
            viz_id = viz_item.get("id")
            viz_position = viz_item.get("position", {})
            
            # Render visualization
            viz_result = self.render_visualization(viz_id, params)
            if viz_result:
                visualizations.append({
                    "visualization": viz_result,
                    "position": viz_position
                })
        
        # Prepare rendering result
        result = {
            "id": dashboard_id,
            "name": dashboard.get("name"),
            "description": dashboard.get("description"),
            "layout": dashboard.get("layout"),
            "config": dashboard.get("config", {}),
            "visualizations": visualizations
        }
        
        # Notify subscribers
        self._notify_subscribers("dashboard_rendered", {
            "dashboard_id": dashboard_id,
            "result": result
        })
        
        return result
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Check if context includes a visualization
        visualization_id = context_data.get("visualization_id")
        if visualization_id and visualization_id in self.visualizations:
            self.set_active_visualization(visualization_id)
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        # Handle interaction mode toggle
        if input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+I":
            # Cycle through interaction modes
            current_mode = self.interaction_mode
            modes = [
                self.MODE_VIEW,
                self.MODE_EXPLORE,
                self.MODE_ANALYZE,
                self.MODE_EDIT
            ]
            
            current_index = modes.index(current_mode) if current_mode in modes else 0
            next_index = (current_index + 1) % len(modes)
            self.set_interaction_mode(modes[next_index])
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        # Handle data-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "data_update":
            # Update dataset if available
            dataset_id = message.get("dataset_id")
            data = message.get("data")
            
            if dataset_id and data and dataset_id in self.datasets:
                dataset = self.datasets[dataset_id]
                dataset["data"] = data
                dataset["updated_at"] = datetime.now().isoformat()
                
                self._notify_subscribers("dataset_updated", {
                    "dataset_id": dataset_id,
                    "dataset": dataset
                })
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        # Handle visualization-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "visualization_request":
            # Handle request to render visualization
            visualization_id = message.get("visualization_id")
            params = message.get("params")
            
            if visualization_id and visualization_id in self.visualizations:
                self.render_visualization(visualization_id, params)
    
    def _on_data_updated(self, event_data: Dict[str, Any]):
        """
        Handle data updated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Data updated: %s", event_data)
        
        data_source_id = event_data.get("data_source_id")
        data = event_data.get("data")
        
        if data_source_id and data and data_source_id in self.data_sources:
            # Update streaming data source
            data_source = self.data_sources[data_source_id]
            
            if data_source.get("type") == self.SOURCE_STREAMING:
                # Find datasets using this data source
                for dataset_id, dataset in self.datasets.items():
                    if dataset.get("data_source_id") == data_source_id:
                        # Update dataset
                        dataset["data"] = data
                        dataset["updated_at"] = datetime.now().isoformat()
                        
                        self._notify_subscribers("dataset_updated", {
                            "dataset_id": dataset_id,
                            "dataset": dataset
                        })
                
                # Find visualizations using this data source
                for viz_id, viz in self.visualizations.items():
                    if viz.get("data_source_id") == data_source_id:
                        # Re-render visualization if it's active
                        if viz_id == self.active_visualization_id:
                            self.render_visualization(viz_id)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Data Visualization events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Data Visualization events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
