"""
Spatial Canvas Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements a 3D spatial canvas for visualizing complex relationships,
digital twins, and multi-dimensional data. It provides an immersive environment for
exploring industrial systems, agent relationships, and protocol flows with intuitive
navigation and interaction capabilities.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import math
import uuid
from datetime import datetime

# Initialize logger
logger = logging.getLogger(__name__)

class SpatialCanvas:
    """
    Spatial Canvas component for creating immersive 3D visualizations of complex
    industrial systems, agent relationships, and protocol flows.
    """
    
    # Canvas mode constants
    MODE_OVERVIEW = "overview"
    MODE_FOCUS = "focus"
    MODE_DETAIL = "detail"
    MODE_EDIT = "edit"
    
    # View type constants
    VIEW_ORTHOGRAPHIC = "orthographic"
    VIEW_PERSPECTIVE = "perspective"
    VIEW_IMMERSIVE = "immersive"
    
    # Entity type constants
    ENTITY_AGENT = "agent"
    ENTITY_DIGITAL_TWIN = "digital_twin"
    ENTITY_PROTOCOL = "protocol"
    ENTITY_WORKFLOW = "workflow"
    ENTITY_DATA_STREAM = "data_stream"
    ENTITY_SYSTEM = "system"
    ENTITY_CUSTOM = "custom"
    
    # Relationship type constants
    REL_COMMUNICATION = "communication"
    REL_DEPENDENCY = "dependency"
    REL_COMPOSITION = "composition"
    REL_FLOW = "flow"
    REL_TRUST = "trust"
    REL_CUSTOM = "custom"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Spatial Canvas component with optional configuration."""
        self.config = config or {}
        self.entities = {}
        self.relationships = {}
        self.views = {}
        self.active_view_id = None
        self.canvas_mode = self.MODE_OVERVIEW
        self.view_type = self.VIEW_PERSPECTIVE
        self.trust_threshold = 0.7  # 0.0 to 1.0
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.protocol_bridge = None
        self.rendering_engine = None
        self.avatar_manager = None
        self.capsule_manager = None
        
        logger.info("Spatial Canvas component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, protocol_bridge=None, 
                  rendering_engine=None, avatar_manager=None, capsule_manager=None):
        """Initialize the Spatial Canvas component and connect to required services."""
        logger.info("Initializing Spatial Canvas component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.protocol_bridge = protocol_bridge
        self.rendering_engine = rendering_engine
        self.avatar_manager = avatar_manager
        self.capsule_manager = capsule_manager
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        if self.avatar_manager:
            self.avatar_manager.subscribe_to_events("avatar_state_changed", self._on_avatar_state_changed)
        
        if self.capsule_manager:
            self.capsule_manager.subscribe_to_events("capsule_state_changed", self._on_capsule_state_changed)
        
        # Create default view if none exists
        if not self.views:
            self.create_view({
                "name": "Default View",
                "description": "Default spatial canvas view",
                "camera": {
                    "position": [0, 0, 10],
                    "target": [0, 0, 0],
                    "up": [0, 1, 0]
                }
            })
        
        logger.info("Spatial Canvas component initialization complete")
        return True
    
    def create_entity(self, entity_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new entity in the spatial canvas.
        
        Args:
            entity_data: Entity data
        
        Returns:
            Optional[str]: Entity ID if created successfully, None otherwise
        """
        logger.info("Creating entity: %s", entity_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type"]
        for field in required_fields:
            if field not in entity_data:
                logger.warning("Missing required field in entity: %s", field)
                return None
        
        # Generate entity ID
        entity_id = entity_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in entity_data:
            entity_data["description"] = ""
        
        if "position" not in entity_data:
            entity_data["position"] = [0, 0, 0]
        
        if "rotation" not in entity_data:
            entity_data["rotation"] = [0, 0, 0]
        
        if "scale" not in entity_data:
            entity_data["scale"] = [1, 1, 1]
        
        if "color" not in entity_data:
            entity_data["color"] = "#3498db"  # Default blue
        
        if "opacity" not in entity_data:
            entity_data["opacity"] = 1.0
        
        if "visible" not in entity_data:
            entity_data["visible"] = True
        
        if "selectable" not in entity_data:
            entity_data["selectable"] = True
        
        if "metadata" not in entity_data:
            entity_data["metadata"] = {}
        
        if "trust_level" not in entity_data:
            entity_data["trust_level"] = 0.5
        
        if "created_at" not in entity_data:
            entity_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in entity_data:
            entity_data["updated_at"] = datetime.now().isoformat()
        
        # Store entity
        entity_data["id"] = entity_id
        self.entities[entity_id] = entity_data
        
        # Notify subscribers
        self._notify_subscribers("entity_created", {
            "entity_id": entity_id,
            "entity": entity_data
        })
        
        return entity_id
    
    def update_entity(self, entity_id: str, entity_data: Dict[str, Any]) -> bool:
        """
        Update an existing entity.
        
        Args:
            entity_id: Entity identifier
            entity_data: Updated entity data
        
        Returns:
            bool: True if entity was updated successfully, False otherwise
        """
        logger.info("Updating entity: %s", entity_id)
        
        if entity_id not in self.entities:
            logger.warning("Entity not found: %s", entity_id)
            return False
        
        # Get current entity data
        current_data = self.entities[entity_id]
        
        # Update fields
        for key, value in entity_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("entity_updated", {
            "entity_id": entity_id,
            "entity": current_data
        })
        
        return True
    
    def delete_entity(self, entity_id: str) -> bool:
        """
        Delete an entity.
        
        Args:
            entity_id: Entity identifier
        
        Returns:
            bool: True if entity was deleted successfully, False otherwise
        """
        logger.info("Deleting entity: %s", entity_id)
        
        if entity_id not in self.entities:
            logger.warning("Entity not found: %s", entity_id)
            return False
        
        # Remove entity
        del self.entities[entity_id]
        
        # Remove relationships involving this entity
        relationships_to_delete = []
        for rel_id, rel in self.relationships.items():
            if rel.get("source_id") == entity_id or rel.get("target_id") == entity_id:
                relationships_to_delete.append(rel_id)
        
        for rel_id in relationships_to_delete:
            self.delete_relationship(rel_id)
        
        # Notify subscribers
        self._notify_subscribers("entity_deleted", {
            "entity_id": entity_id
        })
        
        return True
    
    def get_entity(self, entity_id: str) -> Optional[Dict[str, Any]]:
        """
        Get entity by ID.
        
        Args:
            entity_id: Entity identifier
        
        Returns:
            Optional[Dict[str, Any]]: Entity if found, None otherwise
        """
        if entity_id in self.entities:
            return self.entities[entity_id]
        else:
            logger.warning("Entity not found: %s", entity_id)
            return None
    
    def get_all_entities(self, entity_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all entities, optionally filtered by type.
        
        Args:
            entity_type: Optional entity type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of entities
        """
        if entity_type:
            return [entity for entity in self.entities.values() if entity.get("type") == entity_type]
        else:
            return list(self.entities.values())
    
    def create_relationship(self, relationship_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new relationship between entities.
        
        Args:
            relationship_data: Relationship data
        
        Returns:
            Optional[str]: Relationship ID if created successfully, None otherwise
        """
        logger.info("Creating relationship: %s", relationship_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["source_id", "target_id", "type"]
        for field in required_fields:
            if field not in relationship_data:
                logger.warning("Missing required field in relationship: %s", field)
                return None
        
        # Validate source and target entities
        source_id = relationship_data["source_id"]
        target_id = relationship_data["target_id"]
        
        if source_id not in self.entities:
            logger.warning("Source entity not found: %s", source_id)
            return None
        
        if target_id not in self.entities:
            logger.warning("Target entity not found: %s", target_id)
            return None
        
        # Generate relationship ID
        relationship_id = relationship_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "name" not in relationship_data:
            relationship_data["name"] = f"Relationship {relationship_id}"
        
        if "description" not in relationship_data:
            relationship_data["description"] = ""
        
        if "color" not in relationship_data:
            relationship_data["color"] = "#7f8c8d"  # Default gray
        
        if "width" not in relationship_data:
            relationship_data["width"] = 1.0
        
        if "style" not in relationship_data:
            relationship_data["style"] = "solid"
        
        if "visible" not in relationship_data:
            relationship_data["visible"] = True
        
        if "selectable" not in relationship_data:
            relationship_data["selectable"] = True
        
        if "metadata" not in relationship_data:
            relationship_data["metadata"] = {}
        
        if "trust_level" not in relationship_data:
            relationship_data["trust_level"] = 0.5
        
        if "created_at" not in relationship_data:
            relationship_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in relationship_data:
            relationship_data["updated_at"] = datetime.now().isoformat()
        
        # Store relationship
        relationship_data["id"] = relationship_id
        self.relationships[relationship_id] = relationship_data
        
        # Notify subscribers
        self._notify_subscribers("relationship_created", {
            "relationship_id": relationship_id,
            "relationship": relationship_data
        })
        
        return relationship_id
    
    def update_relationship(self, relationship_id: str, relationship_data: Dict[str, Any]) -> bool:
        """
        Update an existing relationship.
        
        Args:
            relationship_id: Relationship identifier
            relationship_data: Updated relationship data
        
        Returns:
            bool: True if relationship was updated successfully, False otherwise
        """
        logger.info("Updating relationship: %s", relationship_id)
        
        if relationship_id not in self.relationships:
            logger.warning("Relationship not found: %s", relationship_id)
            return False
        
        # Get current relationship data
        current_data = self.relationships[relationship_id]
        
        # Update fields
        for key, value in relationship_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            # Validate source and target entities if changed
            if key == "source_id" and value not in self.entities:
                logger.warning("Source entity not found: %s", value)
                continue
            
            if key == "target_id" and value not in self.entities:
                logger.warning("Target entity not found: %s", value)
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("relationship_updated", {
            "relationship_id": relationship_id,
            "relationship": current_data
        })
        
        return True
    
    def delete_relationship(self, relationship_id: str) -> bool:
        """
        Delete a relationship.
        
        Args:
            relationship_id: Relationship identifier
        
        Returns:
            bool: True if relationship was deleted successfully, False otherwise
        """
        logger.info("Deleting relationship: %s", relationship_id)
        
        if relationship_id not in self.relationships:
            logger.warning("Relationship not found: %s", relationship_id)
            return False
        
        # Remove relationship
        del self.relationships[relationship_id]
        
        # Notify subscribers
        self._notify_subscribers("relationship_deleted", {
            "relationship_id": relationship_id
        })
        
        return True
    
    def get_relationship(self, relationship_id: str) -> Optional[Dict[str, Any]]:
        """
        Get relationship by ID.
        
        Args:
            relationship_id: Relationship identifier
        
        Returns:
            Optional[Dict[str, Any]]: Relationship if found, None otherwise
        """
        if relationship_id in self.relationships:
            return self.relationships[relationship_id]
        else:
            logger.warning("Relationship not found: %s", relationship_id)
            return None
    
    def get_all_relationships(self, relationship_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all relationships, optionally filtered by type.
        
        Args:
            relationship_type: Optional relationship type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of relationships
        """
        if relationship_type:
            return [rel for rel in self.relationships.values() if rel.get("type") == relationship_type]
        else:
            return list(self.relationships.values())
    
    def get_entity_relationships(self, entity_id: str, direction: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get relationships for a specific entity.
        
        Args:
            entity_id: Entity identifier
            direction: Optional direction filter ("outgoing", "incoming", or None for both)
        
        Returns:
            List[Dict[str, Any]]: List of relationships
        """
        if entity_id not in self.entities:
            logger.warning("Entity not found: %s", entity_id)
            return []
        
        if direction == "outgoing":
            return [rel for rel in self.relationships.values() if rel.get("source_id") == entity_id]
        elif direction == "incoming":
            return [rel for rel in self.relationships.values() if rel.get("target_id") == entity_id]
        else:
            return [rel for rel in self.relationships.values() 
                   if rel.get("source_id") == entity_id or rel.get("target_id") == entity_id]
    
    def create_view(self, view_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new view in the spatial canvas.
        
        Args:
            view_data: View data
        
        Returns:
            Optional[str]: View ID if created successfully, None otherwise
        """
        logger.info("Creating view: %s", view_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "camera"]
        for field in required_fields:
            if field not in view_data:
                logger.warning("Missing required field in view: %s", field)
                return None
        
        # Generate view ID
        view_id = view_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in view_data:
            view_data["description"] = ""
        
        if "filters" not in view_data:
            view_data["filters"] = {}
        
        if "visible_entity_types" not in view_data:
            view_data["visible_entity_types"] = None  # None means all types
        
        if "visible_relationship_types" not in view_data:
            view_data["visible_relationship_types"] = None  # None means all types
        
        if "metadata" not in view_data:
            view_data["metadata"] = {}
        
        if "created_at" not in view_data:
            view_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in view_data:
            view_data["updated_at"] = datetime.now().isoformat()
        
        # Store view
        view_data["id"] = view_id
        self.views[view_id] = view_data
        
        # Set as active view if this is the first one
        if len(self.views) == 1:
            self.active_view_id = view_id
        
        # Notify subscribers
        self._notify_subscribers("view_created", {
            "view_id": view_id,
            "view": view_data
        })
        
        return view_id
    
    def update_view(self, view_id: str, view_data: Dict[str, Any]) -> bool:
        """
        Update an existing view.
        
        Args:
            view_id: View identifier
            view_data: Updated view data
        
        Returns:
            bool: True if view was updated successfully, False otherwise
        """
        logger.info("Updating view: %s", view_id)
        
        if view_id not in self.views:
            logger.warning("View not found: %s", view_id)
            return False
        
        # Get current view data
        current_data = self.views[view_id]
        
        # Update fields
        for key, value in view_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("view_updated", {
            "view_id": view_id,
            "view": current_data
        })
        
        return True
    
    def delete_view(self, view_id: str) -> bool:
        """
        Delete a view.
        
        Args:
            view_id: View identifier
        
        Returns:
            bool: True if view was deleted successfully, False otherwise
        """
        logger.info("Deleting view: %s", view_id)
        
        if view_id not in self.views:
            logger.warning("View not found: %s", view_id)
            return False
        
        # Remove view
        del self.views[view_id]
        
        # Update active view if this was the active one
        if self.active_view_id == view_id:
            if self.views:
                self.active_view_id = next(iter(self.views))
            else:
                self.active_view_id = None
        
        # Notify subscribers
        self._notify_subscribers("view_deleted", {
            "view_id": view_id
        })
        
        return True
    
    def get_view(self, view_id: str) -> Optional[Dict[str, Any]]:
        """
        Get view by ID.
        
        Args:
            view_id: View identifier
        
        Returns:
            Optional[Dict[str, Any]]: View if found, None otherwise
        """
        if view_id in self.views:
            return self.views[view_id]
        else:
            logger.warning("View not found: %s", view_id)
            return None
    
    def get_all_views(self) -> List[Dict[str, Any]]:
        """
        Get all views.
        
        Returns:
            List[Dict[str, Any]]: List of all views
        """
        return list(self.views.values())
    
    def set_active_view(self, view_id: Optional[str]) -> bool:
        """
        Set the active view.
        
        Args:
            view_id: View identifier, or None to clear active view
        
        Returns:
            bool: True if active view was set successfully, False otherwise
        """
        logger.info("Setting active view: %s", view_id)
        
        if view_id is not None and view_id not in self.views:
            logger.warning("View not found: %s", view_id)
            return False
        
        previous_view_id = self.active_view_id
        self.active_view_id = view_id
        
        # Notify subscribers
        self._notify_subscribers("active_view_changed", {
            "previous_view_id": previous_view_id,
            "view_id": view_id
        })
        
        return True
    
    def get_active_view(self) -> Optional[Dict[str, Any]]:
        """
        Get the active view.
        
        Returns:
            Optional[Dict[str, Any]]: Active view if set, None otherwise
        """
        if self.active_view_id is not None and self.active_view_id in self.views:
            return self.views[self.active_view_id]
        else:
            return None
    
    def set_canvas_mode(self, mode: str) -> bool:
        """
        Set the canvas mode.
        
        Args:
            mode: Canvas mode
        
        Returns:
            bool: True if canvas mode was set successfully, False otherwise
        """
        logger.info("Setting canvas mode: %s", mode)
        
        valid_modes = [
            self.MODE_OVERVIEW,
            self.MODE_FOCUS,
            self.MODE_DETAIL,
            self.MODE_EDIT
        ]
        
        if mode not in valid_modes:
            logger.warning("Invalid canvas mode: %s", mode)
            return False
        
        self.canvas_mode = mode
        
        # Notify subscribers
        self._notify_subscribers("canvas_mode_changed", {
            "mode": mode
        })
        
        return True
    
    def get_canvas_mode(self) -> str:
        """
        Get the current canvas mode.
        
        Returns:
            str: Current canvas mode
        """
        return self.canvas_mode
    
    def set_view_type(self, view_type: str) -> bool:
        """
        Set the view type.
        
        Args:
            view_type: View type
        
        Returns:
            bool: True if view type was set successfully, False otherwise
        """
        logger.info("Setting view type: %s", view_type)
        
        valid_view_types = [
            self.VIEW_ORTHOGRAPHIC,
            self.VIEW_PERSPECTIVE,
            self.VIEW_IMMERSIVE
        ]
        
        if view_type not in valid_view_types:
            logger.warning("Invalid view type: %s", view_type)
            return False
        
        self.view_type = view_type
        
        # Notify subscribers
        self._notify_subscribers("view_type_changed", {
            "view_type": view_type
        })
        
        return True
    
    def get_view_type(self) -> str:
        """
        Get the current view type.
        
        Returns:
            str: Current view type
        """
        return self.view_type
    
    def set_trust_threshold(self, threshold: float) -> bool:
        """
        Set the trust threshold for entities and relationships.
        
        Args:
            threshold: Trust threshold (0.0 to 1.0)
        
        Returns:
            bool: True if trust threshold was set successfully, False otherwise
        """
        logger.info("Setting trust threshold: %s", threshold)
        
        # Clamp threshold to valid range
        threshold = max(0.0, min(1.0, threshold))
        
        self.trust_threshold = threshold
        
        # Notify subscribers
        self._notify_subscribers("trust_threshold_changed", {
            "threshold": threshold
        })
        
        return True
    
    def get_trust_threshold(self) -> float:
        """
        Get the current trust threshold.
        
        Returns:
            float: Current trust threshold
        """
        return self.trust_threshold
    
    def focus_on_entity(self, entity_id: str) -> bool:
        """
        Focus the canvas on a specific entity.
        
        Args:
            entity_id: Entity identifier
        
        Returns:
            bool: True if focus was successful, False otherwise
        """
        logger.info("Focusing on entity: %s", entity_id)
        
        if entity_id not in self.entities:
            logger.warning("Entity not found: %s", entity_id)
            return False
        
        entity = self.entities[entity_id]
        
        # Get active view
        active_view = self.get_active_view()
        if not active_view:
            logger.warning("No active view")
            return False
        
        # Update camera to focus on entity
        position = entity.get("position", [0, 0, 0])
        
        # Create a new camera position looking at the entity
        camera = {
            "position": [
                position[0],
                position[1],
                position[2] + 5  # Position camera 5 units away on Z axis
            ],
            "target": position,
            "up": [0, 1, 0]
        }
        
        # Update view
        self.update_view(self.active_view_id, {
            "camera": camera
        })
        
        # Set canvas mode to focus
        self.set_canvas_mode(self.MODE_FOCUS)
        
        # Notify subscribers
        self._notify_subscribers("entity_focused", {
            "entity_id": entity_id,
            "entity": entity
        })
        
        return True
    
    def focus_on_relationship(self, relationship_id: str) -> bool:
        """
        Focus the canvas on a specific relationship.
        
        Args:
            relationship_id: Relationship identifier
        
        Returns:
            bool: True if focus was successful, False otherwise
        """
        logger.info("Focusing on relationship: %s", relationship_id)
        
        if relationship_id not in self.relationships:
            logger.warning("Relationship not found: %s", relationship_id)
            return False
        
        relationship = self.relationships[relationship_id]
        
        # Get source and target entities
        source_id = relationship.get("source_id")
        target_id = relationship.get("target_id")
        
        if source_id not in self.entities or target_id not in self.entities:
            logger.warning("Source or target entity not found")
            return False
        
        source = self.entities[source_id]
        target = self.entities[target_id]
        
        # Get active view
        active_view = self.get_active_view()
        if not active_view:
            logger.warning("No active view")
            return False
        
        # Calculate midpoint between source and target
        source_pos = source.get("position", [0, 0, 0])
        target_pos = target.get("position", [0, 0, 0])
        
        midpoint = [
            (source_pos[0] + target_pos[0]) / 2,
            (source_pos[1] + target_pos[1]) / 2,
            (source_pos[2] + target_pos[2]) / 2
        ]
        
        # Calculate distance between source and target
        dx = target_pos[0] - source_pos[0]
        dy = target_pos[1] - source_pos[1]
        dz = target_pos[2] - source_pos[2]
        distance = math.sqrt(dx*dx + dy*dy + dz*dz)
        
        # Create a new camera position looking at the midpoint
        camera = {
            "position": [
                midpoint[0],
                midpoint[1],
                midpoint[2] + distance  # Position camera at a distance away on Z axis
            ],
            "target": midpoint,
            "up": [0, 1, 0]
        }
        
        # Update view
        self.update_view(self.active_view_id, {
            "camera": camera
        })
        
        # Set canvas mode to focus
        self.set_canvas_mode(self.MODE_FOCUS)
        
        # Notify subscribers
        self._notify_subscribers("relationship_focused", {
            "relationship_id": relationship_id,
            "relationship": relationship
        })
        
        return True
    
    def reset_view(self) -> bool:
        """
        Reset the canvas view to default.
        
        Returns:
            bool: True if reset was successful, False otherwise
        """
        logger.info("Resetting view")
        
        # Get active view
        active_view = self.get_active_view()
        if not active_view:
            logger.warning("No active view")
            return False
        
        # Reset camera to default
        camera = {
            "position": [0, 0, 10],
            "target": [0, 0, 0],
            "up": [0, 1, 0]
        }
        
        # Update view
        self.update_view(self.active_view_id, {
            "camera": camera
        })
        
        # Set canvas mode to overview
        self.set_canvas_mode(self.MODE_OVERVIEW)
        
        # Notify subscribers
        self._notify_subscribers("view_reset", {})
        
        return True
    
    def filter_entities(self, filter_criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Filter entities based on criteria.
        
        Args:
            filter_criteria: Filter criteria
        
        Returns:
            List[Dict[str, Any]]: Filtered entities
        """
        logger.info("Filtering entities with criteria: %s", filter_criteria)
        
        filtered_entities = []
        
        for entity in self.entities.values():
            # Check if entity matches all criteria
            match = True
            
            for key, value in filter_criteria.items():
                # Special case for metadata
                if key == "metadata":
                    for meta_key, meta_value in value.items():
                        if meta_key not in entity.get("metadata", {}) or entity["metadata"][meta_key] != meta_value:
                            match = False
                            break
                # Special case for trust_level (range)
                elif key == "trust_level_min":
                    if entity.get("trust_level", 0) < value:
                        match = False
                elif key == "trust_level_max":
                    if entity.get("trust_level", 0) > value:
                        match = False
                # Regular field match
                elif key not in entity or entity[key] != value:
                    match = False
            
            if match:
                filtered_entities.append(entity)
        
        return filtered_entities
    
    def filter_relationships(self, filter_criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Filter relationships based on criteria.
        
        Args:
            filter_criteria: Filter criteria
        
        Returns:
            List[Dict[str, Any]]: Filtered relationships
        """
        logger.info("Filtering relationships with criteria: %s", filter_criteria)
        
        filtered_relationships = []
        
        for relationship in self.relationships.values():
            # Check if relationship matches all criteria
            match = True
            
            for key, value in filter_criteria.items():
                # Special case for metadata
                if key == "metadata":
                    for meta_key, meta_value in value.items():
                        if meta_key not in relationship.get("metadata", {}) or relationship["metadata"][meta_key] != meta_value:
                            match = False
                            break
                # Special case for trust_level (range)
                elif key == "trust_level_min":
                    if relationship.get("trust_level", 0) < value:
                        match = False
                elif key == "trust_level_max":
                    if relationship.get("trust_level", 0) > value:
                        match = False
                # Regular field match
                elif key not in relationship or relationship[key] != value:
                    match = False
            
            if match:
                filtered_relationships.append(relationship)
        
        return filtered_relationships
    
    def apply_layout(self, layout_type: str, params: Optional[Dict[str, Any]] = None) -> bool:
        """
        Apply an automatic layout to entities.
        
        Args:
            layout_type: Type of layout to apply
            params: Optional layout parameters
        
        Returns:
            bool: True if layout was applied successfully, False otherwise
        """
        logger.info("Applying layout: %s", layout_type)
        
        params = params or {}
        
        # Get entities to layout
        entities = self.get_all_entities()
        if not entities:
            logger.warning("No entities to layout")
            return False
        
        # Apply layout based on type
        if layout_type == "grid":
            return self._apply_grid_layout(entities, params)
        elif layout_type == "circle":
            return self._apply_circle_layout(entities, params)
        elif layout_type == "force":
            return self._apply_force_layout(entities, params)
        elif layout_type == "hierarchy":
            return self._apply_hierarchy_layout(entities, params)
        else:
            logger.warning("Unsupported layout type: %s", layout_type)
            return False
    
    def _apply_grid_layout(self, entities: List[Dict[str, Any]], params: Dict[str, Any]) -> bool:
        """
        Apply a grid layout to entities.
        
        Args:
            entities: Entities to layout
            params: Layout parameters
        
        Returns:
            bool: True if layout was applied successfully, False otherwise
        """
        # Get grid parameters
        rows = params.get("rows", 0)
        cols = params.get("cols", 0)
        spacing_x = params.get("spacing_x", 2.0)
        spacing_y = params.get("spacing_y", 2.0)
        center_x = params.get("center_x", 0.0)
        center_y = params.get("center_y", 0.0)
        
        # Calculate rows and columns if not specified
        if rows <= 0 or cols <= 0:
            count = len(entities)
            cols = math.ceil(math.sqrt(count))
            rows = math.ceil(count / cols)
        
        # Calculate grid origin
        origin_x = center_x - (cols - 1) * spacing_x / 2
        origin_y = center_y - (rows - 1) * spacing_y / 2
        
        # Position entities in grid
        for i, entity in enumerate(entities):
            row = i // cols
            col = i % cols
            
            x = origin_x + col * spacing_x
            y = origin_y + row * spacing_y
            z = entity.get("position", [0, 0, 0])[2]  # Keep original Z
            
            self.update_entity(entity["id"], {
                "position": [x, y, z]
            })
        
        # Notify subscribers
        self._notify_subscribers("layout_applied", {
            "layout_type": "grid",
            "params": params
        })
        
        return True
    
    def _apply_circle_layout(self, entities: List[Dict[str, Any]], params: Dict[str, Any]) -> bool:
        """
        Apply a circle layout to entities.
        
        Args:
            entities: Entities to layout
            params: Layout parameters
        
        Returns:
            bool: True if layout was applied successfully, False otherwise
        """
        # Get circle parameters
        radius = params.get("radius", 5.0)
        center_x = params.get("center_x", 0.0)
        center_y = params.get("center_y", 0.0)
        start_angle = params.get("start_angle", 0.0)
        
        # Position entities in circle
        count = len(entities)
        angle_step = 2 * math.pi / count
        
        for i, entity in enumerate(entities):
            angle = start_angle + i * angle_step
            
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)
            z = entity.get("position", [0, 0, 0])[2]  # Keep original Z
            
            self.update_entity(entity["id"], {
                "position": [x, y, z]
            })
        
        # Notify subscribers
        self._notify_subscribers("layout_applied", {
            "layout_type": "circle",
            "params": params
        })
        
        return True
    
    def _apply_force_layout(self, entities: List[Dict[str, Any]], params: Dict[str, Any]) -> bool:
        """
        Apply a force-directed layout to entities.
        
        Args:
            entities: Entities to layout
            params: Layout parameters
        
        Returns:
            bool: True if layout was applied successfully, False otherwise
        """
        # Get force layout parameters
        iterations = params.get("iterations", 100)
        repulsion = params.get("repulsion", 1.0)
        attraction = params.get("attraction", 0.01)
        gravity = params.get("gravity", 0.1)
        damping = params.get("damping", 0.9)
        
        # Get relationships
        relationships = self.get_all_relationships()
        
        # Initialize positions and velocities
        positions = {}
        velocities = {}
        
        for entity in entities:
            entity_id = entity["id"]
            positions[entity_id] = entity.get("position", [0, 0, 0])
            velocities[entity_id] = [0, 0, 0]
        
        # Run force-directed layout algorithm
        for _ in range(iterations):
            # Calculate forces
            forces = {entity_id: [0, 0, 0] for entity_id in positions}
            
            # Repulsion forces (entities repel each other)
            for i, entity1 in enumerate(entities):
                entity1_id = entity1["id"]
                pos1 = positions[entity1_id]
                
                for j, entity2 in enumerate(entities):
                    if i == j:
                        continue
                    
                    entity2_id = entity2["id"]
                    pos2 = positions[entity2_id]
                    
                    # Calculate distance
                    dx = pos1[0] - pos2[0]
                    dy = pos1[1] - pos2[1]
                    distance = math.sqrt(dx*dx + dy*dy)
                    
                    # Avoid division by zero
                    if distance < 0.1:
                        distance = 0.1
                    
                    # Calculate repulsion force
                    force = repulsion / (distance * distance)
                    
                    # Apply force
                    forces[entity1_id][0] += force * dx / distance
                    forces[entity1_id][1] += force * dy / distance
            
            # Attraction forces (connected entities attract each other)
            for relationship in relationships:
                source_id = relationship.get("source_id")
                target_id = relationship.get("target_id")
                
                if source_id in positions and target_id in positions:
                    pos1 = positions[source_id]
                    pos2 = positions[target_id]
                    
                    # Calculate distance
                    dx = pos2[0] - pos1[0]
                    dy = pos2[1] - pos1[1]
                    distance = math.sqrt(dx*dx + dy*dy)
                    
                    # Avoid division by zero
                    if distance < 0.1:
                        distance = 0.1
                    
                    # Calculate attraction force
                    force = attraction * distance
                    
                    # Apply force
                    forces[source_id][0] += force * dx / distance
                    forces[source_id][1] += force * dy / distance
                    forces[target_id][0] -= force * dx / distance
                    forces[target_id][1] -= force * dy / distance
            
            # Gravity force (pull towards center)
            for entity_id, pos in positions.items():
                # Calculate distance to center
                dx = pos[0]
                dy = pos[1]
                distance = math.sqrt(dx*dx + dy*dy)
                
                # Avoid division by zero
                if distance < 0.1:
                    distance = 0.1
                
                # Calculate gravity force
                force = gravity * distance
                
                # Apply force
                forces[entity_id][0] -= force * dx / distance
                forces[entity_id][1] -= force * dy / distance
            
            # Update velocities and positions
            for entity_id in positions:
                # Update velocity
                velocities[entity_id][0] = damping * velocities[entity_id][0] + forces[entity_id][0]
                velocities[entity_id][1] = damping * velocities[entity_id][1] + forces[entity_id][1]
                
                # Update position
                positions[entity_id][0] += velocities[entity_id][0]
                positions[entity_id][1] += velocities[entity_id][1]
        
        # Apply final positions
        for entity in entities:
            entity_id = entity["id"]
            self.update_entity(entity_id, {
                "position": positions[entity_id]
            })
        
        # Notify subscribers
        self._notify_subscribers("layout_applied", {
            "layout_type": "force",
            "params": params
        })
        
        return True
    
    def _apply_hierarchy_layout(self, entities: List[Dict[str, Any]], params: Dict[str, Any]) -> bool:
        """
        Apply a hierarchical layout to entities.
        
        Args:
            entities: Entities to layout
            params: Layout parameters
        
        Returns:
            bool: True if layout was applied successfully, False otherwise
        """
        # Get hierarchy parameters
        root_id = params.get("root_id")
        direction = params.get("direction", "down")
        level_spacing = params.get("level_spacing", 2.0)
        node_spacing = params.get("node_spacing", 2.0)
        
        # Validate root entity
        if not root_id or root_id not in self.entities:
            # If no valid root specified, use first entity
            if entities:
                root_id = entities[0]["id"]
            else:
                logger.warning("No entities to layout")
                return False
        
        # Build hierarchy tree
        tree = self._build_hierarchy_tree(root_id)
        
        # Calculate positions
        self._calculate_hierarchy_positions(tree, direction, level_spacing, node_spacing)
        
        # Apply positions
        self._apply_hierarchy_positions(tree)
        
        # Notify subscribers
        self._notify_subscribers("layout_applied", {
            "layout_type": "hierarchy",
            "params": params
        })
        
        return True
    
    def _build_hierarchy_tree(self, root_id: str) -> Dict[str, Any]:
        """
        Build a hierarchy tree from relationships.
        
        Args:
            root_id: Root entity identifier
        
        Returns:
            Dict[str, Any]: Hierarchy tree
        """
        # Create root node
        tree = {
            "id": root_id,
            "entity": self.entities[root_id],
            "children": [],
            "position": [0, 0, 0],
            "width": 0,
            "visited": set([root_id])
        }
        
        # Build tree recursively
        self._build_hierarchy_tree_recursive(tree)
        
        return tree
    
    def _build_hierarchy_tree_recursive(self, node: Dict[str, Any]):
        """
        Recursively build hierarchy tree.
        
        Args:
            node: Current tree node
        """
        # Get outgoing relationships
        relationships = self.get_entity_relationships(node["id"], "outgoing")
        
        # Add children
        for relationship in relationships:
            target_id = relationship.get("target_id")
            
            # Skip if already visited (avoid cycles)
            if target_id in node["visited"]:
                continue
            
            # Create child node
            child = {
                "id": target_id,
                "entity": self.entities[target_id],
                "children": [],
                "position": [0, 0, 0],
                "width": 0,
                "visited": set(node["visited"])
            }
            
            # Add target to visited set
            child["visited"].add(target_id)
            
            # Add child to parent
            node["children"].append(child)
            
            # Recursively build child's subtree
            self._build_hierarchy_tree_recursive(child)
    
    def _calculate_hierarchy_positions(self, node: Dict[str, Any], direction: str, 
                                     level_spacing: float, node_spacing: float, 
                                     level: int = 0, offset: float = 0):
        """
        Calculate positions for hierarchy layout.
        
        Args:
            node: Current tree node
            direction: Layout direction
            level_spacing: Spacing between levels
            node_spacing: Spacing between nodes at same level
            level: Current level
            offset: Current offset
        
        Returns:
            float: Width of subtree
        """
        # Calculate positions for children
        total_width = 0
        
        for child in node["children"]:
            child_width = self._calculate_hierarchy_positions(
                child, direction, level_spacing, node_spacing, level + 1, offset + total_width)
            total_width += child_width
        
        # If no children, set width to 1
        if not node["children"]:
            node["width"] = 1
        else:
            node["width"] = max(1, total_width)
        
        # Calculate position based on direction
        if direction == "down":
            node["position"] = [offset + node["width"] / 2, -level * level_spacing, 0]
        elif direction == "up":
            node["position"] = [offset + node["width"] / 2, level * level_spacing, 0]
        elif direction == "right":
            node["position"] = [level * level_spacing, offset + node["width"] / 2, 0]
        elif direction == "left":
            node["position"] = [-level * level_spacing, offset + node["width"] / 2, 0]
        
        return node["width"] * node_spacing
    
    def _apply_hierarchy_positions(self, node: Dict[str, Any]):
        """
        Apply calculated positions to entities.
        
        Args:
            node: Current tree node
        """
        # Update entity position
        self.update_entity(node["id"], {
            "position": node["position"]
        })
        
        # Recursively apply positions to children
        for child in node["children"]:
            self._apply_hierarchy_positions(child)
    
    def export_canvas(self) -> Dict[str, Any]:
        """
        Export the entire canvas to a serializable format.
        
        Returns:
            Dict[str, Any]: Exported canvas data
        """
        logger.info("Exporting canvas")
        
        # Create export data
        export_data = {
            "entities": list(self.entities.values()),
            "relationships": list(self.relationships.values()),
            "views": list(self.views.values()),
            "active_view_id": self.active_view_id,
            "canvas_mode": self.canvas_mode,
            "view_type": self.view_type,
            "trust_threshold": self.trust_threshold,
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }
        
        return export_data
    
    def import_canvas(self, import_data: Dict[str, Any]) -> bool:
        """
        Import canvas from a serialized format.
        
        Args:
            import_data: Imported canvas data
        
        Returns:
            bool: True if import was successful, False otherwise
        """
        logger.info("Importing canvas")
        
        # Validate import data
        required_fields = ["entities", "relationships", "views"]
        for field in required_fields:
            if field not in import_data:
                logger.warning("Missing required field in import data: %s", field)
                return False
        
        # Clear existing data
        self.entities = {}
        self.relationships = {}
        self.views = {}
        self.active_view_id = None
        
        # Import entities
        for entity_data in import_data["entities"]:
            entity_id = entity_data.get("id")
            if entity_id:
                self.entities[entity_id] = entity_data
        
        # Import relationships
        for relationship_data in import_data["relationships"]:
            relationship_id = relationship_data.get("id")
            if relationship_id:
                self.relationships[relationship_id] = relationship_data
        
        # Import views
        for view_data in import_data["views"]:
            view_id = view_data.get("id")
            if view_id:
                self.views[view_id] = view_data
        
        # Set active view
        active_view_id = import_data.get("active_view_id")
        if active_view_id and active_view_id in self.views:
            self.active_view_id = active_view_id
        elif self.views:
            self.active_view_id = next(iter(self.views))
        
        # Set canvas mode
        canvas_mode = import_data.get("canvas_mode")
        if canvas_mode:
            self.set_canvas_mode(canvas_mode)
        
        # Set view type
        view_type = import_data.get("view_type")
        if view_type:
            self.set_view_type(view_type)
        
        # Set trust threshold
        trust_threshold = import_data.get("trust_threshold")
        if trust_threshold is not None:
            self.set_trust_threshold(trust_threshold)
        
        # Notify subscribers
        self._notify_subscribers("canvas_imported", {
            "metadata": import_data.get("metadata", {})
        })
        
        return True
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Check if context includes an entity
        entity_id = context_data.get("entity_id")
        if entity_id and entity_id in self.entities:
            self.focus_on_entity(entity_id)
        
        # Check if context includes a relationship
        relationship_id = context_data.get("relationship_id")
        if relationship_id and relationship_id in self.relationships:
            self.focus_on_relationship(relationship_id)
        
        # Check if context includes a view
        view_id = context_data.get("view_id")
        if view_id and view_id in self.views:
            self.set_active_view(view_id)
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        # Handle canvas mode toggle
        if input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+M":
            # Cycle through canvas modes
            current_mode = self.canvas_mode
            modes = [
                self.MODE_OVERVIEW,
                self.MODE_FOCUS,
                self.MODE_DETAIL,
                self.MODE_EDIT
            ]
            
            current_index = modes.index(current_mode) if current_mode in modes else 0
            next_index = (current_index + 1) % len(modes)
            self.set_canvas_mode(modes[next_index])
        
        # Handle view type toggle
        elif input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+V":
            # Cycle through view types
            current_type = self.view_type
            types = [
                self.VIEW_ORTHOGRAPHIC,
                self.VIEW_PERSPECTIVE,
                self.VIEW_IMMERSIVE
            ]
            
            current_index = types.index(current_type) if current_type in types else 0
            next_index = (current_index + 1) % len(types)
            self.set_view_type(types[next_index])
        
        # Handle reset view
        elif input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+R":
            self.reset_view()
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        # Handle entity-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "entity_update":
            # Update entity if available
            entity_id = message.get("entity_id")
            entity_data = message.get("entity_data")
            
            if entity_id and entity_data and entity_id in self.entities:
                self.update_entity(entity_id, entity_data)
        
        elif message_type == "relationship_update":
            # Update relationship if available
            relationship_id = message.get("relationship_id")
            relationship_data = message.get("relationship_data")
            
            if relationship_id and relationship_data and relationship_id in self.relationships:
                self.update_relationship(relationship_id, relationship_data)
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        # Handle canvas-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "canvas_request":
            # Handle request to focus on entity or relationship
            entity_id = message.get("entity_id")
            relationship_id = message.get("relationship_id")
            
            if entity_id and entity_id in self.entities:
                self.focus_on_entity(entity_id)
            elif relationship_id and relationship_id in self.relationships:
                self.focus_on_relationship(relationship_id)
    
    def _on_avatar_state_changed(self, event_data: Dict[str, Any]):
        """
        Handle avatar state changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Avatar state changed: %s", event_data)
        
        avatar_id = event_data.get("avatar_id")
        state = event_data.get("state")
        
        # Check if avatar has a corresponding entity
        for entity_id, entity in self.entities.items():
            if entity.get("type") == self.ENTITY_AGENT and entity.get("metadata", {}).get("avatar_id") == avatar_id:
                # Update entity based on avatar state
                updates = {}
                
                if "status" in state:
                    updates["metadata"] = entity.get("metadata", {})
                    updates["metadata"]["status"] = state["status"]
                
                if "trust_level" in state:
                    updates["trust_level"] = state["trust_level"]
                
                if "position" in state:
                    updates["position"] = state["position"]
                
                if updates:
                    self.update_entity(entity_id, updates)
    
    def _on_capsule_state_changed(self, event_data: Dict[str, Any]):
        """
        Handle capsule state changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule state changed: %s", event_data)
        
        capsule_id = event_data.get("capsule_id")
        state = event_data.get("state")
        
        # Check if capsule has a corresponding entity
        for entity_id, entity in self.entities.items():
            if entity.get("metadata", {}).get("capsule_id") == capsule_id:
                # Update entity based on capsule state
                updates = {}
                
                if "status" in state:
                    updates["metadata"] = entity.get("metadata", {})
                    updates["metadata"]["status"] = state["status"]
                
                if "trust_level" in state:
                    updates["trust_level"] = state["trust_level"]
                
                if "color" in state:
                    updates["color"] = state["color"]
                
                if updates:
                    self.update_entity(entity_id, updates)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Spatial Canvas events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Spatial Canvas events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
