"""
Action Menu Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Action Menu, which provides contextual actions and
commands based on the current user focus, active agents, and system state.
The menu adapts its content dynamically to provide the most relevant actions
for the current context, with support for voice, gesture, and traditional input.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union
import json
import os
import time
import math
import re
import uuid

# Initialize logger
logger = logging.getLogger(__name__)

class ActionMenu:
    """
    Action Menu component for providing contextual actions and commands
    based on the current user focus, active agents, and system state.
    """
    
    # Action category constants
    CATEGORY_FREQUENT = "frequent"
    CATEGORY_CONTEXTUAL = "contextual"
    CATEGORY_SYSTEM = "system"
    CATEGORY_AGENT = "agent"
    CATEGORY_WORKFLOW = "workflow"
    CATEGORY_NAVIGATION = "navigation"
    CATEGORY_TOOLS = "tools"
    
    # Action type constants
    TYPE_COMMAND = "command"
    TYPE_NAVIGATION = "navigation"
    TYPE_TOGGLE = "toggle"
    TYPE_MODAL = "modal"
    TYPE_SUBMENU = "submenu"
    
    # Input mode constants
    INPUT_KEYBOARD = "keyboard"
    INPUT_VOICE = "voice"
    INPUT_GESTURE = "gesture"
    INPUT_TOUCH = "touch"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Action Menu component with optional configuration."""
        self.config = config or {}
        self.actions = {}
        self.categories = {}
        self.recent_actions = []
        self.frequent_actions = {}
        self.contextual_actions = {}
        self.menu_visibility = False
        self.menu_position = {"x": 0, "y": 0}
        self.menu_anchor = "cursor"  # cursor, center, top-right, etc.
        self.menu_mode = "radial"  # radial, list, grid, voice
        self.active_category = self.CATEGORY_CONTEXTUAL
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.capsule_manager = None
        self.avatar_manager = None
        
        # Initialize action categories
        self._initialize_categories()
        
        logger.info("Action Menu component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, capsule_manager=None, avatar_manager=None):
        """Initialize the Action Menu component and connect to required services."""
        logger.info("Initializing Action Menu component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.capsule_manager = capsule_manager
        self.avatar_manager = avatar_manager
        
        # Register default actions
        self._register_default_actions()
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
            self.context_engine.subscribe_to_events("focus_changed", self._on_focus_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
            self.interaction_orchestrator.subscribe_to_events("gesture_detected", self._on_gesture_detected)
        
        if self.capsule_manager:
            self.capsule_manager.subscribe_to_events("capsule_activated", self._on_capsule_activated)
            self.capsule_manager.subscribe_to_events("capsule_deactivated", self._on_capsule_deactivated)
        
        logger.info("Action Menu component initialization complete")
        return True
    
    def _initialize_categories(self):
        """Initialize action categories with default settings."""
        logger.info("Initializing action categories")
        
        self.categories = {
            self.CATEGORY_FREQUENT: {
                "id": self.CATEGORY_FREQUENT,
                "name": "Frequent",
                "icon": "star_icon",
                "order": 0,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_CONTEXTUAL: {
                "id": self.CATEGORY_CONTEXTUAL,
                "name": "Contextual",
                "icon": "context_icon",
                "order": 1,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_SYSTEM: {
                "id": self.CATEGORY_SYSTEM,
                "name": "System",
                "icon": "system_icon",
                "order": 2,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_AGENT: {
                "id": self.CATEGORY_AGENT,
                "name": "Agent",
                "icon": "agent_icon",
                "order": 3,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_WORKFLOW: {
                "id": self.CATEGORY_WORKFLOW,
                "name": "Workflow",
                "icon": "workflow_icon",
                "order": 4,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_NAVIGATION: {
                "id": self.CATEGORY_NAVIGATION,
                "name": "Navigation",
                "icon": "navigation_icon",
                "order": 5,
                "visible": True,
                "actions": []
            },
            self.CATEGORY_TOOLS: {
                "id": self.CATEGORY_TOOLS,
                "name": "Tools",
                "icon": "tools_icon",
                "order": 6,
                "visible": True,
                "actions": []
            }
        }
    
    def _register_default_actions(self):
        """Register default actions for the menu."""
        logger.info("Registering default actions")
        
        # System actions
        self.register_action({
            "id": "system_dashboard",
            "name": "Dashboard",
            "description": "Open system dashboard",
            "icon": "dashboard_icon",
            "category": self.CATEGORY_SYSTEM,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Ctrl+D",
            "voice_command": "open dashboard",
            "gesture": "swipe_up",
            "handler": self._handle_system_dashboard
        })
        
        self.register_action({
            "id": "system_settings",
            "name": "Settings",
            "description": "Open system settings",
            "icon": "settings_icon",
            "category": self.CATEGORY_SYSTEM,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Ctrl+,",
            "voice_command": "open settings",
            "gesture": "circle",
            "handler": self._handle_system_settings
        })
        
        self.register_action({
            "id": "system_help",
            "name": "Help",
            "description": "Open help and documentation",
            "icon": "help_icon",
            "category": self.CATEGORY_SYSTEM,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "F1",
            "voice_command": "open help",
            "gesture": "question_mark",
            "handler": self._handle_system_help
        })
        
        # Navigation actions
        self.register_action({
            "id": "navigation_home",
            "name": "Home",
            "description": "Go to home screen",
            "icon": "home_icon",
            "category": self.CATEGORY_NAVIGATION,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Alt+Home",
            "voice_command": "go home",
            "gesture": "home",
            "handler": self._handle_navigation_home
        })
        
        self.register_action({
            "id": "navigation_back",
            "name": "Back",
            "description": "Go back to previous screen",
            "icon": "back_icon",
            "category": self.CATEGORY_NAVIGATION,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Alt+Left",
            "voice_command": "go back",
            "gesture": "swipe_right",
            "handler": self._handle_navigation_back
        })
        
        self.register_action({
            "id": "navigation_forward",
            "name": "Forward",
            "description": "Go forward to next screen",
            "icon": "forward_icon",
            "category": self.CATEGORY_NAVIGATION,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Alt+Right",
            "voice_command": "go forward",
            "gesture": "swipe_left",
            "handler": self._handle_navigation_forward
        })
        
        # Agent actions
        self.register_action({
            "id": "agent_create",
            "name": "Create Agent",
            "description": "Create a new agent",
            "icon": "create_agent_icon",
            "category": self.CATEGORY_AGENT,
            "type": self.TYPE_MODAL,
            "shortcut": "Ctrl+N",
            "voice_command": "create agent",
            "gesture": "agent_plus",
            "handler": self._handle_agent_create
        })
        
        self.register_action({
            "id": "agent_list",
            "name": "Agent List",
            "description": "View all agents",
            "icon": "agent_list_icon",
            "category": self.CATEGORY_AGENT,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Ctrl+Shift+A",
            "voice_command": "show agents",
            "gesture": "agent_list",
            "handler": self._handle_agent_list
        })
        
        # Workflow actions
        self.register_action({
            "id": "workflow_create",
            "name": "Create Workflow",
            "description": "Create a new workflow",
            "icon": "create_workflow_icon",
            "category": self.CATEGORY_WORKFLOW,
            "type": self.TYPE_MODAL,
            "shortcut": "Ctrl+Shift+N",
            "voice_command": "create workflow",
            "gesture": "workflow_plus",
            "handler": self._handle_workflow_create
        })
        
        self.register_action({
            "id": "workflow_list",
            "name": "Workflow List",
            "description": "View all workflows",
            "icon": "workflow_list_icon",
            "category": self.CATEGORY_WORKFLOW,
            "type": self.TYPE_NAVIGATION,
            "shortcut": "Ctrl+Shift+W",
            "voice_command": "show workflows",
            "gesture": "workflow_list",
            "handler": self._handle_workflow_list
        })
        
        # Tool actions
        self.register_action({
            "id": "tool_search",
            "name": "Search",
            "description": "Search for content",
            "icon": "search_icon",
            "category": self.CATEGORY_TOOLS,
            "type": self.TYPE_MODAL,
            "shortcut": "Ctrl+F",
            "voice_command": "search for",
            "gesture": "magnify",
            "handler": self._handle_tool_search
        })
        
        self.register_action({
            "id": "tool_capture",
            "name": "Capture",
            "description": "Capture screen or content",
            "icon": "capture_icon",
            "category": self.CATEGORY_TOOLS,
            "type": self.TYPE_MODAL,
            "shortcut": "Ctrl+Shift+C",
            "voice_command": "capture screen",
            "gesture": "camera",
            "handler": self._handle_tool_capture
        })
    
    def register_action(self, action: Dict[str, Any]) -> bool:
        """
        Register a new action with the menu.
        
        Args:
            action: Action definition
        
        Returns:
            bool: True if action was registered successfully, False otherwise
        """
        logger.info("Registering action: %s", action.get("id"))
        
        # Validate required fields
        required_fields = ["id", "name", "category", "type", "handler"]
        for field in required_fields:
            if field not in action:
                logger.warning("Missing required field in action: %s", field)
                return False
        
        # Validate category
        if action["category"] not in self.categories:
            logger.warning("Invalid action category: %s", action["category"])
            return False
        
        # Validate type
        valid_types = [
            self.TYPE_COMMAND,
            self.TYPE_NAVIGATION,
            self.TYPE_TOGGLE,
            self.TYPE_MODAL,
            self.TYPE_SUBMENU
        ]
        
        if action["type"] not in valid_types:
            logger.warning("Invalid action type: %s", action["type"])
            return False
        
        # Add default fields if not present
        if "description" not in action:
            action["description"] = action["name"]
        
        if "icon" not in action:
            action["icon"] = "default_icon"
        
        if "shortcut" not in action:
            action["shortcut"] = ""
        
        if "voice_command" not in action:
            action["voice_command"] = ""
        
        if "gesture" not in action:
            action["gesture"] = ""
        
        if "enabled" not in action:
            action["enabled"] = True
        
        if "visible" not in action:
            action["visible"] = True
        
        if "order" not in action:
            # Get highest order in category and add 1
            category_actions = [a for a in self.actions.values() if a["category"] == action["category"]]
            highest_order = max([a.get("order", 0) for a in category_actions]) if category_actions else -1
            action["order"] = highest_order + 1
        
        # Store action
        self.actions[action["id"]] = action
        
        # Add to category
        if action["id"] not in self.categories[action["category"]]["actions"]:
            self.categories[action["category"]]["actions"].append(action["id"])
        
        # Notify subscribers
        self._notify_subscribers("action_registered", {
            "action_id": action["id"],
            "action": action
        })
        
        return True
    
    def unregister_action(self, action_id: str) -> bool:
        """
        Unregister an action from the menu.
        
        Args:
            action_id: Action identifier
        
        Returns:
            bool: True if action was unregistered successfully, False otherwise
        """
        logger.info("Unregistering action: %s", action_id)
        
        if action_id not in self.actions:
            logger.warning("Action not found: %s", action_id)
            return False
        
        # Get action category
        category = self.actions[action_id]["category"]
        
        # Remove from category
        if action_id in self.categories[category]["actions"]:
            self.categories[category]["actions"].remove(action_id)
        
        # Remove from actions
        del self.actions[action_id]
        
        # Remove from recent actions
        self.recent_actions = [a for a in self.recent_actions if a != action_id]
        
        # Remove from frequent actions
        if action_id in self.frequent_actions:
            del self.frequent_actions[action_id]
        
        # Remove from contextual actions
        for context, actions in self.contextual_actions.items():
            if action_id in actions:
                actions.remove(action_id)
        
        # Notify subscribers
        self._notify_subscribers("action_unregistered", {
            "action_id": action_id
        })
        
        return True
    
    def get_action(self, action_id: str) -> Optional[Dict[str, Any]]:
        """
        Get action by ID.
        
        Args:
            action_id: Action identifier
        
        Returns:
            Optional[Dict[str, Any]]: Action if found, None otherwise
        """
        if action_id in self.actions:
            return self.actions[action_id]
        else:
            logger.warning("Action not found: %s", action_id)
            return None
    
    def get_actions_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Get actions by category.
        
        Args:
            category: Category identifier
        
        Returns:
            List[Dict[str, Any]]: List of actions in the category
        """
        if category not in self.categories:
            logger.warning("Category not found: %s", category)
            return []
        
        # Get action IDs in category
        action_ids = self.categories[category]["actions"]
        
        # Get actions
        actions = []
        for action_id in action_ids:
            if action_id in self.actions:
                actions.append(self.actions[action_id])
        
        # Sort by order
        actions.sort(key=lambda a: a.get("order", 0))
        
        return actions
    
    def get_all_actions(self) -> List[Dict[str, Any]]:
        """
        Get all registered actions.
        
        Returns:
            List[Dict[str, Any]]: List of all actions
        """
        return list(self.actions.values())
    
    def get_recent_actions(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get recently used actions.
        
        Args:
            limit: Maximum number of actions to return
        
        Returns:
            List[Dict[str, Any]]: List of recent actions
        """
        # Get recent action IDs
        recent_ids = self.recent_actions[-limit:]
        
        # Get actions
        actions = []
        for action_id in reversed(recent_ids):
            if action_id in self.actions:
                actions.append(self.actions[action_id])
        
        return actions
    
    def get_frequent_actions(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get frequently used actions.
        
        Args:
            limit: Maximum number of actions to return
        
        Returns:
            List[Dict[str, Any]]: List of frequent actions
        """
        # Sort frequent actions by count
        sorted_actions = sorted(self.frequent_actions.items(), key=lambda x: x[1], reverse=True)
        
        # Get top action IDs
        top_ids = [action_id for action_id, count in sorted_actions[:limit]]
        
        # Get actions
        actions = []
        for action_id in top_ids:
            if action_id in self.actions:
                actions.append(self.actions[action_id])
        
        return actions
    
    def get_contextual_actions(self, context_type: str) -> List[Dict[str, Any]]:
        """
        Get contextual actions for a specific context.
        
        Args:
            context_type: Context type
        
        Returns:
            List[Dict[str, Any]]: List of contextual actions
        """
        if context_type not in self.contextual_actions:
            logger.warning("Context type not found: %s", context_type)
            return []
        
        # Get action IDs for context
        action_ids = self.contextual_actions[context_type]
        
        # Get actions
        actions = []
        for action_id in action_ids:
            if action_id in self.actions:
                actions.append(self.actions[action_id])
        
        # Sort by order
        actions.sort(key=lambda a: a.get("order", 0))
        
        return actions
    
    def register_contextual_actions(self, context_type: str, action_ids: List[str]) -> bool:
        """
        Register actions as contextual for a specific context.
        
        Args:
            context_type: Context type
            action_ids: List of action identifiers
        
        Returns:
            bool: True if actions were registered successfully, False otherwise
        """
        logger.info("Registering contextual actions for context: %s", context_type)
        
        # Validate action IDs
        valid_ids = []
        for action_id in action_ids:
            if action_id in self.actions:
                valid_ids.append(action_id)
            else:
                logger.warning("Action not found: %s", action_id)
        
        # Store contextual actions
        self.contextual_actions[context_type] = valid_ids
        
        # Notify subscribers
        self._notify_subscribers("contextual_actions_registered", {
            "context_type": context_type,
            "action_ids": valid_ids
        })
        
        return True
    
    def execute_action(self, action_id: str, params: Optional[Dict[str, Any]] = None) -> bool:
        """
        Execute an action.
        
        Args:
            action_id: Action identifier
            params: Optional parameters for the action
        
        Returns:
            bool: True if action was executed successfully, False otherwise
        """
        logger.info("Executing action: %s", action_id)
        
        if action_id not in self.actions:
            logger.warning("Action not found: %s", action_id)
            return False
        
        action = self.actions[action_id]
        
        # Check if action is enabled
        if not action.get("enabled", True):
            logger.warning("Action is disabled: %s", action_id)
            return False
        
        # Add to recent actions
        if action_id in self.recent_actions:
            self.recent_actions.remove(action_id)
        self.recent_actions.append(action_id)
        
        # Limit recent actions size
        max_recent = 20
        if len(self.recent_actions) > max_recent:
            self.recent_actions = self.recent_actions[-max_recent:]
        
        # Update frequent actions
        if action_id not in self.frequent_actions:
            self.frequent_actions[action_id] = 0
        self.frequent_actions[action_id] += 1
        
        # Execute action handler
        try:
            handler = action["handler"]
            result = handler(params or {})
            
            # Notify subscribers
            self._notify_subscribers("action_executed", {
                "action_id": action_id,
                "params": params,
                "result": result
            })
            
            return True
        except Exception as e:
            logger.error("Error executing action: %s - %s", action_id, e)
            return False
    
    def show_menu(self, position: Optional[Dict[str, float]] = None, 
                 anchor: Optional[str] = None, mode: Optional[str] = None) -> bool:
        """
        Show the action menu.
        
        Args:
            position: Optional position for the menu
            anchor: Optional anchor point for the menu
            mode: Optional menu mode
        
        Returns:
            bool: True if menu was shown successfully, False otherwise
        """
        logger.info("Showing action menu")
        
        # Update menu properties
        if position:
            self.menu_position = position
        
        if anchor:
            self.menu_anchor = anchor
        
        if mode:
            self.menu_mode = mode
        
        # Show menu
        self.menu_visibility = True
        
        # Notify subscribers
        self._notify_subscribers("menu_shown", {
            "position": self.menu_position,
            "anchor": self.menu_anchor,
            "mode": self.menu_mode
        })
        
        return True
    
    def hide_menu(self) -> bool:
        """
        Hide the action menu.
        
        Returns:
            bool: True if menu was hidden successfully, False otherwise
        """
        logger.info("Hiding action menu")
        
        # Hide menu
        self.menu_visibility = False
        
        # Notify subscribers
        self._notify_subscribers("menu_hidden", {})
        
        return True
    
    def is_menu_visible(self) -> bool:
        """
        Check if menu is visible.
        
        Returns:
            bool: True if menu is visible, False otherwise
        """
        return self.menu_visibility
    
    def set_active_category(self, category: str) -> bool:
        """
        Set the active category.
        
        Args:
            category: Category identifier
        
        Returns:
            bool: True if category was set successfully, False otherwise
        """
        logger.info("Setting active category: %s", category)
        
        if category not in self.categories:
            logger.warning("Category not found: %s", category)
            return False
        
        self.active_category = category
        
        # Notify subscribers
        self._notify_subscribers("active_category_changed", {
            "category": category
        })
        
        return True
    
    def get_active_category(self) -> str:
        """
        Get the active category.
        
        Returns:
            str: Active category
        """
        return self.active_category
    
    def set_category_visibility(self, category: str, visible: bool) -> bool:
        """
        Set visibility of a category.
        
        Args:
            category: Category identifier
            visible: Whether category should be visible
        
        Returns:
            bool: True if visibility was set successfully, False otherwise
        """
        logger.info("Setting category visibility: %s -> %s", category, visible)
        
        if category not in self.categories:
            logger.warning("Category not found: %s", category)
            return False
        
        self.categories[category]["visible"] = visible
        
        # Notify subscribers
        self._notify_subscribers("category_visibility_changed", {
            "category": category,
            "visible": visible
        })
        
        return True
    
    def get_category_visibility(self, category: str) -> Optional[bool]:
        """
        Get visibility of a category.
        
        Args:
            category: Category identifier
        
        Returns:
            Optional[bool]: Whether category is visible if found, None otherwise
        """
        if category not in self.categories:
            logger.warning("Category not found: %s", category)
            return None
        
        return self.categories[category]["visible"]
    
    def get_all_categories(self) -> List[Dict[str, Any]]:
        """
        Get all categories.
        
        Returns:
            List[Dict[str, Any]]: List of all categories
        """
        # Convert to list and sort by order
        categories = list(self.categories.values())
        categories.sort(key=lambda c: c.get("order", 0))
        
        return categories
    
    def handle_input(self, input_type: str, input_data: Dict[str, Any]) -> bool:
        """
        Handle input for action menu.
        
        Args:
            input_type: Type of input (keyboard, voice, gesture, touch)
            input_data: Input data
        
        Returns:
            bool: True if input was handled successfully, False otherwise
        """
        logger.info("Handling input: %s", input_type)
        
        if input_type == self.INPUT_KEYBOARD:
            return self._handle_keyboard_input(input_data)
        elif input_type == self.INPUT_VOICE:
            return self._handle_voice_input(input_data)
        elif input_type == self.INPUT_GESTURE:
            return self._handle_gesture_input(input_data)
        elif input_type == self.INPUT_TOUCH:
            return self._handle_touch_input(input_data)
        else:
            logger.warning("Invalid input type: %s", input_type)
            return False
    
    def _handle_keyboard_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Handle keyboard input.
        
        Args:
            input_data: Keyboard input data
        
        Returns:
            bool: True if input was handled successfully, False otherwise
        """
        shortcut = input_data.get("shortcut")
        
        if not shortcut:
            return False
        
        # Find action with matching shortcut
        for action_id, action in self.actions.items():
            if action.get("shortcut") == shortcut and action.get("enabled", True):
                return self.execute_action(action_id)
        
        return False
    
    def _handle_voice_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Handle voice input.
        
        Args:
            input_data: Voice input data
        
        Returns:
            bool: True if input was handled successfully, False otherwise
        """
        command = input_data.get("command", "").lower()
        
        if not command:
            return False
        
        # Find action with matching voice command
        for action_id, action in self.actions.items():
            voice_command = action.get("voice_command", "").lower()
            
            if voice_command and command.startswith(voice_command) and action.get("enabled", True):
                # Extract parameters from command
                params = {}
                if len(command) > len(voice_command):
                    params["text"] = command[len(voice_command):].strip()
                
                return self.execute_action(action_id, params)
        
        return False
    
    def _handle_gesture_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Handle gesture input.
        
        Args:
            input_data: Gesture input data
        
        Returns:
            bool: True if input was handled successfully, False otherwise
        """
        gesture = input_data.get("gesture")
        
        if not gesture:
            return False
        
        # Find action with matching gesture
        for action_id, action in self.actions.items():
            if action.get("gesture") == gesture and action.get("enabled", True):
                return self.execute_action(action_id)
        
        return False
    
    def _handle_touch_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Handle touch input.
        
        Args:
            input_data: Touch input data
        
        Returns:
            bool: True if input was handled successfully, False otherwise
        """
        # If menu is not visible, show it
        if not self.menu_visibility:
            position = {
                "x": input_data.get("x", 0),
                "y": input_data.get("y", 0)
            }
            
            return self.show_menu(position=position, anchor="touch")
        
        # If menu is visible, check if touch is on an action
        action_id = input_data.get("action_id")
        
        if action_id and action_id in self.actions:
            return self.execute_action(action_id)
        
        # If touch is outside menu, hide it
        if input_data.get("outside_menu", False):
            return self.hide_menu()
        
        return False
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        
        if context_type and context_type in self.contextual_actions:
            # Set active category to contextual
            self.set_active_category(self.CATEGORY_CONTEXTUAL)
            
            # Update contextual category actions
            self.categories[self.CATEGORY_CONTEXTUAL]["actions"] = self.contextual_actions[context_type]
            
            # Notify subscribers
            self._notify_subscribers("contextual_actions_updated", {
                "context_type": context_type,
                "action_ids": self.contextual_actions[context_type]
            })
    
    def _on_focus_changed(self, event_data: Dict[str, Any]):
        """
        Handle focus changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Focus changed: %s", event_data)
        
        focus_type = event_data.get("focus_type")
        
        # Map focus type to context type
        focus_to_context = {
            "agent": "agent",
            "workflow": "workflow",
            "task": "task",
            "resource": "resource",
            "alert": "alert",
            "system": "system",
            "user": "user"
        }
        
        if focus_type in focus_to_context:
            context_type = focus_to_context[focus_type]
            
            if context_type in self.contextual_actions:
                # Set active category to contextual
                self.set_active_category(self.CATEGORY_CONTEXTUAL)
                
                # Update contextual category actions
                self.categories[self.CATEGORY_CONTEXTUAL]["actions"] = self.contextual_actions[context_type]
                
                # Notify subscribers
                self._notify_subscribers("contextual_actions_updated", {
                    "context_type": context_type,
                    "action_ids": self.contextual_actions[context_type]
                })
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        if input_type:
            self.handle_input(input_type, input_data)
    
    def _on_gesture_detected(self, event_data: Dict[str, Any]):
        """
        Handle gesture detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Gesture detected: %s", event_data)
        
        gesture = event_data.get("gesture")
        
        if gesture:
            self.handle_input(self.INPUT_GESTURE, {"gesture": gesture})
    
    def _on_capsule_activated(self, event_data: Dict[str, Any]):
        """
        Handle capsule activated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule activated: %s", event_data)
        
        capsule_type = event_data.get("capsule_type")
        
        if capsule_type and capsule_type in self.contextual_actions:
            # Set active category to contextual
            self.set_active_category(self.CATEGORY_CONTEXTUAL)
            
            # Update contextual category actions
            self.categories[self.CATEGORY_CONTEXTUAL]["actions"] = self.contextual_actions[capsule_type]
            
            # Notify subscribers
            self._notify_subscribers("contextual_actions_updated", {
                "context_type": capsule_type,
                "action_ids": self.contextual_actions[capsule_type]
            })
    
    def _on_capsule_deactivated(self, event_data: Dict[str, Any]):
        """
        Handle capsule deactivated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule deactivated: %s", event_data)
        
        # Reset to system context
        if "system" in self.contextual_actions:
            # Set active category to contextual
            self.set_active_category(self.CATEGORY_CONTEXTUAL)
            
            # Update contextual category actions
            self.categories[self.CATEGORY_CONTEXTUAL]["actions"] = self.contextual_actions["system"]
            
            # Notify subscribers
            self._notify_subscribers("contextual_actions_updated", {
                "context_type": "system",
                "action_ids": self.contextual_actions["system"]
            })
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Action Menu events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Action Menu events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    # Default action handlers
    
    def _handle_system_dashboard(self, params: Dict[str, Any]) -> bool:
        """
        Handle system dashboard action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling system dashboard action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("dashboard")
        
        return False
    
    def _handle_system_settings(self, params: Dict[str, Any]) -> bool:
        """
        Handle system settings action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling system settings action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("settings")
        
        return False
    
    def _handle_system_help(self, params: Dict[str, Any]) -> bool:
        """
        Handle system help action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling system help action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("help")
        
        return False
    
    def _handle_navigation_home(self, params: Dict[str, Any]) -> bool:
        """
        Handle navigation home action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling navigation home action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("home")
        
        return False
    
    def _handle_navigation_back(self, params: Dict[str, Any]) -> bool:
        """
        Handle navigation back action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling navigation back action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_back()
        
        return False
    
    def _handle_navigation_forward(self, params: Dict[str, Any]) -> bool:
        """
        Handle navigation forward action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling navigation forward action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_forward()
        
        return False
    
    def _handle_agent_create(self, params: Dict[str, Any]) -> bool:
        """
        Handle agent create action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling agent create action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.show_modal("agent_create")
        
        return False
    
    def _handle_agent_list(self, params: Dict[str, Any]) -> bool:
        """
        Handle agent list action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling agent list action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("agent_list")
        
        return False
    
    def _handle_workflow_create(self, params: Dict[str, Any]) -> bool:
        """
        Handle workflow create action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling workflow create action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.show_modal("workflow_create")
        
        return False
    
    def _handle_workflow_list(self, params: Dict[str, Any]) -> bool:
        """
        Handle workflow list action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling workflow list action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.navigate_to("workflow_list")
        
        return False
    
    def _handle_tool_search(self, params: Dict[str, Any]) -> bool:
        """
        Handle tool search action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling tool search action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.show_modal("search", params)
        
        return False
    
    def _handle_tool_capture(self, params: Dict[str, Any]) -> bool:
        """
        Handle tool capture action.
        
        Args:
            params: Action parameters
        
        Returns:
            bool: True if action was handled successfully, False otherwise
        """
        logger.info("Handling tool capture action")
        
        if self.universal_skin_shell:
            return self.universal_skin_shell.show_modal("capture")
        
        return False
