"""
Haptic Feedback Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements a sophisticated haptic feedback system that provides tactile
responses across different devices and contexts, enhancing the ambient intelligence
experience through touch-based communication.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import uuid
from datetime import datetime
import threading

# Initialize logger
logger = logging.getLogger(__name__)

class HapticFeedback:
    """
    Haptic Feedback component for providing tactile responses
    across different devices within the Universal Skin UI/UX Layer.
    """
    
    # Haptic pattern types
    PATTERN_TAP = "tap"
    PATTERN_DOUBLE_TAP = "double_tap"
    PATTERN_LONG_PRESS = "long_press"
    PATTERN_SUCCESS = "success"
    PATTERN_ERROR = "error"
    PATTERN_WARNING = "warning"
    PATTERN_NOTIFICATION = "notification"
    PATTERN_HEARTBEAT = "heartbeat"
    PATTERN_PULSE = "pulse"
    PATTERN_RAMP_UP = "ramp_up"
    PATTERN_RAMP_DOWN = "ramp_down"
    PATTERN_BUZZ = "buzz"
    PATTERN_CUSTOM = "custom"
    
    # Haptic intensity levels
    INTENSITY_SUBTLE = "subtle"
    INTENSITY_LIGHT = "light"
    INTENSITY_MEDIUM = "medium"
    INTENSITY_STRONG = "strong"
    INTENSITY_MAXIMUM = "maximum"
    
    # Device types
    DEVICE_MOBILE = "mobile"
    DEVICE_TABLET = "tablet"
    DEVICE_WEARABLE = "wearable"
    DEVICE_CONTROLLER = "controller"
    DEVICE_CUSTOM = "custom"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Haptic Feedback component with optional configuration."""
        self.config = config or {}
        self.pattern_registry = {}
        self.active_patterns = set()
        self.feedback_history = []
        self.event_subscribers = {}
        self.device_capabilities = {}
        self.current_device_type = None
        self.universal_skin_shell = None
        self.context_engine = None
        self.device_adapter = None
        
        # Initialize default patterns
        self._initialize_default_patterns()
        
        logger.info("Haptic Feedback component initialized with config: %s", self.config)
    
    def _initialize_default_patterns(self):
        """Initialize default haptic patterns."""
        # Tap pattern
        self.register_pattern({
            "id": "tap",
            "name": "Tap",
            "type": self.PATTERN_TAP,
            "sequence": [
                {"intensity": 0.5, "duration": 50}
            ],
            "enabled": True
        })
        
        # Double tap pattern
        self.register_pattern({
            "id": "double_tap",
            "name": "Double Tap",
            "type": self.PATTERN_DOUBLE_TAP,
            "sequence": [
                {"intensity": 0.5, "duration": 50},
                {"intensity": 0.0, "duration": 100},
                {"intensity": 0.5, "duration": 50}
            ],
            "enabled": True
        })
        
        # Long press pattern
        self.register_pattern({
            "id": "long_press",
            "name": "Long Press",
            "type": self.PATTERN_LONG_PRESS,
            "sequence": [
                {"intensity": 0.3, "duration": 300}
            ],
            "enabled": True
        })
        
        # Success pattern
        self.register_pattern({
            "id": "success",
            "name": "Success",
            "type": self.PATTERN_SUCCESS,
            "sequence": [
                {"intensity": 0.3, "duration": 50},
                {"intensity": 0.0, "duration": 50},
                {"intensity": 0.5, "duration": 100}
            ],
            "enabled": True
        })
        
        # Error pattern
        self.register_pattern({
            "id": "error",
            "name": "Error",
            "type": self.PATTERN_ERROR,
            "sequence": [
                {"intensity": 0.7, "duration": 100},
                {"intensity": 0.0, "duration": 50},
                {"intensity": 0.7, "duration": 100}
            ],
            "enabled": True
        })
        
        # Warning pattern
        self.register_pattern({
            "id": "warning",
            "name": "Warning",
            "type": self.PATTERN_WARNING,
            "sequence": [
                {"intensity": 0.5, "duration": 100},
                {"intensity": 0.0, "duration": 100},
                {"intensity": 0.5, "duration": 100}
            ],
            "enabled": True
        })
        
        # Notification pattern
        self.register_pattern({
            "id": "notification",
            "name": "Notification",
            "type": self.PATTERN_NOTIFICATION,
            "sequence": [
                {"intensity": 0.3, "duration": 50},
                {"intensity": 0.0, "duration": 50},
                {"intensity": 0.3, "duration": 50},
                {"intensity": 0.0, "duration": 50},
                {"intensity": 0.5, "duration": 100}
            ],
            "enabled": True
        })
        
        # Heartbeat pattern
        self.register_pattern({
            "id": "heartbeat",
            "name": "Heartbeat",
            "type": self.PATTERN_HEARTBEAT,
            "sequence": [
                {"intensity": 0.6, "duration": 100},
                {"intensity": 0.0, "duration": 100},
                {"intensity": 0.8, "duration": 100},
                {"intensity": 0.0, "duration": 600}
            ],
            "enabled": True
        })
        
        # Pulse pattern
        self.register_pattern({
            "id": "pulse",
            "name": "Pulse",
            "type": self.PATTERN_PULSE,
            "sequence": [
                {"intensity": 0.0, "duration": 0, "transition": "linear"},
                {"intensity": 0.7, "duration": 300, "transition": "linear"},
                {"intensity": 0.0, "duration": 300, "transition": "linear"}
            ],
            "enabled": True
        })
        
        # Ramp up pattern
        self.register_pattern({
            "id": "ramp_up",
            "name": "Ramp Up",
            "type": self.PATTERN_RAMP_UP,
            "sequence": [
                {"intensity": 0.0, "duration": 0},
                {"intensity": 0.2, "duration": 100, "transition": "linear"},
                {"intensity": 0.4, "duration": 100, "transition": "linear"},
                {"intensity": 0.6, "duration": 100, "transition": "linear"},
                {"intensity": 0.8, "duration": 100, "transition": "linear"}
            ],
            "enabled": True
        })
        
        # Ramp down pattern
        self.register_pattern({
            "id": "ramp_down",
            "name": "Ramp Down",
            "type": self.PATTERN_RAMP_DOWN,
            "sequence": [
                {"intensity": 0.8, "duration": 0},
                {"intensity": 0.6, "duration": 100, "transition": "linear"},
                {"intensity": 0.4, "duration": 100, "transition": "linear"},
                {"intensity": 0.2, "duration": 100, "transition": "linear"},
                {"intensity": 0.0, "duration": 100, "transition": "linear"}
            ],
            "enabled": True
        })
        
        # Buzz pattern
        self.register_pattern({
            "id": "buzz",
            "name": "Buzz",
            "type": self.PATTERN_BUZZ,
            "sequence": [
                {"intensity": 0.7, "duration": 500, "frequency": 200}
            ],
            "enabled": True
        })
    
    def initialize(self, universal_skin_shell=None, context_engine=None, device_adapter=None):
        """Initialize the Haptic Feedback component and connect to required services."""
        logger.info("Initializing Haptic Feedback component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.device_adapter = device_adapter
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.device_adapter:
            self.device_adapter.subscribe_to_events("device_changed", self._on_device_changed)
            self.device_adapter.subscribe_to_events("capabilities_changed", self._on_capabilities_changed)
            
            # Get current device type and capabilities
            device_info = self.device_adapter.get_current_device_info()
            if device_info:
                self.current_device_type = device_info.get("type")
                self.device_capabilities = device_info.get("capabilities", {})
        
        logger.info("Haptic Feedback component initialization complete")
        return True
    
    def register_pattern(self, pattern_data: Dict[str, Any]) -> Optional[str]:
        """
        Register a new haptic pattern.
        
        Args:
            pattern_data: Pattern data
        
        Returns:
            Optional[str]: Pattern ID if registered successfully, None otherwise
        """
        logger.info("Registering pattern: %s", pattern_data.get("name", ""))
        
        # Validate required fields
        required_fields = ["name", "type", "sequence"]
        for field in required_fields:
            if field not in pattern_data:
                logger.warning("Missing required field in pattern: %s", field)
                return None
        
        # Generate pattern ID if not provided
        pattern_id = pattern_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "enabled" not in pattern_data:
            pattern_data["enabled"] = True
        
        if "metadata" not in pattern_data:
            pattern_data["metadata"] = {}
        
        if "created_at" not in pattern_data:
            pattern_data["created_at"] = datetime.now().isoformat()
        
        # Store pattern ID
        pattern_data["id"] = pattern_id
        
        # Store pattern
        self.pattern_registry[pattern_id] = pattern_data
        
        # Add to active patterns if enabled
        if pattern_data["enabled"]:
            self.active_patterns.add(pattern_id)
        
        # Notify subscribers
        self._notify_subscribers("pattern_registered", {
            "pattern_id": pattern_id,
            "pattern": pattern_data
        })
        
        return pattern_id
    
    def update_pattern(self, pattern_id: str, pattern_data: Dict[str, Any]) -> bool:
        """
        Update an existing haptic pattern.
        
        Args:
            pattern_id: Pattern identifier
            pattern_data: Updated pattern data
        
        Returns:
            bool: True if pattern was updated successfully, False otherwise
        """
        logger.info("Updating pattern: %s", pattern_id)
        
        if pattern_id not in self.pattern_registry:
            logger.warning("Pattern not found: %s", pattern_id)
            return False
        
        # Get current pattern data
        current_data = self.pattern_registry[pattern_id]
        
        # Update fields
        for key, value in pattern_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update active patterns
        if current_data["enabled"]:
            self.active_patterns.add(pattern_id)
        else:
            self.active_patterns.discard(pattern_id)
        
        # Notify subscribers
        self._notify_subscribers("pattern_updated", {
            "pattern_id": pattern_id,
            "pattern": current_data
        })
        
        return True
    
    def delete_pattern(self, pattern_id: str) -> bool:
        """
        Delete a haptic pattern.
        
        Args:
            pattern_id: Pattern identifier
        
        Returns:
            bool: True if pattern was deleted successfully, False otherwise
        """
        logger.info("Deleting pattern: %s", pattern_id)
        
        if pattern_id not in self.pattern_registry:
            logger.warning("Pattern not found: %s", pattern_id)
            return False
        
        # Remove pattern
        del self.pattern_registry[pattern_id]
        
        # Remove from active patterns
        self.active_patterns.discard(pattern_id)
        
        # Notify subscribers
        self._notify_subscribers("pattern_deleted", {
            "pattern_id": pattern_id
        })
        
        return True
    
    def get_pattern(self, pattern_id: str) -> Optional[Dict[str, Any]]:
        """
        Get pattern by ID.
        
        Args:
            pattern_id: Pattern identifier
        
        Returns:
            Optional[Dict[str, Any]]: Pattern if found, None otherwise
        """
        if pattern_id in self.pattern_registry:
            return self.pattern_registry[pattern_id]
        else:
            logger.warning("Pattern not found: %s", pattern_id)
            return None
    
    def get_all_patterns(self, pattern_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all patterns, optionally filtered by type.
        
        Args:
            pattern_type: Optional pattern type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of patterns
        """
        patterns = list(self.pattern_registry.values())
        
        if pattern_type:
            patterns = [p for p in patterns if p.get("type") == pattern_type]
        
        return patterns
    
    def get_active_patterns(self, pattern_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get active patterns, optionally filtered by type.
        
        Args:
            pattern_type: Optional pattern type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of active patterns
        """
        active_patterns = [self.pattern_registry[pid] for pid in self.active_patterns 
                         if pid in self.pattern_registry]
        
        if pattern_type:
            active_patterns = [p for p in active_patterns if p.get("type") == pattern_type]
        
        return active_patterns
    
    def enable_pattern(self, pattern_id: str) -> bool:
        """
        Enable a haptic pattern.
        
        Args:
            pattern_id: Pattern identifier
        
        Returns:
            bool: True if pattern was enabled successfully, False otherwise
        """
        logger.info("Enabling pattern: %s", pattern_id)
        
        if pattern_id not in self.pattern_registry:
            logger.warning("Pattern not found: %s", pattern_id)
            return False
        
        # Update pattern
        self.pattern_registry[pattern_id]["enabled"] = True
        
        # Add to active patterns
        self.active_patterns.add(pattern_id)
        
        # Notify subscribers
        self._notify_subscribers("pattern_enabled", {
            "pattern_id": pattern_id
        })
        
        return True
    
    def disable_pattern(self, pattern_id: str) -> bool:
        """
        Disable a haptic pattern.
        
        Args:
            pattern_id: Pattern identifier
        
        Returns:
            bool: True if pattern was disabled successfully, False otherwise
        """
        logger.info("Disabling pattern: %s", pattern_id)
        
        if pattern_id not in self.pattern_registry:
            logger.warning("Pattern not found: %s", pattern_id)
            return False
        
        # Update pattern
        self.pattern_registry[pattern_id]["enabled"] = False
        
        # Remove from active patterns
        self.active_patterns.discard(pattern_id)
        
        # Notify subscribers
        self._notify_subscribers("pattern_disabled", {
            "pattern_id": pattern_id
        })
        
        return True
    
    def enable_patterns_by_type(self, pattern_type: str) -> int:
        """
        Enable all patterns of a specific type.
        
        Args:
            pattern_type: Pattern type
        
        Returns:
            int: Number of patterns enabled
        """
        logger.info("Enabling patterns of type: %s", pattern_type)
        
        count = 0
        for pattern_id, pattern in self.pattern_registry.items():
            if pattern.get("type") == pattern_type and not pattern.get("enabled", False):
                pattern["enabled"] = True
                self.active_patterns.add(pattern_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("patterns_enabled_by_type", {
                "pattern_type": pattern_type,
                "count": count
            })
        
        return count
    
    def disable_patterns_by_type(self, pattern_type: str) -> int:
        """
        Disable all patterns of a specific type.
        
        Args:
            pattern_type: Pattern type
        
        Returns:
            int: Number of patterns disabled
        """
        logger.info("Disabling patterns of type: %s", pattern_type)
        
        count = 0
        for pattern_id, pattern in self.pattern_registry.items():
            if pattern.get("type") == pattern_type and pattern.get("enabled", False):
                pattern["enabled"] = False
                self.active_patterns.discard(pattern_id)
                count += 1
        
        if count > 0:
            # Notify subscribers
            self._notify_subscribers("patterns_disabled_by_type", {
                "pattern_type": pattern_type,
                "count": count
            })
        
        return count
    
    def play_pattern(self, pattern_id_or_type: str, intensity_modifier: float = 1.0, 
                   repeat: int = 1, device_type: Optional[str] = None) -> bool:
        """
        Play a haptic pattern.
        
        Args:
            pattern_id_or_type: Pattern ID or type
            intensity_modifier: Optional intensity modifier (0.0 to 1.0)
            repeat: Number of times to repeat the pattern
            device_type: Optional device type to target
        
        Returns:
            bool: True if pattern was played successfully, False otherwise
        """
        logger.info("Playing pattern: %s", pattern_id_or_type)
        
        # Check if haptic feedback is supported
        if not self._is_haptic_supported(device_type):
            logger.warning("Haptic feedback not supported on current device")
            return False
        
        # Get pattern
        pattern = None
        
        # First try to find by ID
        if pattern_id_or_type in self.pattern_registry:
            pattern = self.pattern_registry[pattern_id_or_type]
        else:
            # Try to find by type
            patterns = self.get_active_patterns(pattern_type=pattern_id_or_type)
            if patterns:
                pattern = patterns[0]
        
        if not pattern:
            logger.warning("Pattern not found: %s", pattern_id_or_type)
            return False
        
        # Check if pattern is enabled
        if not pattern.get("enabled", False):
            logger.warning("Pattern is disabled: %s", pattern_id_or_type)
            return False
        
        # Get sequence
        sequence = pattern.get("sequence", [])
        if not sequence:
            logger.warning("Pattern has no sequence: %s", pattern_id_or_type)
            return False
        
        # Apply intensity modifier
        modified_sequence = []
        for step in sequence:
            modified_step = step.copy()
            if "intensity" in modified_step:
                modified_step["intensity"] = min(1.0, max(0.0, modified_step["intensity"] * intensity_modifier))
            modified_sequence.append(modified_step)
        
        # Play pattern
        success = self._play_haptic_sequence(modified_sequence, repeat, device_type)
        
        if success:
            # Add to history
            history_item = {
                "timestamp": datetime.now().isoformat(),
                "pattern_id": pattern.get("id"),
                "pattern_type": pattern.get("type"),
                "intensity_modifier": intensity_modifier,
                "repeat": repeat,
                "device_type": device_type or self.current_device_type
            }
            
            self.feedback_history.append(history_item)
            
            # Limit history size
            max_history = self.config.get("max_history_size", 100)
            if len(self.feedback_history) > max_history:
                self.feedback_history = self.feedback_history[-max_history:]
            
            # Notify subscribers
            self._notify_subscribers("pattern_played", {
                "pattern_id": pattern.get("id"),
                "pattern_type": pattern.get("type"),
                "intensity_modifier": intensity_modifier,
                "repeat": repeat,
                "device_type": device_type or self.current_device_type
            })
        
        return success
    
    def play_intensity(self, intensity: float, duration: int, 
                     frequency: Optional[float] = None, device_type: Optional[str] = None) -> bool:
        """
        Play a constant intensity haptic feedback.
        
        Args:
            intensity: Intensity level (0.0 to 1.0)
            duration: Duration in milliseconds
            frequency: Optional frequency in Hz
            device_type: Optional device type to target
        
        Returns:
            bool: True if feedback was played successfully, False otherwise
        """
        logger.info("Playing intensity: %f for %d ms", intensity, duration)
        
        # Check if haptic feedback is supported
        if not self._is_haptic_supported(device_type):
            logger.warning("Haptic feedback not supported on current device")
            return False
        
        # Clamp intensity
        intensity = min(1.0, max(0.0, intensity))
        
        # Create sequence
        sequence = [
            {
                "intensity": intensity,
                "duration": duration
            }
        ]
        
        # Add frequency if provided
        if frequency is not None:
            sequence[0]["frequency"] = frequency
        
        # Play sequence
        success = self._play_haptic_sequence(sequence, 1, device_type)
        
        if success:
            # Add to history
            history_item = {
                "timestamp": datetime.now().isoformat(),
                "intensity": intensity,
                "duration": duration,
                "frequency": frequency,
                "device_type": device_type or self.current_device_type
            }
            
            self.feedback_history.append(history_item)
            
            # Limit history size
            max_history = self.config.get("max_history_size", 100)
            if len(self.feedback_history) > max_history:
                self.feedback_history = self.feedback_history[-max_history:]
            
            # Notify subscribers
            self._notify_subscribers("intensity_played", {
                "intensity": intensity,
                "duration": duration,
                "frequency": frequency,
                "device_type": device_type or self.current_device_type
            })
        
        return success
    
    def stop_all(self) -> bool:
        """
        Stop all haptic feedback.
        
        Returns:
            bool: True if feedback was stopped successfully, False otherwise
        """
        logger.info("Stopping all haptic feedback")
        
        # This would typically involve calling the device adapter
        if self.device_adapter:
            # Call stop method
            success = self.device_adapter.stop_haptic_feedback()
        else:
            # No device adapter, assume success
            success = True
        
        if success:
            # Notify subscribers
            self._notify_subscribers("feedback_stopped", {})
        
        return success
    
    def get_feedback_history(self, limit: Optional[int] = None, 
                           pattern_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get haptic feedback history.
        
        Args:
            limit: Optional limit on number of history items to return
            pattern_type: Optional pattern type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of feedback history items
        """
        history = self.feedback_history
        
        if pattern_type:
            history = [h for h in history if h.get("pattern_type") == pattern_type]
        
        if limit:
            history = history[-limit:]
        
        return history
    
    def clear_feedback_history(self) -> bool:
        """
        Clear haptic feedback history.
        
        Returns:
            bool: True if history was cleared successfully
        """
        logger.info("Clearing feedback history")
        
        self.feedback_history = []
        
        # Notify subscribers
        self._notify_subscribers("feedback_history_cleared", {})
        
        return True
    
    def _is_haptic_supported(self, device_type: Optional[str] = None) -> bool:
        """
        Check if haptic feedback is supported on the specified device type.
        
        Args:
            device_type: Optional device type to check
        
        Returns:
            bool: True if haptic feedback is supported, False otherwise
        """
        # Use current device type if not specified
        device_type = device_type or self.current_device_type
        
        # Check if device type is known
        if not device_type:
            return False
        
        # Check device capabilities
        if "haptic" in self.device_capabilities:
            return self.device_capabilities["haptic"]
        
        # Default to True for known device types that typically support haptic feedback
        return device_type in [self.DEVICE_MOBILE, self.DEVICE_TABLET, 
                             self.DEVICE_WEARABLE, self.DEVICE_CONTROLLER]
    
    def _play_haptic_sequence(self, sequence: List[Dict[str, Any]], repeat: int, 
                            device_type: Optional[str] = None) -> bool:
        """
        Play a haptic sequence.
        
        Args:
            sequence: Haptic sequence
            repeat: Number of times to repeat the sequence
            device_type: Optional device type to target
        
        Returns:
            bool: True if sequence was played successfully, False otherwise
        """
        # This would typically involve calling the device adapter
        if self.device_adapter:
            # Call play method
            return self.device_adapter.play_haptic_sequence(sequence, repeat, device_type)
        
        # No device adapter, simulate playback
        logger.info("Simulating haptic sequence playback: %s", sequence)
        
        # Start playback thread
        threading.Thread(target=self._simulate_haptic_playback, 
                       args=(sequence, repeat), daemon=True).start()
        
        return True
    
    def _simulate_haptic_playback(self, sequence: List[Dict[str, Any]], repeat: int):
        """
        Simulate haptic sequence playback.
        
        Args:
            sequence: Haptic sequence
            repeat: Number of times to repeat the sequence
        """
        for _ in range(repeat):
            for step in sequence:
                intensity = step.get("intensity", 0.0)
                duration = step.get("duration", 0)
                frequency = step.get("frequency", None)
                
                logger.debug("Simulating haptic step: intensity=%f, duration=%d, frequency=%s", 
                           intensity, duration, frequency)
                
                # Sleep for duration
                if duration > 0:
                    time.sleep(duration / 1000.0)
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Adjust haptic feedback based on context
        if context_type == "user_context":
            # Adjust for user preferences
            user_id = context_data.get("user_id")
            if user_id:
                logger.info("Adjusting haptic feedback for user: %s", user_id)
                # Apply user preferences
        
        elif context_type == "application_context":
            # Adjust for application needs
            app_id = context_data.get("app_id")
            if app_id:
                logger.info("Adjusting haptic feedback for application: %s", app_id)
                # Enable/disable patterns based on application needs
        
        elif context_type == "environment_context":
            # Adjust for environment
            environment = context_data.get("environment")
            if environment:
                logger.info("Adjusting haptic feedback for environment: %s", environment)
                # Adjust intensity based on environment
    
    def _on_device_changed(self, event_data: Dict[str, Any]):
        """
        Handle device changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Device changed: %s", event_data)
        
        device_type = event_data.get("device_type")
        if device_type:
            logger.info("Device type changed to: %s", device_type)
            self.current_device_type = device_type
    
    def _on_capabilities_changed(self, event_data: Dict[str, Any]):
        """
        Handle capabilities changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capabilities changed: %s", event_data)
        
        capabilities = event_data.get("capabilities", {})
        self.device_capabilities = capabilities
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Haptic Feedback events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Haptic Feedback events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def get_intensity_level(self, level: str) -> float:
        """
        Get intensity value for named intensity level.
        
        Args:
            level: Intensity level name
        
        Returns:
            float: Intensity value (0.0 to 1.0)
        """
        intensity_map = {
            self.INTENSITY_SUBTLE: 0.2,
            self.INTENSITY_LIGHT: 0.4,
            self.INTENSITY_MEDIUM: 0.6,
            self.INTENSITY_STRONG: 0.8,
            self.INTENSITY_MAXIMUM: 1.0
        }
        
        return intensity_map.get(level, 0.5)
    
    def play_named_intensity(self, level: str, duration: int, 
                           frequency: Optional[float] = None, 
                           device_type: Optional[str] = None) -> bool:
        """
        Play a named intensity level haptic feedback.
        
        Args:
            level: Intensity level name
            duration: Duration in milliseconds
            frequency: Optional frequency in Hz
            device_type: Optional device type to target
        
        Returns:
            bool: True if feedback was played successfully, False otherwise
        """
        intensity = self.get_intensity_level(level)
        return self.play_intensity(intensity, duration, frequency, device_type)
    
    def play_trust_feedback(self, trust_score: float, device_type: Optional[str] = None) -> bool:
        """
        Play haptic feedback based on trust score.
        
        Args:
            trust_score: Trust score (0.0 to 1.0)
            device_type: Optional device type to target
        
        Returns:
            bool: True if feedback was played successfully, False otherwise
        """
        logger.info("Playing trust feedback for score: %f", trust_score)
        
        # Clamp trust score
        trust_score = min(1.0, max(0.0, trust_score))
        
        # Determine pattern based on trust score
        if trust_score >= 0.8:
            return self.play_pattern(self.PATTERN_SUCCESS, trust_score, 1, device_type)
        elif trust_score >= 0.6:
            return self.play_pattern(self.PATTERN_PULSE, trust_score, 1, device_type)
        elif trust_score >= 0.4:
            return self.play_pattern(self.PATTERN_TAP, trust_score, 1, device_type)
        elif trust_score >= 0.2:
            return self.play_pattern(self.PATTERN_WARNING, trust_score, 1, device_type)
        else:
            return self.play_pattern(self.PATTERN_ERROR, trust_score, 1, device_type)
    
    def play_notification_feedback(self, priority: str, device_type: Optional[str] = None) -> bool:
        """
        Play haptic feedback for notification.
        
        Args:
            priority: Notification priority (high, medium, low)
            device_type: Optional device type to target
        
        Returns:
            bool: True if feedback was played successfully, False otherwise
        """
        logger.info("Playing notification feedback for priority: %s", priority)
        
        # Determine pattern and intensity based on priority
        if priority.lower() == "high":
            return self.play_pattern(self.PATTERN_NOTIFICATION, 1.0, 1, device_type)
        elif priority.lower() == "medium":
            return self.play_pattern(self.PATTERN_NOTIFICATION, 0.7, 1, device_type)
        else:  # low
            return self.play_pattern(self.PATTERN_NOTIFICATION, 0.4, 1, device_type)
    
    def play_capsule_feedback(self, event_type: str, device_type: Optional[str] = None) -> bool:
        """
        Play haptic feedback for capsule events.
        
        Args:
            event_type: Capsule event type (create, pin, unpin, close, etc.)
            device_type: Optional device type to target
        
        Returns:
            bool: True if feedback was played successfully, False otherwise
        """
        logger.info("Playing capsule feedback for event: %s", event_type)
        
        # Determine pattern based on event type
        if event_type == "create":
            return self.play_pattern(self.PATTERN_SUCCESS, 0.8, 1, device_type)
        elif event_type == "pin":
            return self.play_pattern(self.PATTERN_TAP, 0.9, 1, device_type)
        elif event_type == "unpin":
            return self.play_pattern(self.PATTERN_DOUBLE_TAP, 0.7, 1, device_type)
        elif event_type == "close":
            return self.play_pattern(self.PATTERN_RAMP_DOWN, 0.6, 1, device_type)
        elif event_type == "error":
            return self.play_pattern(self.PATTERN_ERROR, 0.8, 1, device_type)
        else:
            return self.play_pattern(self.PATTERN_TAP, 0.5, 1, device_type)
    
    def play_ambient_pulse(self, intensity: float = 0.3, interval: int = 5000, 
                         device_type: Optional[str] = None) -> bool:
        """
        Start playing ambient pulse haptic feedback.
        
        Args:
            intensity: Pulse intensity (0.0 to 1.0)
            interval: Interval between pulses in milliseconds
            device_type: Optional device type to target
        
        Returns:
            bool: True if ambient pulse was started successfully, False otherwise
        """
        logger.info("Starting ambient pulse with intensity: %f, interval: %d", intensity, interval)
        
        # This would typically involve starting a background thread
        # For now, just simulate starting
        
        # Notify subscribers
        self._notify_subscribers("ambient_pulse_started", {
            "intensity": intensity,
            "interval": interval,
            "device_type": device_type or self.current_device_type
        })
        
        return True
    
    def stop_ambient_pulse(self) -> bool:
        """
        Stop playing ambient pulse haptic feedback.
        
        Returns:
            bool: True if ambient pulse was stopped successfully, False otherwise
        """
        logger.info("Stopping ambient pulse")
        
        # This would typically involve stopping a background thread
        # For now, just simulate stopping
        
        # Notify subscribers
        self._notify_subscribers("ambient_pulse_stopped", {})
        
        return True
