"""
Cross-Layer Integration Module - Enables seamless integration between the UI/UX Layer and all other layers of the Industriverse ecosystem.

This module provides comprehensive integration with all existing layers through the Real-Time Context Bus,
ensuring bidirectional communication, state synchronization, and seamless user experience.
"""

import os
import sys
import json
import logging
import asyncio
import websockets
from typing import Dict, List, Any, Optional, Union, Callable
from enum import Enum

# Core module imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.protocol_bridge.protocol_bridge import ProtocolBridge
from core.cross_layer_integration.real_time_context_bus import RealTimeContextBus

class LayerType(Enum):
    """Enumeration of Industriverse layers."""
    DATA = "data"
    CORE_AI = "core_ai"
    GENERATIVE = "generative"
    APPLICATION = "application"
    PROTOCOL = "protocol"
    WORKFLOW = "workflow"
    UI_UX = "ui_ux"
    SECURITY = "security"

class IntegrationStatus(Enum):
    """Enumeration of integration statuses."""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"

class CrossLayerIntegration:
    """
    Cross-Layer Integration module for the UI/UX Layer.
    
    Provides comprehensive integration with all existing layers through the Real-Time Context Bus,
    ensuring bidirectional communication, state synchronization, and seamless user experience.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the Cross-Layer Integration module.
        
        Args:
            config: Configuration dictionary for cross-layer integration
        """
        self.logger = logging.getLogger(__name__)
        self.config = config or {}
        
        # Initialize protocol bridge
        self.protocol_bridge = ProtocolBridge(
            config=self.config.get('protocol_bridge', {})
        )
        
        # Initialize real-time context bus
        self.real_time_context_bus = RealTimeContextBus(
            protocol_bridge=self.protocol_bridge,
            config=self.config.get('real_time_context_bus', {})
        )
        
        # Layer connection status
        self.layer_status = {
            LayerType.DATA: IntegrationStatus.DISCONNECTED,
            LayerType.CORE_AI: IntegrationStatus.DISCONNECTED,
            LayerType.GENERATIVE: IntegrationStatus.DISCONNECTED,
            LayerType.APPLICATION: IntegrationStatus.DISCONNECTED,
            LayerType.PROTOCOL: IntegrationStatus.DISCONNECTED,
            LayerType.WORKFLOW: IntegrationStatus.DISCONNECTED,
            LayerType.SECURITY: IntegrationStatus.DISCONNECTED
        }
        
        # Layer connection URLs
        self.layer_urls = {
            LayerType.DATA: self.config.get('data_layer_url', 'http://data-layer.industriverse.svc.cluster.local:8080'),
            LayerType.CORE_AI: self.config.get('core_ai_layer_url', 'http://core-ai-layer.industriverse.svc.cluster.local:8080'),
            LayerType.GENERATIVE: self.config.get('generative_layer_url', 'http://generative-layer.industriverse.svc.cluster.local:8080'),
            LayerType.APPLICATION: self.config.get('application_layer_url', 'http://application-layer.industriverse.svc.cluster.local:8080'),
            LayerType.PROTOCOL: self.config.get('protocol_layer_url', 'http://protocol-layer.industriverse.svc.cluster.local:8080'),
            LayerType.WORKFLOW: self.config.get('workflow_layer_url', 'http://workflow-layer.industriverse.svc.cluster.local:8080'),
            LayerType.SECURITY: self.config.get('security_layer_url', 'http://security-layer.industriverse.svc.cluster.local:8080')
        }
        
        # Layer event handlers
        self.layer_event_handlers = {
            LayerType.DATA: {},
            LayerType.CORE_AI: {},
            LayerType.GENERATIVE: {},
            LayerType.APPLICATION: {},
            LayerType.PROTOCOL: {},
            LayerType.WORKFLOW: {},
            LayerType.SECURITY: {}
        }
        
        # Layer subscriptions
        self.layer_subscriptions = {
            LayerType.DATA: set(),
            LayerType.CORE_AI: set(),
            LayerType.GENERATIVE: set(),
            LayerType.APPLICATION: set(),
            LayerType.PROTOCOL: set(),
            LayerType.WORKFLOW: set(),
            LayerType.SECURITY: set()
        }
        
        self.logger.info("Cross-Layer Integration module initialized")
    
    async def connect_to_all_layers(self):
        """Connect to all layers."""
        self.logger.info("Connecting to all layers")
        
        # Connect to the Real-Time Context Bus
        await self.real_time_context_bus.connect()
        
        # Connect to each layer
        for layer_type in LayerType:
            if layer_type != LayerType.UI_UX:  # Don't connect to ourselves
                await self.connect_to_layer(layer_type)
    
    async def connect_to_layer(self, layer_type: LayerType):
        """
        Connect to a specific layer.
        
        Args:
            layer_type: Type of layer to connect to
        """
        if layer_type == LayerType.UI_UX:
            self.logger.warning("Cannot connect to UI/UX layer from UI/UX layer")
            return
        
        self.logger.info(f"Connecting to {layer_type.value} layer")
        self.layer_status[layer_type] = IntegrationStatus.CONNECTING
        
        try:
            # Get layer URL
            layer_url = self.layer_urls[layer_type]
            
            # Connect to layer via Real-Time Context Bus
            await self.real_time_context_bus.subscribe_to_layer(layer_type.value, layer_url)
            
            # Update status
            self.layer_status[layer_type] = IntegrationStatus.CONNECTED
            self.logger.info(f"Connected to {layer_type.value} layer")
            
            # Subscribe to default topics
            await self.subscribe_to_default_topics(layer_type)
        except Exception as e:
            self.layer_status[layer_type] = IntegrationStatus.ERROR
            self.logger.error(f"Failed to connect to {layer_type.value} layer: {str(e)}")
    
    async def subscribe_to_default_topics(self, layer_type: LayerType):
        """
        Subscribe to default topics for a layer.
        
        Args:
            layer_type: Type of layer
        """
        default_topics = {
            LayerType.DATA: ["data.updates", "data.schema", "data.query.results"],
            LayerType.CORE_AI: ["core_ai.models", "core_ai.inference", "core_ai.training"],
            LayerType.GENERATIVE: ["generative.templates", "generative.components", "generative.code"],
            LayerType.APPLICATION: ["application.status", "application.events", "application.user"],
            LayerType.PROTOCOL: ["protocol.mcp", "protocol.a2a", "protocol.discovery"],
            LayerType.WORKFLOW: ["workflow.status", "workflow.events", "workflow.capsules"],
            LayerType.SECURITY: ["security.trust", "security.compliance", "security.audit"]
        }
        
        topics = default_topics.get(layer_type, [])
        for topic in topics:
            await self.subscribe_to_topic(layer_type, topic)
    
    async def subscribe_to_topic(self, layer_type: LayerType, topic: str):
        """
        Subscribe to a topic for a layer.
        
        Args:
            layer_type: Type of layer
            topic: Topic to subscribe to
        """
        if self.layer_status[layer_type] != IntegrationStatus.CONNECTED:
            self.logger.warning(f"Cannot subscribe to topic {topic} for {layer_type.value} layer: not connected")
            return
        
        self.logger.info(f"Subscribing to topic {topic} for {layer_type.value} layer")
        
        try:
            # Subscribe to topic via Real-Time Context Bus
            await self.real_time_context_bus.subscribe_to_topic(f"{layer_type.value}.{topic}")
            
            # Add to subscriptions
            self.layer_subscriptions[layer_type].add(topic)
            
            self.logger.info(f"Subscribed to topic {topic} for {layer_type.value} layer")
        except Exception as e:
            self.logger.error(f"Failed to subscribe to topic {topic} for {layer_type.value} layer: {str(e)}")
    
    async def unsubscribe_from_topic(self, layer_type: LayerType, topic: str):
        """
        Unsubscribe from a topic for a layer.
        
        Args:
            layer_type: Type of layer
            topic: Topic to unsubscribe from
        """
        if topic not in self.layer_subscriptions[layer_type]:
            self.logger.warning(f"Not subscribed to topic {topic} for {layer_type.value} layer")
            return
        
        self.logger.info(f"Unsubscribing from topic {topic} for {layer_type.value} layer")
        
        try:
            # Unsubscribe from topic via Real-Time Context Bus
            await self.real_time_context_bus.unsubscribe_from_topic(f"{layer_type.value}.{topic}")
            
            # Remove from subscriptions
            self.layer_subscriptions[layer_type].remove(topic)
            
            self.logger.info(f"Unsubscribed from topic {topic} for {layer_type.value} layer")
        except Exception as e:
            self.logger.error(f"Failed to unsubscribe from topic {topic} for {layer_type.value} layer: {str(e)}")
    
    def register_event_handler(self, layer_type: LayerType, event_type: str, handler: Callable):
        """
        Register an event handler for a layer.
        
        Args:
            layer_type: Type of layer
            event_type: Type of event
            handler: Event handler function
        """
        if event_type not in self.layer_event_handlers[layer_type]:
            self.layer_event_handlers[layer_type][event_type] = []
        
        self.layer_event_handlers[layer_type][event_type].append(handler)
        self.logger.info(f"Registered event handler for {event_type} events from {layer_type.value} layer")
    
    def unregister_event_handler(self, layer_type: LayerType, event_type: str, handler: Callable):
        """
        Unregister an event handler for a layer.
        
        Args:
            layer_type: Type of layer
            event_type: Type of event
            handler: Event handler function
        """
        if event_type in self.layer_event_handlers[layer_type] and handler in self.layer_event_handlers[layer_type][event_type]:
            self.layer_event_handlers[layer_type][event_type].remove(handler)
            self.logger.info(f"Unregistered event handler for {event_type} events from {layer_type.value} layer")
    
    async def send_event_to_layer(self, layer_type: LayerType, event_type: str, event_data: Dict[str, Any]):
        """
        Send an event to a layer.
        
        Args:
            layer_type: Type of layer
            event_type: Type of event
            event_data: Event data
        """
        if self.layer_status[layer_type] != IntegrationStatus.CONNECTED:
            self.logger.warning(f"Cannot send event to {layer_type.value} layer: not connected")
            return
        
        self.logger.info(f"Sending {event_type} event to {layer_type.value} layer")
        
        try:
            # Create event message
            event_message = {
                "source": "ui_ux",
                "destination": layer_type.value,
                "type": event_type,
                "data": event_data,
                "timestamp": self.real_time_context_bus.get_timestamp()
            }
            
            # Send event via Real-Time Context Bus
            await self.real_time_context_bus.publish_event(f"{layer_type.value}.{event_type}", event_message)
            
            self.logger.info(f"Sent {event_type} event to {layer_type.value} layer")
        except Exception as e:
            self.logger.error(f"Failed to send {event_type} event to {layer_type.value} layer: {str(e)}")
    
    async def handle_incoming_event(self, event: Dict[str, Any]):
        """
        Handle an incoming event from any layer.
        
        Args:
            event: Event data
        """
        source = event.get("source")
        event_type = event.get("type")
        event_data = event.get("data", {})
        
        self.logger.debug(f"Received {event_type} event from {source} layer")
        
        try:
            # Convert source to LayerType
            layer_type = next((lt for lt in LayerType if lt.value == source), None)
            if not layer_type:
                self.logger.warning(f"Received event from unknown layer: {source}")
                return
            
            # Call event handlers
            if event_type in self.layer_event_handlers[layer_type]:
                for handler in self.layer_event_handlers[layer_type][event_type]:
                    try:
                        await handler(event_data)
                    except Exception as e:
                        self.logger.error(f"Error in event handler for {event_type} event from {source} layer: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error handling {event_type} event from {source} layer: {str(e)}")
    
    async def start_event_listener(self):
        """Start the event listener."""
        self.logger.info("Starting event listener")
        
        # Register event handler with Real-Time Context Bus
        self.real_time_context_bus.register_event_handler(self.handle_incoming_event)
        
        # Start the Real-Time Context Bus
        await self.real_time_context_bus.start()
    
    async def stop_event_listener(self):
        """Stop the event listener."""
        self.logger.info("Stopping event listener")
        
        # Stop the Real-Time Context Bus
        await self.real_time_context_bus.stop()
    
    async def disconnect_from_all_layers(self):
        """Disconnect from all layers."""
        self.logger.info("Disconnecting from all layers")
        
        # Disconnect from each layer
        for layer_type in LayerType:
            if layer_type != LayerType.UI_UX:  # Don't disconnect from ourselves
                await self.disconnect_from_layer(layer_type)
        
        # Disconnect from the Real-Time Context Bus
        await self.real_time_context_bus.disconnect()
    
    async def disconnect_from_layer(self, layer_type: LayerType):
        """
        Disconnect from a specific layer.
        
        Args:
            layer_type: Type of layer to disconnect from
        """
        if layer_type == LayerType.UI_UX:
            self.logger.warning("Cannot disconnect from UI/UX layer from UI/UX layer")
            return
        
        if self.layer_status[layer_type] != IntegrationStatus.CONNECTED:
            self.logger.warning(f"Not connected to {layer_type.value} layer")
            return
        
        self.logger.info(f"Disconnecting from {layer_type.value} layer")
        
        try:
            # Unsubscribe from all topics
            for topic in list(self.layer_subscriptions[layer_type]):
                await self.unsubscribe_from_topic(layer_type, topic)
            
            # Disconnect from layer via Real-Time Context Bus
            await self.real_time_context_bus.unsubscribe_from_layer(layer_type.value)
            
            # Update status
            self.layer_status[layer_type] = IntegrationStatus.DISCONNECTED
            
            self.logger.info(f"Disconnected from {layer_type.value} layer")
        except Exception as e:
            self.layer_status[layer_type] = IntegrationStatus.ERROR
            self.logger.error(f"Failed to disconnect from {layer_type.value} layer: {str(e)}")
    
    def get_layer_status(self, layer_type: LayerType) -> IntegrationStatus:
        """
        Get the status of a layer connection.
        
        Args:
            layer_type: Type of layer
            
        Returns:
            Status of the layer connection
        """
        return self.layer_status.get(layer_type, IntegrationStatus.DISCONNECTED)
    
    def get_all_layer_statuses(self) -> Dict[str, str]:
        """
        Get the status of all layer connections.
        
        Returns:
            Dictionary of layer statuses
        """
        return {layer_type.value: status.value for layer_type, status in self.layer_status.items()}
    
    async def test_layer_connection(self, layer_type: LayerType) -> bool:
        """
        Test the connection to a layer.
        
        Args:
            layer_type: Type of layer
            
        Returns:
            True if the connection is working, False otherwise
        """
        if self.layer_status[layer_type] != IntegrationStatus.CONNECTED:
            self.logger.warning(f"Cannot test connection to {layer_type.value} layer: not connected")
            return False
        
        self.logger.info(f"Testing connection to {layer_type.value} layer")
        
        try:
            # Send ping event
            ping_data = {
                "ping": True,
                "timestamp": self.real_time_context_bus.get_timestamp()
            }
            
            # Use a future to wait for the pong response
            pong_future = asyncio.Future()
            
            # Register temporary event handler for pong
            async def pong_handler(event_data):
                pong_future.set_result(True)
            
            self.register_event_handler(layer_type, "pong", pong_handler)
            
            # Send ping event
            await self.send_event_to_layer(layer_type, "ping", ping_data)
            
            # Wait for pong response with timeout
            try:
                await asyncio.wait_for(pong_future, timeout=5.0)
                self.logger.info(f"Connection to {layer_type.value} layer is working")
                return True
            except asyncio.TimeoutError:
                self.logger.warning(f"Connection to {layer_type.value} layer timed out")
                return False
            finally:
                # Unregister temporary event handler
                self.unregister_event_handler(layer_type, "pong", pong_handler)
        except Exception as e:
            self.logger.error(f"Failed to test connection to {layer_type.value} layer: {str(e)}")
            return False

# Factory function to create a cross-layer integration instance
def create_cross_layer_integration(config: Dict[str, Any] = None) -> CrossLayerIntegration:
    """
    Create a cross-layer integration instance.
    
    Args:
        config: Configuration dictionary
        
    Returns:
        CrossLayerIntegration instance
    """
    return CrossLayerIntegration(config)

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Create cross-layer integration
    integration = create_cross_layer_integration()
    
    # Run async code
    async def main():
        # Connect to all layers
        await integration.connect_to_all_layers()
        
        # Start event listener
        await integration.start_event_listener()
        
        # Test connections
        for layer_type in LayerType:
            if layer_type != LayerType.UI_UX:
                await integration.test_layer_connection(layer_type)
        
        # Print layer statuses
        print(json.dumps(integration.get_all_layer_statuses(), indent=2))
        
        # Wait for a while
        await asyncio.sleep(10)
        
        # Disconnect from all layers
        await integration.disconnect_from_all_layers()
    
    # Run the async main function
    asyncio.run(main())
