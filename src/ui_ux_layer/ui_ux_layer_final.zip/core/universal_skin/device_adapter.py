"""
Device Adapter - Adapts the Universal Skin Shell to different devices and form factors

This module handles the adaptation of the Universal Skin Shell to different devices,
screen sizes, input methods, and capabilities. It ensures a consistent yet
contextually appropriate experience across the compute continuum.
"""

import logging
from typing import Dict, Any, List, Optional

# Initialize logger
logger = logging.getLogger(__name__)

class DeviceAdapter:
    """
    Handles adaptation to different devices and form factors.
    """
    
    # Device type constants
    DESKTOP = "desktop"
    MOBILE = "mobile"
    TABLET = "tablet"
    KIOSK = "kiosk"
    INDUSTRIAL_PANEL = "industrial_panel"
    EDGE_DEVICE = "edge_device"
    AR_HEADSET = "ar_headset"
    VR_HEADSET = "vr_headset"
    
    # Input method constants
    TOUCH = "touch"
    MOUSE = "mouse"
    KEYBOARD = "keyboard"
    VOICE = "voice"
    GESTURE = "gesture"
    EYE_TRACKING = "eye_tracking"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Device Adapter with optional configuration."""
        self.config = config or {}
        self.device_profiles = self.config.get('device_profiles', {})
        self.layout_templates = self.config.get('layout_templates', {})
        self.current_device_info = {}
        self.current_layout_config = {}
        
        # Load default device profiles if not provided
        if not self.device_profiles:
            self._load_default_device_profiles()
        
        # Load default layout templates if not provided
        if not self.layout_templates:
            self._load_default_layout_templates()
        
        logger.info("Device Adapter initialized with %d device profiles and %d layout templates", 
                   len(self.device_profiles), len(self.layout_templates))
    
    def initialize(self):
        """Initialize the Device Adapter."""
        logger.info("Initializing Device Adapter")
        return True
    
    def _load_default_device_profiles(self):
        """Load default device profiles."""
        self.device_profiles = {
            self.DESKTOP: {
                'input_methods': [self.MOUSE, self.KEYBOARD],
                'default_layout': 'desktop_standard',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': True,
                    'network_reliability': 'high',
                    'screen_size': 'large',
                    'multi_window': True
                }
            },
            self.MOBILE: {
                'input_methods': [self.TOUCH, self.VOICE],
                'default_layout': 'mobile_standard',
                'capabilities': {
                    'high_performance': False,
                    'persistent_storage': True,
                    'network_reliability': 'medium',
                    'screen_size': 'small',
                    'multi_window': False
                }
            },
            self.TABLET: {
                'input_methods': [self.TOUCH, self.KEYBOARD],
                'default_layout': 'tablet_standard',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': True,
                    'network_reliability': 'medium',
                    'screen_size': 'medium',
                    'multi_window': False
                }
            },
            self.KIOSK: {
                'input_methods': [self.TOUCH],
                'default_layout': 'kiosk_standard',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': False,
                    'network_reliability': 'high',
                    'screen_size': 'large',
                    'multi_window': False
                }
            },
            self.INDUSTRIAL_PANEL: {
                'input_methods': [self.TOUCH],
                'default_layout': 'industrial_panel_standard',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': True,
                    'network_reliability': 'high',
                    'screen_size': 'medium',
                    'multi_window': False,
                    'rugged': True
                }
            },
            self.EDGE_DEVICE: {
                'input_methods': [self.TOUCH],
                'default_layout': 'edge_device_minimal',
                'capabilities': {
                    'high_performance': False,
                    'persistent_storage': True,
                    'network_reliability': 'low',
                    'screen_size': 'small',
                    'multi_window': False,
                    'offline_operation': True
                }
            },
            self.AR_HEADSET: {
                'input_methods': [self.GESTURE, self.VOICE, self.EYE_TRACKING],
                'default_layout': 'ar_spatial',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': False,
                    'network_reliability': 'medium',
                    'screen_size': 'immersive',
                    'multi_window': True,
                    'spatial_awareness': True
                }
            },
            self.VR_HEADSET: {
                'input_methods': [self.GESTURE, self.VOICE],
                'default_layout': 'vr_immersive',
                'capabilities': {
                    'high_performance': True,
                    'persistent_storage': False,
                    'network_reliability': 'medium',
                    'screen_size': 'immersive',
                    'multi_window': True,
                    'spatial_awareness': True
                }
            }
        }
    
    def _load_default_layout_templates(self):
        """Load default layout templates."""
        self.layout_templates = {
            'desktop_standard': {
                'components': {
                    'capsule_dock': {
                        'position': 'right',
                        'size': 'medium',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'left',
                        'size': 'medium',
                        'visibility': 'visible'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'bottom',
                        'size': 'small',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'fade',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'small',
                    'visibility': 'visible'
                }
            },
            'mobile_standard': {
                'components': {
                    'capsule_dock': {
                        'position': 'bottom',
                        'size': 'small',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'bottom',
                        'size': 'small',
                        'visibility': 'collapsible'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'full',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'center',
                        'size': 'full',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'center',
                        'size': 'full',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'top',
                        'size': 'tiny',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'slide',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'tiny',
                    'visibility': 'visible'
                }
            },
            'tablet_standard': {
                'components': {
                    'capsule_dock': {
                        'position': 'right',
                        'size': 'small',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'left',
                        'size': 'small',
                        'visibility': 'collapsible'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'bottom',
                        'size': 'small',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'slide',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'small',
                    'visibility': 'visible'
                }
            },
            'kiosk_standard': {
                'components': {
                    'capsule_dock': {
                        'position': 'right',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'left',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'bottom',
                        'size': 'medium',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'fade',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'medium',
                    'visibility': 'visible'
                }
            },
            'industrial_panel_standard': {
                'components': {
                    'capsule_dock': {
                        'position': 'right',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'left',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'center',
                        'size': 'large',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'bottom',
                        'size': 'medium',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'fade',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'medium',
                    'visibility': 'visible'
                }
            },
            'edge_device_minimal': {
                'components': {
                    'capsule_dock': {
                        'position': 'bottom',
                        'size': 'small',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'hidden',
                        'size': 'none',
                        'visibility': 'hidden'
                    },
                    'timeline_view': {
                        'position': 'center',
                        'size': 'full',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'hidden',
                        'size': 'none',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'hidden',
                        'size': 'none',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'top',
                        'size': 'tiny',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'instant',
                'ambient_indicators': {
                    'position': 'top',
                    'size': 'tiny',
                    'visibility': 'visible'
                }
            },
            'ar_spatial': {
                'components': {
                    'capsule_dock': {
                        'position': 'floating',
                        'size': 'medium',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'wrist',
                        'size': 'medium',
                        'visibility': 'collapsible'
                    },
                    'timeline_view': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'peripheral',
                        'size': 'small',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'spatial',
                'ambient_indicators': {
                    'position': 'peripheral',
                    'size': 'small',
                    'visibility': 'visible'
                }
            },
            'vr_immersive': {
                'components': {
                    'capsule_dock': {
                        'position': 'floating',
                        'size': 'large',
                        'visibility': 'visible'
                    },
                    'global_navigation': {
                        'position': 'wrist',
                        'size': 'large',
                        'visibility': 'collapsible'
                    },
                    'timeline_view': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'visible'
                    },
                    'swarm_lens': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'hidden'
                    },
                    'mission_deck': {
                        'position': 'spatial',
                        'size': 'dynamic',
                        'visibility': 'hidden'
                    },
                    'trust_ribbon': {
                        'position': 'peripheral',
                        'size': 'medium',
                        'visibility': 'visible'
                    }
                },
                'transition_style': 'spatial',
                'ambient_indicators': {
                    'position': 'peripheral',
                    'size': 'medium',
                    'visibility': 'visible'
                }
            }
        }
    
    def adapt(self, device_info: Dict[str, Any]) -> bool:
        """
        Adapt the UI to the specified device.
        
        Args:
            device_info: Dictionary containing device information
                - type: Device type (desktop, mobile, etc.)
                - screen_width: Screen width in pixels
                - screen_height: Screen height in pixels
                - input_methods: List of available input methods
                - capabilities: Dictionary of device capabilities
        
        Returns:
            bool: True if adaptation was successful, False otherwise
        """
        logger.info("Adapting to device: %s", device_info)
        
        # Store current device info
        self.current_device_info = device_info
        
        # Get device type
        device_type = device_info.get('type', self.DESKTOP)
        
        # Get device profile
        device_profile = self.device_profiles.get(device_type)
        if not device_profile:
            logger.warning("Unknown device type: %s, using desktop profile", device_type)
            device_profile = self.device_profiles.get(self.DESKTOP)
        
        # Get layout template name
        layout_template_name = device_profile.get('default_layout')
        
        # Get layout template
        layout_template = self.layout_templates.get(layout_template_name)
        if not layout_template:
            logger.warning("Unknown layout template: %s, using desktop_standard", layout_template_name)
            layout_template = self.layout_templates.get('desktop_standard')
        
        # Apply device-specific customizations to layout
        layout_config = self._customize_layout_for_device(layout_template, device_info)
        
        # Store current layout config
        self.current_layout_config = layout_config
        
        logger.info("Adaptation complete for device type: %s", device_type)
        return True
    
    def _customize_layout_for_device(self, base_layout: Dict[str, Any], device_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Customize layout template for specific device characteristics.
        
        Args:
            base_layout: Base layout template
            device_info: Device information
        
        Returns:
            Dict[str, Any]: Customized layout configuration
        """
        # Create a deep copy of the base layout
        import copy
        layout = copy.deepcopy(base_layout)
        
        # Get screen dimensions
        screen_width = device_info.get('screen_width', 1920)
        screen_height = device_info.get('screen_height', 1080)
        
        # Adjust component sizes based on screen dimensions
        if screen_width < 600 or screen_height < 600:
            # Very small screen, reduce sizes
            for component_id, component_config in layout.get('components', {}).items():
                if component_config.get('size') == 'medium':
                    component_config['size'] = 'small'
                elif component_config.get('size') == 'large':
                    component_config['size'] = 'medium'
        
        # Adjust for input methods
        input_methods = device_info.get('input_methods', [])
        
        # If touch is the primary input method, make interactive elements larger
        if self.TOUCH in input_methods and self.MOUSE not in input_methods:
            layout['touch_optimized'] = True
        else:
            layout['touch_optimized'] = False
        
        # If voice is available, enable voice commands
        if self.VOICE in input_methods:
            layout['voice_enabled'] = True
        else:
            layout['voice_enabled'] = False
        
        # If gesture is available, enable gesture controls
        if self.GESTURE in input_methods:
            layout['gesture_enabled'] = True
        else:
            layout['gesture_enabled'] = False
        
        # Adjust for device capabilities
        capabilities = device_info.get('capabilities', {})
        
        # If low performance, disable animations
        if not capabilities.get('high_performance', True):
            layout['animations_enabled'] = False
        else:
            layout['animations_enabled'] = True
        
        # If offline operation is supported, enable offline mode
        if capabilities.get('offline_operation', False):
            layout['offline_mode_enabled'] = True
        else:
            layout['offline_mode_enabled'] = False
        
        # If multi-window is supported, enable window management
        if capabilities.get('multi_window', False):
            layout['multi_window_enabled'] = True
        else:
            layout['multi_window_enabled'] = False
        
        return layout
    
    def get_layout_config(self, device_info: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Get layout configuration for the specified device.
        
        Args:
            device_info: Device information (optional, uses current device if not provided)
        
        Returns:
            Dict[str, Any]: Layout configuration
        """
        if device_info:
            # Adapt to the specified device
            self.adapt(device_info)
        
        return self.current_layout_config
    
    def get_current_device_info(self) -> Dict[str, Any]:
        """
        Get current device information.
        
        Returns:
            Dict[str, Any]: Current device information
        """
        return self.current_device_info
    
    def register_device_profile(self, device_type: str, profile: Dict[str, Any]) -> bool:
        """
        Register a new device profile.
        
        Args:
            device_type: Device type identifier
            profile: Device profile configuration
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        logger.info("Registering device profile for type: %s", device_type)
        
        self.device_profiles[device_type] = profile
        return True
    
    def register_layout_template(self, template_name: str, template: Dict[str, Any]) -> bool:
        """
        Register a new layout template.
        
        Args:
            template_name: Template identifier
            template: Layout template configuration
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        logger.info("Registering layout template: %s", template_name)
        
        self.layout_templates[template_name] = template
        return True
    
    def get_device_profile(self, device_type: str) -> Dict[str, Any]:
        """
        Get device profile for the specified type.
        
        Args:
            device_type: Device type identifier
        
        Returns:
            Dict[str, Any]: Device profile configuration
        """
        return self.device_profiles.get(device_type, {})
    
    def get_layout_template(self, template_name: str) -> Dict[str, Any]:
        """
        Get layout template with the specified name.
        
        Args:
            template_name: Template identifier
        
        Returns:
            Dict[str, Any]: Layout template configuration
        """
        return self.layout_templates.get(template_name, {})
    
    def detect_device(self) -> Dict[str, Any]:
        """
        Detect current device characteristics.
        
        Returns:
            Dict[str, Any]: Detected device information
        """
        # This is a placeholder implementation
        # In a real implementation, this would detect the actual device
        # characteristics using browser/platform APIs
        
        import platform
        import os
        
        # Default to desktop
        device_info = {
            'type': self.DESKTOP,
            'screen_width': 1920,
            'screen_height': 1080,
            'input_methods': [self.MOUSE, self.KEYBOARD],
            'capabilities': {
                'high_performance': True,
                'persistent_storage': True,
                'network_reliability': 'high',
                'screen_size': 'large',
                'multi_window': True
            }
        }
        
        # Check if running on mobile
        if 'MOBILE' in os.environ.get('USER_AGENT', '').upper():
            device_info = {
                'type': self.MOBILE,
                'screen_width': 375,
                'screen_height': 812,
                'input_methods': [self.TOUCH, self.VOICE],
                'capabilities': {
                    'high_performance': False,
                    'persistent_storage': True,
                    'network_reliability': 'medium',
                    'screen_size': 'small',
                    'multi_window': False
                }
            }
        
        logger.info("Detected device: %s", device_info)
        return device_info
