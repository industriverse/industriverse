"""
Interaction Orchestrator - Coordinates multi-modal interactions between users, agents, and systems

This module implements the core functionality for orchestrating interactions across
different modalities, devices, and contexts. It serves as the central coordination
point for all user and agent interactions within the UI/UX Layer.
"""

import logging
import json
from typing import Dict, List, Any, Optional, Callable

# Initialize logger
logger = logging.getLogger(__name__)

class InteractionOrchestrator:
    """
    Orchestrates multi-modal interactions between users, agents, and systems.
    """
    
    # Interaction modality constants
    MODALITY_VISUAL = "visual"
    MODALITY_VOICE = "voice"
    MODALITY_GESTURE = "gesture"
    MODALITY_TOUCH = "touch"
    MODALITY_TEXT = "text"
    MODALITY_AR = "ar"
    MODALITY_VR = "vr"
    MODALITY_HAPTIC = "haptic"
    
    # Interaction type constants
    TYPE_COMMAND = "command"
    TYPE_QUERY = "query"
    TYPE_RESPONSE = "response"
    TYPE_NOTIFICATION = "notification"
    TYPE_SUGGESTION = "suggestion"
    TYPE_FEEDBACK = "feedback"
    TYPE_AMBIENT = "ambient"
    
    # Interaction priority levels
    PRIORITY_CRITICAL = "critical"
    PRIORITY_HIGH = "high"
    PRIORITY_MEDIUM = "medium"
    PRIORITY_LOW = "low"
    PRIORITY_AMBIENT = "ambient"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Interaction Orchestrator with optional configuration."""
        self.config = config or {}
        self.active_interactions = {}
        self.interaction_history = []
        self.modality_handlers = {}
        self.interaction_handlers = {}
        self.event_subscribers = {}
        self.interaction_queue = {}
        self.interaction_policies = {}
        
        # Initialize interaction queue for each priority level
        for priority in [self.PRIORITY_CRITICAL, self.PRIORITY_HIGH, 
                        self.PRIORITY_MEDIUM, self.PRIORITY_LOW, 
                        self.PRIORITY_AMBIENT]:
            self.interaction_queue[priority] = []
        
        logger.info("Interaction Orchestrator initialized with config: %s", self.config)
    
    def initialize(self):
        """Initialize the Interaction Orchestrator and all its components."""
        logger.info("Initializing Interaction Orchestrator components")
        
        # Import dependencies here to avoid circular imports
        from .modality_handler_manager import ModalityHandlerManager
        from .interaction_policy_engine import InteractionPolicyEngine
        from .interaction_history_manager import InteractionHistoryManager
        from .interaction_queue_manager import InteractionQueueManager
        from .interaction_event_bus import InteractionEventBus
        
        # Initialize components
        self.modality_manager = ModalityHandlerManager(self.config.get('modality_manager', {}))
        self.policy_engine = InteractionPolicyEngine(self.config.get('policy_engine', {}))
        self.history_manager = InteractionHistoryManager(self.config.get('history_manager', {}))
        self.queue_manager = InteractionQueueManager(self.config.get('queue_manager', {}))
        self.event_bus = InteractionEventBus(self.config.get('event_bus', {}))
        
        # Initialize each component
        self.modality_manager.initialize()
        self.policy_engine.initialize()
        self.history_manager.initialize()
        self.queue_manager.initialize()
        self.event_bus.initialize()
        
        # Register default modality handlers
        self._register_default_modality_handlers()
        
        # Load default interaction policies
        self._load_default_interaction_policies()
        
        # Subscribe to event bus
        self.event_bus.subscribe('interaction_started', self._handle_interaction_started)
        self.event_bus.subscribe('interaction_completed', self._handle_interaction_completed)
        self.event_bus.subscribe('interaction_failed', self._handle_interaction_failed)
        
        logger.info("Interaction Orchestrator initialization complete")
        return True
    
    def _register_default_modality_handlers(self):
        """Register default modality handlers."""
        default_handlers = self.config.get('default_modality_handlers', {})
        
        for modality, handler_config in default_handlers.items():
            self.register_modality_handler(modality, handler_config)
        
        logger.info("Registered %d default modality handlers", len(default_handlers))
    
    def _load_default_interaction_policies(self):
        """Load default interaction policies."""
        default_policies = self.config.get('default_policies', [])
        
        for policy in default_policies:
            self.register_interaction_policy(policy)
        
        logger.info("Loaded %d default interaction policies", len(default_policies))
    
    def start_interaction(self, interaction_config: Dict[str, Any]) -> str:
        """
        Start a new interaction.
        
        Args:
            interaction_config: Configuration for the interaction
                - type: Type of interaction
                - modality: Primary modality for the interaction
                - content: Content of the interaction
                - source: Source of the interaction
                - target: Target of the interaction
                - priority: Priority of the interaction
                - context: Context information for the interaction
        
        Returns:
            str: Unique identifier for the interaction
        """
        logger.info("Starting interaction: %s", interaction_config)
        
        # Generate interaction ID if not provided
        interaction_id = interaction_config.get('id')
        if not interaction_id:
            interaction_id = self._generate_interaction_id(interaction_config)
            interaction_config['id'] = interaction_id
        
        # Set default values if not provided
        interaction_type = interaction_config.get('type', self.TYPE_COMMAND)
        modality = interaction_config.get('modality', self.MODALITY_VISUAL)
        priority = interaction_config.get('priority', self.PRIORITY_MEDIUM)
        
        # Create interaction object
        interaction = {
            'id': interaction_id,
            'config': interaction_config,
            'type': interaction_type,
            'modality': modality,
            'content': interaction_config.get('content', {}),
            'source': interaction_config.get('source', 'system'),
            'target': interaction_config.get('target', 'user'),
            'priority': priority,
            'context': interaction_config.get('context', {}),
            'state': 'pending',
            'created_at': self._get_current_timestamp(),
            'updated_at': self._get_current_timestamp(),
            'completed_at': None,
            'result': None,
            'error': None
        }
        
        # Check if interaction should be queued or processed immediately
        should_queue = self.policy_engine.should_queue_interaction(interaction) if self.policy_engine else False
        
        if should_queue:
            # Add to queue
            if self.queue_manager:
                self.queue_manager.enqueue_interaction(interaction)
            else:
                # Simple queuing if queue manager not available
                self.interaction_queue[priority].append(interaction)
            
            logger.info("Interaction queued: %s", interaction_id)
        else:
            # Process immediately
            self._process_interaction(interaction)
        
        # Store interaction
        self.active_interactions[interaction_id] = interaction
        
        # Publish event
        self.event_bus.publish('interaction_started', {
            'interaction_id': interaction_id,
            'interaction': interaction
        })
        
        # Notify subscribers
        self._notify_subscribers('interaction_started', {
            'interaction_id': interaction_id,
            'interaction': interaction
        })
        
        logger.info("Interaction started: %s", interaction_id)
        return interaction_id
    
    def _process_interaction(self, interaction: Dict[str, Any]) -> bool:
        """
        Process an interaction.
        
        Args:
            interaction: Interaction to process
        
        Returns:
            bool: True if processing was successful, False otherwise
        """
        interaction_id = interaction['id']
        modality = interaction['modality']
        
        logger.debug("Processing interaction: %s with modality %s", interaction_id, modality)
        
        # Update interaction state
        interaction['state'] = 'processing'
        interaction['updated_at'] = self._get_current_timestamp()
        
        # Get modality handler
        if self.modality_manager:
            handler = self.modality_manager.get_handler(modality)
        else:
            # Simple handler lookup if modality manager not available
            handler = self.modality_handlers.get(modality)
        
        if not handler:
            logger.warning("No handler found for modality: %s", modality)
            
            # Update interaction with error
            interaction['state'] = 'failed'
            interaction['updated_at'] = self._get_current_timestamp()
            interaction['error'] = f"No handler found for modality: {modality}"
            
            # Publish event
            self.event_bus.publish('interaction_failed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'error': interaction['error']
            })
            
            # Notify subscribers
            self._notify_subscribers('interaction_failed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'error': interaction['error']
            })
            
            return False
        
        try:
            # Process interaction with handler
            result = handler.handle_interaction(interaction)
            
            # Update interaction with result
            interaction['state'] = 'completed'
            interaction['updated_at'] = self._get_current_timestamp()
            interaction['completed_at'] = self._get_current_timestamp()
            interaction['result'] = result
            
            # Add to history
            if self.history_manager:
                self.history_manager.add_to_history(interaction)
            else:
                # Simple history tracking if history manager not available
                self.interaction_history.append(interaction)
                
                # Limit history size
                max_history = self.config.get('max_history_size', 100)
                if len(self.interaction_history) > max_history:
                    self.interaction_history = self.interaction_history[-max_history:]
            
            # Publish event
            self.event_bus.publish('interaction_completed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'result': result
            })
            
            # Notify subscribers
            self._notify_subscribers('interaction_completed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'result': result
            })
            
            logger.debug("Interaction processed successfully: %s", interaction_id)
            return True
        
        except Exception as e:
            logger.error("Error processing interaction: %s", e)
            
            # Update interaction with error
            interaction['state'] = 'failed'
            interaction['updated_at'] = self._get_current_timestamp()
            interaction['error'] = str(e)
            
            # Publish event
            self.event_bus.publish('interaction_failed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'error': str(e)
            })
            
            # Notify subscribers
            self._notify_subscribers('interaction_failed', {
                'interaction_id': interaction_id,
                'interaction': interaction,
                'error': str(e)
            })
            
            return False
    
    def complete_interaction(self, interaction_id: str, result: Any) -> bool:
        """
        Complete an interaction with a result.
        
        Args:
            interaction_id: Unique identifier for the interaction
            result: Result of the interaction
        
        Returns:
            bool: True if completion was successful, False otherwise
        """
        logger.info("Completing interaction: %s", interaction_id)
        
        if interaction_id not in self.active_interactions:
            logger.warning("Interaction not found: %s", interaction_id)
            return False
        
        interaction = self.active_interactions[interaction_id]
        
        # Update interaction with result
        interaction['state'] = 'completed'
        interaction['updated_at'] = self._get_current_timestamp()
        interaction['completed_at'] = self._get_current_timestamp()
        interaction['result'] = result
        
        # Add to history
        if self.history_manager:
            self.history_manager.add_to_history(interaction)
        else:
            # Simple history tracking if history manager not available
            self.interaction_history.append(interaction)
            
            # Limit history size
            max_history = self.config.get('max_history_size', 100)
            if len(self.interaction_history) > max_history:
                self.interaction_history = self.interaction_history[-max_history:]
        
        # Remove from active interactions
        del self.active_interactions[interaction_id]
        
        # Publish event
        self.event_bus.publish('interaction_completed', {
            'interaction_id': interaction_id,
            'interaction': interaction,
            'result': result
        })
        
        # Notify subscribers
        self._notify_subscribers('interaction_completed', {
            'interaction_id': interaction_id,
            'interaction': interaction,
            'result': result
        })
        
        # Process next interaction in queue
        self._process_next_in_queue()
        
        logger.info("Interaction completed: %s", interaction_id)
        return True
    
    def fail_interaction(self, interaction_id: str, error: str) -> bool:
        """
        Fail an interaction with an error.
        
        Args:
            interaction_id: Unique identifier for the interaction
            error: Error message
        
        Returns:
            bool: True if failure was recorded successfully, False otherwise
        """
        logger.info("Failing interaction: %s with error: %s", interaction_id, error)
        
        if interaction_id not in self.active_interactions:
            logger.warning("Interaction not found: %s", interaction_id)
            return False
        
        interaction = self.active_interactions[interaction_id]
        
        # Update interaction with error
        interaction['state'] = 'failed'
        interaction['updated_at'] = self._get_current_timestamp()
        interaction['error'] = error
        
        # Add to history
        if self.history_manager:
            self.history_manager.add_to_history(interaction)
        else:
            # Simple history tracking if history manager not available
            self.interaction_history.append(interaction)
            
            # Limit history size
            max_history = self.config.get('max_history_size', 100)
            if len(self.interaction_history) > max_history:
                self.interaction_history = self.interaction_history[-max_history:]
        
        # Remove from active interactions
        del self.active_interactions[interaction_id]
        
        # Publish event
        self.event_bus.publish('interaction_failed', {
            'interaction_id': interaction_id,
            'interaction': interaction,
            'error': error
        })
        
        # Notify subscribers
        self._notify_subscribers('interaction_failed', {
            'interaction_id': interaction_id,
            'interaction': interaction,
            'error': error
        })
        
        # Process next interaction in queue
        self._process_next_in_queue()
        
        logger.info("Interaction failed: %s", interaction_id)
        return True
    
    def cancel_interaction(self, interaction_id: str) -> bool:
        """
        Cancel an interaction.
        
        Args:
            interaction_id: Unique identifier for the interaction
        
        Returns:
            bool: True if cancellation was successful, False otherwise
        """
        logger.info("Cancelling interaction: %s", interaction_id)
        
        if interaction_id not in self.active_interactions:
            logger.warning("Interaction not found: %s", interaction_id)
            return False
        
        interaction = self.active_interactions[interaction_id]
        
        # Update interaction state
        interaction['state'] = 'cancelled'
        interaction['updated_at'] = self._get_current_timestamp()
        
        # Add to history
        if self.history_manager:
            self.history_manager.add_to_history(interaction)
        else:
            # Simple history tracking if history manager not available
            self.interaction_history.append(interaction)
            
            # Limit history size
            max_history = self.config.get('max_history_size', 100)
            if len(self.interaction_history) > max_history:
                self.interaction_history = self.interaction_history[-max_history:]
        
        # Remove from active interactions
        del self.active_interactions[interaction_id]
        
        # Remove from queue if queued
        if self.queue_manager:
            self.queue_manager.remove_from_queue(interaction_id)
        else:
            # Simple queue removal if queue manager not available
            for priority, queue in self.interaction_queue.items():
                for i, queued_interaction in enumerate(queue):
                    if queued_interaction['id'] == interaction_id:
                        queue.pop(i)
                        break
        
        # Publish event
        self.event_bus.publish('interaction_cancelled', {
            'interaction_id': interaction_id,
            'interaction': interaction
        })
        
        # Notify subscribers
        self._notify_subscribers('interaction_cancelled', {
            'interaction_id': interaction_id,
            'interaction': interaction
        })
        
        # Process next interaction in queue
        self._process_next_in_queue()
        
        logger.info("Interaction cancelled: %s", interaction_id)
        return True
    
    def get_interaction(self, interaction_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an interaction by ID.
        
        Args:
            interaction_id: Unique identifier for the interaction
        
        Returns:
            Optional[Dict[str, Any]]: Interaction information or None if not found
        """
        return self.active_interactions.get(interaction_id)
    
    def get_all_interactions(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all active interactions.
        
        Returns:
            Dict[str, Dict[str, Any]]: Dictionary of all active interactions
        """
        return self.active_interactions.copy()
    
    def get_interaction_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get interaction history.
        
        Args:
            limit: Maximum number of history entries to return
        
        Returns:
            List[Dict[str, Any]]: List of history entries
        """
        if self.history_manager:
            return self.history_manager.get_history(limit)
        
        return self.interaction_history[-limit:]
    
    def register_modality_handler(self, modality: str, handler_config: Dict[str, Any]) -> bool:
        """
        Register a modality handler.
        
        Args:
            modality: Modality to handle
            handler_config: Handler configuration
                - id: Unique identifier for the handler
                - name: Human-readable name for the handler
                - description: Description of the handler
                - enabled: Whether the handler is enabled
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        handler_id = handler_config.get('id')
        if not handler_id:
            logger.warning("Handler must have an ID")
            return False
        
        logger.info("Registering modality handler: %s for modality %s", handler_id, modality)
        
        # Register with modality manager
        if self.modality_manager:
            return self.modality_manager.register_handler(modality, handler_config)
        
        # Simple handler storage if modality manager not available
        self.modality_handlers[modality] = handler_config
        return True
    
    def unregister_modality_handler(self, modality: str) -> bool:
        """
        Unregister a modality handler.
        
        Args:
            modality: Modality to unregister handler for
        
        Returns:
            bool: True if unregistration was successful, False otherwise
        """
        logger.info("Unregistering modality handler for modality: %s", modality)
        
        # Unregister from modality manager
        if self.modality_manager:
            return self.modality_manager.unregister_handler(modality)
        
        # Simple handler removal if modality manager not available
        if modality in self.modality_handlers:
            del self.modality_handlers[modality]
            return True
        
        logger.warning("Handler not found for modality: %s", modality)
        return False
    
    def register_interaction_policy(self, policy: Dict[str, Any]) -> bool:
        """
        Register an interaction policy.
        
        Args:
            policy: Policy configuration
                - id: Unique identifier for the policy
                - name: Human-readable name for the policy
                - description: Description of the policy
                - condition: Condition expression or function
                - action: Action to take when condition is met
                - priority: Priority of the policy
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        policy_id = policy.get('id')
        if not policy_id:
            logger.warning("Policy must have an ID")
            return False
        
        logger.info("Registering interaction policy: %s", policy_id)
        
        # Register with policy engine
        if self.policy_engine:
            return self.policy_engine.register_policy(policy)
        
        # Simple policy storage if policy engine not available
        self.interaction_policies[policy_id] = policy
        return True
    
    def unregister_interaction_policy(self, policy_id: str) -> bool:
        """
        Unregister an interaction policy.
        
        Args:
            policy_id: Unique identifier for the policy
        
        Returns:
            bool: True if unregistration was successful, False otherwise
        """
        logger.info("Unregistering interaction policy: %s", policy_id)
        
        # Unregister from policy engine
        if self.policy_engine:
            return self.policy_engine.unregister_policy(policy_id)
        
        # Simple policy removal if policy engine not available
        if policy_id in self.interaction_policies:
            del self.interaction_policies[policy_id]
            return True
        
        logger.warning("Policy not found: %s", policy_id)
        return False
    
    def _process_next_in_queue(self):
        """Process the next interaction in the queue."""
        # Use queue manager if available
        if self.queue_manager:
            next_interaction = self.queue_manager.dequeue_next_interaction()
            if next_interaction:
                self._process_interaction(next_interaction)
            return
        
        # Simple queue processing if queue manager not available
        for priority in [self.PRIORITY_CRITICAL, self.PRIORITY_HIGH, 
                        self.PRIORITY_MEDIUM, self.PRIORITY_LOW, 
                        self.PRIORITY_AMBIENT]:
            if self.interaction_queue[priority]:
                next_interaction = self.interaction_queue[priority].pop(0)
                self._process_interaction(next_interaction)
                return
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to interaction events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = []
        
        self.event_subscribers[event_type].append(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from interaction events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def _handle_interaction_started(self, event_data: Dict[str, Any]):
        """
        Handle interaction started event.
        
        Args:
            event_data: Event data
        """
        interaction_id = event_data.get('interaction_id')
        
        logger.debug("Handling interaction started event: %s", interaction_id)
        
        # Notify subscribers
        self._notify_subscribers('interaction_started', event_data)
    
    def _handle_interaction_completed(self, event_data: Dict[str, Any]):
        """
        Handle interaction completed event.
        
        Args:
            event_data: Event data
        """
        interaction_id = event_data.get('interaction_id')
        
        logger.debug("Handling interaction completed event: %s", interaction_id)
        
        # Notify subscribers
        self._notify_subscribers('interaction_completed', event_data)
    
    def _handle_interaction_failed(self, event_data: Dict[str, Any]):
        """
        Handle interaction failed event.
        
        Args:
            event_data: Event data
        """
        interaction_id = event_data.get('interaction_id')
        error = event_data.get('error')
        
        logger.debug("Handling interaction failed event: %s with error: %s", 
                    interaction_id, error)
        
        # Notify subscribers
        self._notify_subscribers('interaction_failed', event_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def _generate_interaction_id(self, interaction_config: Dict[str, Any]) -> str:
        """
        Generate a unique interaction ID.
        
        Args:
            interaction_config: Interaction configuration
        
        Returns:
            str: Unique interaction ID
        """
        import uuid
        import hashlib
        
        # Use type, source, and target if available
        interaction_type = interaction_config.get('type', '')
        source = interaction_config.get('source', '')
        target = interaction_config.get('target', '')
        
        if interaction_type and source and target:
            # Create a deterministic ID based on type, source, and target
            hash_input = f"{interaction_type}:{source}:{target}:{uuid.uuid4()}"
            return f"interaction-{hashlib.md5(hash_input.encode()).hexdigest()[:8]}"
        
        # Otherwise, generate a random ID
        return f"interaction-{uuid.uuid4().hex[:8]}"
    
    def _get_current_timestamp(self) -> int:
        """
        Get current timestamp.
        
        Returns:
            int: Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)
    
    def to_json(self) -> str:
        """
        Serialize interaction orchestrator state to JSON.
        
        Returns:
            str: JSON string representation of interaction orchestrator state
        """
        state = {
            'active_interactions': self.active_interactions,
            'interaction_queue': self.interaction_queue
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize interaction orchestrator state from JSON.
        
        Args:
            json_str: JSON string representation of interaction orchestrator state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        try:
            state = json.loads(json_str)
            
            self.active_interactions = state.get('active_interactions', {})
            self.interaction_queue = state.get('interaction_queue', {})
            
            # Initialize queue for any missing priority levels
            for priority in [self.PRIORITY_CRITICAL, self.PRIORITY_HIGH, 
                            self.PRIORITY_MEDIUM, self.PRIORITY_LOW, 
                            self.PRIORITY_AMBIENT]:
                if priority not in self.interaction_queue:
                    self.interaction_queue[priority] = []
            
            return True
        except Exception as e:
            logger.error("Error deserializing interaction orchestrator state: %s", e)
            return False
