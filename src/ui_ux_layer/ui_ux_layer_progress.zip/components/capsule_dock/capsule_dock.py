"""
Capsule Dock Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Capsule Dock, a central UI element that displays and manages
Agent Capsules in the Universal Skin interface. It serves as a primary interaction point
for users to engage with AI Agents and Digital Twins across the Industrial Foundry Framework.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set
import json

# Initialize logger
logger = logging.getLogger(__name__)

class CapsuleDock:
    """
    Capsule Dock component for displaying and managing Agent Capsules.
    """
    
    # Dock position constants
    POSITION_TOP = "top"
    POSITION_BOTTOM = "bottom"
    POSITION_LEFT = "left"
    POSITION_RIGHT = "right"
    POSITION_FLOATING = "floating"
    
    # Dock mode constants
    MODE_EXPANDED = "expanded"
    MODE_COLLAPSED = "collapsed"
    MODE_AUTO = "auto"
    MODE_AMBIENT = "ambient"
    
    # Dock layout constants
    LAYOUT_LINEAR = "linear"
    LAYOUT_GRID = "grid"
    LAYOUT_RADIAL = "radial"
    LAYOUT_ADAPTIVE = "adaptive"
    LAYOUT_SWARM = "swarm"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Capsule Dock with optional configuration."""
        self.config = config or {}
        self.capsules = {}
        self.active_capsule_id = None
        self.position = self.config.get('position', self.POSITION_BOTTOM)
        self.mode = self.config.get('mode', self.MODE_AUTO)
        self.layout = self.config.get('layout', self.LAYOUT_ADAPTIVE)
        self.max_visible_capsules = self.config.get('max_visible_capsules', 10)
        self.auto_arrange = self.config.get('auto_arrange', True)
        self.trust_weighted_display = self.config.get('trust_weighted_display', True)
        self.context_aware_grouping = self.config.get('context_aware_grouping', True)
        self.animation_enabled = self.config.get('animation_enabled', True)
        self.event_subscribers = {}
        self.capsule_groups = {}
        self.pinned_capsules = set()
        self.hidden_capsules = set()
        self.capsule_states = {}
        self.interaction_history = []
        self.context_engine = None
        self.rendering_engine = None
        self.theme_manager = None
        self.accessibility_manager = None
        
        logger.info("Capsule Dock initialized with config: %s", self.config)
    
    def initialize(self, context_engine=None, rendering_engine=None, 
                  theme_manager=None, accessibility_manager=None):
        """Initialize the Capsule Dock and connect to required services."""
        logger.info("Initializing Capsule Dock")
        
        # Store references to required services
        self.context_engine = context_engine
        self.rendering_engine = rendering_engine
        self.theme_manager = theme_manager
        self.accessibility_manager = accessibility_manager
        
        # Initialize capsule groups
        self._initialize_capsule_groups()
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events('context_changed', self._on_context_changed)
        
        if self.theme_manager:
            self.theme_manager.subscribe_to_events('theme_changed', self._on_theme_changed)
        
        if self.accessibility_manager:
            self.accessibility_manager.subscribe_to_events('settings_changed', self._on_accessibility_settings_changed)
        
        logger.info("Capsule Dock initialization complete")
        return True
    
    def _initialize_capsule_groups(self):
        """Initialize default capsule groups."""
        self.capsule_groups = {
            'pinned': {
                'id': 'pinned',
                'name': 'Pinned',
                'description': 'Pinned capsules',
                'capsules': [],
                'visible': True,
                'expanded': True,
                'order': 0
            },
            'active': {
                'id': 'active',
                'name': 'Active',
                'description': 'Currently active capsules',
                'capsules': [],
                'visible': True,
                'expanded': True,
                'order': 1
            },
            'recent': {
                'id': 'recent',
                'name': 'Recent',
                'description': 'Recently used capsules',
                'capsules': [],
                'visible': True,
                'expanded': True,
                'order': 2
            },
            'suggested': {
                'id': 'suggested',
                'name': 'Suggested',
                'description': 'Suggested capsules based on context',
                'capsules': [],
                'visible': True,
                'expanded': False,
                'order': 3
            },
            'layer': {
                'id': 'layer',
                'name': 'Layers',
                'description': 'Layer-specific capsules',
                'capsules': [],
                'visible': True,
                'expanded': False,
                'order': 4,
                'subgroups': {
                    'data_layer': {
                        'id': 'data_layer',
                        'name': 'Data Layer',
                        'description': 'Data Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 0
                    },
                    'core_ai_layer': {
                        'id': 'core_ai_layer',
                        'name': 'Core AI Layer',
                        'description': 'Core AI Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 1
                    },
                    'generative_layer': {
                        'id': 'generative_layer',
                        'name': 'Generative Layer',
                        'description': 'Generative Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 2
                    },
                    'application_layer': {
                        'id': 'application_layer',
                        'name': 'Application Layer',
                        'description': 'Application Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 3
                    },
                    'protocol_layer': {
                        'id': 'protocol_layer',
                        'name': 'Protocol Layer',
                        'description': 'Protocol Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 4
                    },
                    'workflow_layer': {
                        'id': 'workflow_layer',
                        'name': 'Workflow Layer',
                        'description': 'Workflow Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 5
                    },
                    'ui_ux_layer': {
                        'id': 'ui_ux_layer',
                        'name': 'UI/UX Layer',
                        'description': 'UI/UX Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 6
                    },
                    'security_layer': {
                        'id': 'security_layer',
                        'name': 'Security Layer',
                        'description': 'Security Layer capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 7
                    }
                }
            },
            'industry': {
                'id': 'industry',
                'name': 'Industry',
                'description': 'Industry-specific capsules',
                'capsules': [],
                'visible': True,
                'expanded': False,
                'order': 5,
                'subgroups': {
                    'manufacturing': {
                        'id': 'manufacturing',
                        'name': 'Manufacturing',
                        'description': 'Manufacturing capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 0
                    },
                    'logistics': {
                        'id': 'logistics',
                        'name': 'Logistics',
                        'description': 'Logistics capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 1
                    },
                    'energy': {
                        'id': 'energy',
                        'name': 'Energy',
                        'description': 'Energy capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 2
                    },
                    'retail': {
                        'id': 'retail',
                        'name': 'Retail',
                        'description': 'Retail capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 3
                    },
                    'defense': {
                        'id': 'defense',
                        'name': 'Defense',
                        'description': 'Defense capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 4
                    },
                    'aerospace': {
                        'id': 'aerospace',
                        'name': 'Aerospace',
                        'description': 'Aerospace capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 5
                    },
                    'data_centers': {
                        'id': 'data_centers',
                        'name': 'Data Centers',
                        'description': 'Data Centers capsules',
                        'capsules': [],
                        'visible': True,
                        'expanded': False,
                        'order': 6
                    }
                }
            }
        }
    
    def add_capsule(self, capsule: Dict[str, Any]) -> bool:
        """
        Add a capsule to the dock.
        
        Args:
            capsule: Capsule data
        
        Returns:
            bool: True if capsule was added successfully, False otherwise
        """
        logger.info("Adding capsule: %s", capsule.get('id'))
        
        # Validate capsule
        if not self._validate_capsule(capsule):
            logger.warning("Invalid capsule: %s", capsule.get('id'))
            return False
        
        capsule_id = capsule['id']
        
        # Add capsule to dock
        self.capsules[capsule_id] = capsule
        
        # Initialize capsule state
        self.capsule_states[capsule_id] = {
            'visible': True,
            'expanded': False,
            'active': False,
            'pinned': False,
            'position': {'x': 0, 'y': 0},
            'size': {'width': 0, 'height': 0},
            'trust_score': capsule.get('trust_score', 0.5),
            'confidence': capsule.get('confidence', 0.5),
            'last_interaction': self._get_current_timestamp(),
            'interaction_count': 0
        }
        
        # Add to appropriate groups
        self._add_capsule_to_groups(capsule)
        
        # Notify subscribers
        self._notify_subscribers('capsule_added', {
            'capsule_id': capsule_id,
            'capsule': capsule
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def remove_capsule(self, capsule_id: str) -> bool:
        """
        Remove a capsule from the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was removed successfully, False otherwise
        """
        logger.info("Removing capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Remove from groups
        self._remove_capsule_from_groups(capsule_id)
        
        # Remove from pinned capsules
        if capsule_id in self.pinned_capsules:
            self.pinned_capsules.remove(capsule_id)
        
        # Remove from hidden capsules
        if capsule_id in self.hidden_capsules:
            self.hidden_capsules.remove(capsule_id)
        
        # Remove capsule state
        if capsule_id in self.capsule_states:
            del self.capsule_states[capsule_id]
        
        # Remove capsule
        del self.capsules[capsule_id]
        
        # Clear active capsule if it's the one being removed
        if self.active_capsule_id == capsule_id:
            self.active_capsule_id = None
        
        # Notify subscribers
        self._notify_subscribers('capsule_removed', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def update_capsule(self, capsule_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a capsule in the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
            updates: Updates to apply to the capsule
        
        Returns:
            bool: True if capsule was updated successfully, False otherwise
        """
        logger.info("Updating capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Get current capsule
        capsule = self.capsules[capsule_id]
        
        # Apply updates
        for key, value in updates.items():
            if key in capsule:
                if isinstance(capsule[key], dict) and isinstance(value, dict):
                    # Deep update for nested dictionaries
                    self._deep_update(capsule[key], value)
                else:
                    # Simple update for non-dict values
                    capsule[key] = value
        
        # Update capsule state if needed
        if 'trust_score' in updates:
            self.capsule_states[capsule_id]['trust_score'] = updates['trust_score']
        
        if 'confidence' in updates:
            self.capsule_states[capsule_id]['confidence'] = updates['confidence']
        
        # Update groups if needed
        if 'layer' in updates or 'industry' in updates:
            self._remove_capsule_from_groups(capsule_id)
            self._add_capsule_to_groups(capsule)
        
        # Notify subscribers
        self._notify_subscribers('capsule_updated', {
            'capsule_id': capsule_id,
            'updates': updates,
            'capsule': capsule
        })
        
        # Arrange capsules if auto-arrange is enabled and relevant properties changed
        relevant_properties = {'size', 'position', 'trust_score', 'confidence', 'layer', 'industry'}
        if self.auto_arrange and any(key in relevant_properties for key in updates.keys()):
            self._arrange_capsules()
        
        return True
    
    def get_capsule(self, capsule_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a capsule by ID.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            Optional[Dict[str, Any]]: Capsule data or None if not found
        """
        return self.capsules.get(capsule_id)
    
    def get_capsules(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all capsules.
        
        Returns:
            Dict[str, Dict[str, Any]]: All capsules
        """
        return self.capsules
    
    def get_visible_capsules(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all visible capsules.
        
        Returns:
            Dict[str, Dict[str, Any]]: All visible capsules
        """
        return {capsule_id: capsule for capsule_id, capsule in self.capsules.items() 
                if capsule_id not in self.hidden_capsules}
    
    def get_capsule_state(self, capsule_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the state of a capsule.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            Optional[Dict[str, Any]]: Capsule state or None if not found
        """
        return self.capsule_states.get(capsule_id)
    
    def get_capsule_states(self) -> Dict[str, Dict[str, Any]]:
        """
        Get states of all capsules.
        
        Returns:
            Dict[str, Dict[str, Any]]: States of all capsules
        """
        return self.capsule_states
    
    def set_active_capsule(self, capsule_id: str) -> bool:
        """
        Set the active capsule.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was set as active successfully, False otherwise
        """
        logger.info("Setting active capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Clear previous active capsule
        if self.active_capsule_id and self.active_capsule_id in self.capsule_states:
            self.capsule_states[self.active_capsule_id]['active'] = False
        
        # Set new active capsule
        self.active_capsule_id = capsule_id
        self.capsule_states[capsule_id]['active'] = True
        self.capsule_states[capsule_id]['last_interaction'] = self._get_current_timestamp()
        self.capsule_states[capsule_id]['interaction_count'] += 1
        
        # Add to interaction history
        self.interaction_history.append({
            'timestamp': self._get_current_timestamp(),
            'action': 'activate',
            'capsule_id': capsule_id
        })
        
        # Notify subscribers
        self._notify_subscribers('active_capsule_changed', {
            'capsule_id': capsule_id,
            'previous_capsule_id': self.active_capsule_id
        })
        
        # Update recent group
        self._update_recent_group()
        
        return True
    
    def get_active_capsule(self) -> Optional[Dict[str, Any]]:
        """
        Get the active capsule.
        
        Returns:
            Optional[Dict[str, Any]]: Active capsule or None if no active capsule
        """
        if not self.active_capsule_id:
            return None
        
        return self.capsules.get(self.active_capsule_id)
    
    def get_active_capsule_id(self) -> Optional[str]:
        """
        Get the ID of the active capsule.
        
        Returns:
            Optional[str]: ID of the active capsule or None if no active capsule
        """
        return self.active_capsule_id
    
    def pin_capsule(self, capsule_id: str) -> bool:
        """
        Pin a capsule to the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was pinned successfully, False otherwise
        """
        logger.info("Pinning capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Add to pinned capsules
        self.pinned_capsules.add(capsule_id)
        
        # Update capsule state
        self.capsule_states[capsule_id]['pinned'] = True
        
        # Add to pinned group
        self._add_capsule_to_group('pinned', capsule_id)
        
        # Notify subscribers
        self._notify_subscribers('capsule_pinned', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def unpin_capsule(self, capsule_id: str) -> bool:
        """
        Unpin a capsule from the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was unpinned successfully, False otherwise
        """
        logger.info("Unpinning capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        if capsule_id not in self.pinned_capsules:
            logger.warning("Capsule not pinned: %s", capsule_id)
            return False
        
        # Remove from pinned capsules
        self.pinned_capsules.remove(capsule_id)
        
        # Update capsule state
        self.capsule_states[capsule_id]['pinned'] = False
        
        # Remove from pinned group
        self._remove_capsule_from_group('pinned', capsule_id)
        
        # Notify subscribers
        self._notify_subscribers('capsule_unpinned', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def is_capsule_pinned(self, capsule_id: str) -> bool:
        """
        Check if a capsule is pinned.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule is pinned, False otherwise
        """
        return capsule_id in self.pinned_capsules
    
    def hide_capsule(self, capsule_id: str) -> bool:
        """
        Hide a capsule from the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was hidden successfully, False otherwise
        """
        logger.info("Hiding capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Add to hidden capsules
        self.hidden_capsules.add(capsule_id)
        
        # Update capsule state
        self.capsule_states[capsule_id]['visible'] = False
        
        # Notify subscribers
        self._notify_subscribers('capsule_hidden', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def show_capsule(self, capsule_id: str) -> bool:
        """
        Show a hidden capsule in the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was shown successfully, False otherwise
        """
        logger.info("Showing capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        if capsule_id not in self.hidden_capsules:
            logger.warning("Capsule not hidden: %s", capsule_id)
            return False
        
        # Remove from hidden capsules
        self.hidden_capsules.remove(capsule_id)
        
        # Update capsule state
        self.capsule_states[capsule_id]['visible'] = True
        
        # Notify subscribers
        self._notify_subscribers('capsule_shown', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def is_capsule_visible(self, capsule_id: str) -> bool:
        """
        Check if a capsule is visible.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule is visible, False otherwise
        """
        return capsule_id not in self.hidden_capsules
    
    def expand_capsule(self, capsule_id: str) -> bool:
        """
        Expand a capsule in the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was expanded successfully, False otherwise
        """
        logger.info("Expanding capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Update capsule state
        self.capsule_states[capsule_id]['expanded'] = True
        
        # Notify subscribers
        self._notify_subscribers('capsule_expanded', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def collapse_capsule(self, capsule_id: str) -> bool:
        """
        Collapse a capsule in the dock.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was collapsed successfully, False otherwise
        """
        logger.info("Collapsing capsule: %s", capsule_id)
        
        if capsule_id not in self.capsules:
            logger.warning("Capsule not found: %s", capsule_id)
            return False
        
        # Update capsule state
        self.capsule_states[capsule_id]['expanded'] = False
        
        # Notify subscribers
        self._notify_subscribers('capsule_collapsed', {
            'capsule_id': capsule_id
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def is_capsule_expanded(self, capsule_id: str) -> bool:
        """
        Check if a capsule is expanded.
        
        Args:
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule is expanded, False otherwise
        """
        if capsule_id not in self.capsule_states:
            return False
        
        return self.capsule_states[capsule_id].get('expanded', False)
    
    def set_position(self, position: str) -> bool:
        """
        Set the position of the dock.
        
        Args:
            position: Position of the dock (POSITION_TOP, POSITION_BOTTOM, POSITION_LEFT, POSITION_RIGHT, POSITION_FLOATING)
        
        Returns:
            bool: True if position was set successfully, False otherwise
        """
        logger.info("Setting dock position: %s", position)
        
        valid_positions = [self.POSITION_TOP, self.POSITION_BOTTOM, self.POSITION_LEFT, 
                          self.POSITION_RIGHT, self.POSITION_FLOATING]
        
        if position not in valid_positions:
            logger.warning("Invalid position: %s", position)
            return False
        
        self.position = position
        
        # Notify subscribers
        self._notify_subscribers('position_changed', {
            'position': position
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_position(self) -> str:
        """
        Get the position of the dock.
        
        Returns:
            str: Position of the dock
        """
        return self.position
    
    def set_mode(self, mode: str) -> bool:
        """
        Set the mode of the dock.
        
        Args:
            mode: Mode of the dock (MODE_EXPANDED, MODE_COLLAPSED, MODE_AUTO, MODE_AMBIENT)
        
        Returns:
            bool: True if mode was set successfully, False otherwise
        """
        logger.info("Setting dock mode: %s", mode)
        
        valid_modes = [self.MODE_EXPANDED, self.MODE_COLLAPSED, self.MODE_AUTO, self.MODE_AMBIENT]
        
        if mode not in valid_modes:
            logger.warning("Invalid mode: %s", mode)
            return False
        
        self.mode = mode
        
        # Notify subscribers
        self._notify_subscribers('mode_changed', {
            'mode': mode
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_mode(self) -> str:
        """
        Get the mode of the dock.
        
        Returns:
            str: Mode of the dock
        """
        return self.mode
    
    def set_layout(self, layout: str) -> bool:
        """
        Set the layout of the dock.
        
        Args:
            layout: Layout of the dock (LAYOUT_LINEAR, LAYOUT_GRID, LAYOUT_RADIAL, LAYOUT_ADAPTIVE, LAYOUT_SWARM)
        
        Returns:
            bool: True if layout was set successfully, False otherwise
        """
        logger.info("Setting dock layout: %s", layout)
        
        valid_layouts = [self.LAYOUT_LINEAR, self.LAYOUT_GRID, self.LAYOUT_RADIAL, 
                        self.LAYOUT_ADAPTIVE, self.LAYOUT_SWARM]
        
        if layout not in valid_layouts:
            logger.warning("Invalid layout: %s", layout)
            return False
        
        self.layout = layout
        
        # Notify subscribers
        self._notify_subscribers('layout_changed', {
            'layout': layout
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_layout(self) -> str:
        """
        Get the layout of the dock.
        
        Returns:
            str: Layout of the dock
        """
        return self.layout
    
    def set_max_visible_capsules(self, max_visible_capsules: int) -> bool:
        """
        Set the maximum number of visible capsules.
        
        Args:
            max_visible_capsules: Maximum number of visible capsules
        
        Returns:
            bool: True if max visible capsules was set successfully, False otherwise
        """
        logger.info("Setting max visible capsules: %s", max_visible_capsules)
        
        if max_visible_capsules < 1:
            logger.warning("Invalid max visible capsules: %s", max_visible_capsules)
            return False
        
        self.max_visible_capsules = max_visible_capsules
        
        # Notify subscribers
        self._notify_subscribers('max_visible_capsules_changed', {
            'max_visible_capsules': max_visible_capsules
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_max_visible_capsules(self) -> int:
        """
        Get the maximum number of visible capsules.
        
        Returns:
            int: Maximum number of visible capsules
        """
        return self.max_visible_capsules
    
    def set_auto_arrange(self, auto_arrange: bool) -> bool:
        """
        Set whether capsules should be automatically arranged.
        
        Args:
            auto_arrange: Whether capsules should be automatically arranged
        
        Returns:
            bool: True if auto arrange was set successfully, False otherwise
        """
        logger.info("Setting auto arrange: %s", auto_arrange)
        
        self.auto_arrange = auto_arrange
        
        # Notify subscribers
        self._notify_subscribers('auto_arrange_changed', {
            'auto_arrange': auto_arrange
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_auto_arrange(self) -> bool:
        """
        Get whether capsules should be automatically arranged.
        
        Returns:
            bool: Whether capsules should be automatically arranged
        """
        return self.auto_arrange
    
    def set_trust_weighted_display(self, trust_weighted_display: bool) -> bool:
        """
        Set whether capsules should be displayed based on trust scores.
        
        Args:
            trust_weighted_display: Whether capsules should be displayed based on trust scores
        
        Returns:
            bool: True if trust weighted display was set successfully, False otherwise
        """
        logger.info("Setting trust weighted display: %s", trust_weighted_display)
        
        self.trust_weighted_display = trust_weighted_display
        
        # Notify subscribers
        self._notify_subscribers('trust_weighted_display_changed', {
            'trust_weighted_display': trust_weighted_display
        })
        
        # Arrange capsules if auto-arrange is enabled
        if self.auto_arrange:
            self._arrange_capsules()
        
        return True
    
    def get_trust_weighted_display(self) -> bool:
        """
        Get whether capsules should be displayed based on trust scores.
        
        Returns:
            bool: Whether capsules should be displayed based on trust scores
        """
        return self.trust_weighted_display
    
    def set_context_aware_grouping(self, context_aware_grouping: bool) -> bool:
        """
        Set whether capsules should be grouped based on context.
        
        Args:
            context_aware_grouping: Whether capsules should be grouped based on context
        
        Returns:
            bool: True if context aware grouping was set successfully, False otherwise
        """
        logger.info("Setting context aware grouping: %s", context_aware_grouping)
        
        self.context_aware_grouping = context_aware_grouping
        
        # Notify subscribers
        self._notify_subscribers('context_aware_grouping_changed', {
            'context_aware_grouping': context_aware_grouping
        })
        
        # Update groups if context aware grouping is enabled
        if self.context_aware_grouping and self.context_engine:
            self._update_context_aware_groups()
        
        return True
    
    def get_context_aware_grouping(self) -> bool:
        """
        Get whether capsules should be grouped based on context.
        
        Returns:
            bool: Whether capsules should be grouped based on context
        """
        return self.context_aware_grouping
    
    def set_animation_enabled(self, animation_enabled: bool) -> bool:
        """
        Set whether animations should be enabled.
        
        Args:
            animation_enabled: Whether animations should be enabled
        
        Returns:
            bool: True if animation enabled was set successfully, False otherwise
        """
        logger.info("Setting animation enabled: %s", animation_enabled)
        
        self.animation_enabled = animation_enabled
        
        # Notify subscribers
        self._notify_subscribers('animation_enabled_changed', {
            'animation_enabled': animation_enabled
        })
        
        return True
    
    def get_animation_enabled(self) -> bool:
        """
        Get whether animations should be enabled.
        
        Returns:
            bool: Whether animations should be enabled
        """
        return self.animation_enabled
    
    def add_capsule_group(self, group: Dict[str, Any]) -> bool:
        """
        Add a capsule group.
        
        Args:
            group: Group data
        
        Returns:
            bool: True if group was added successfully, False otherwise
        """
        logger.info("Adding capsule group: %s", group.get('id'))
        
        # Validate group
        if not self._validate_group(group):
            logger.warning("Invalid group: %s", group.get('id'))
            return False
        
        group_id = group['id']
        
        # Add group
        self.capsule_groups[group_id] = group
        
        # Notify subscribers
        self._notify_subscribers('group_added', {
            'group_id': group_id,
            'group': group
        })
        
        return True
    
    def remove_capsule_group(self, group_id: str) -> bool:
        """
        Remove a capsule group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was removed successfully, False otherwise
        """
        logger.info("Removing capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Remove group
        del self.capsule_groups[group_id]
        
        # Notify subscribers
        self._notify_subscribers('group_removed', {
            'group_id': group_id
        })
        
        return True
    
    def update_capsule_group(self, group_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update a capsule group.
        
        Args:
            group_id: Unique identifier for the group
            updates: Updates to apply to the group
        
        Returns:
            bool: True if group was updated successfully, False otherwise
        """
        logger.info("Updating capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Get current group
        group = self.capsule_groups[group_id]
        
        # Apply updates
        for key, value in updates.items():
            if key in group:
                if isinstance(group[key], dict) and isinstance(value, dict):
                    # Deep update for nested dictionaries
                    self._deep_update(group[key], value)
                else:
                    # Simple update for non-dict values
                    group[key] = value
        
        # Notify subscribers
        self._notify_subscribers('group_updated', {
            'group_id': group_id,
            'updates': updates,
            'group': group
        })
        
        return True
    
    def get_capsule_group(self, group_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a capsule group by ID.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            Optional[Dict[str, Any]]: Group data or None if not found
        """
        return self.capsule_groups.get(group_id)
    
    def get_capsule_groups(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all capsule groups.
        
        Returns:
            Dict[str, Dict[str, Any]]: All capsule groups
        """
        return self.capsule_groups
    
    def add_capsule_to_group(self, group_id: str, capsule_id: str) -> bool:
        """
        Add a capsule to a group.
        
        Args:
            group_id: Unique identifier for the group
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was added to group successfully, False otherwise
        """
        return self._add_capsule_to_group(group_id, capsule_id)
    
    def remove_capsule_from_group(self, group_id: str, capsule_id: str) -> bool:
        """
        Remove a capsule from a group.
        
        Args:
            group_id: Unique identifier for the group
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was removed from group successfully, False otherwise
        """
        return self._remove_capsule_from_group(group_id, capsule_id)
    
    def get_capsules_in_group(self, group_id: str) -> List[Dict[str, Any]]:
        """
        Get all capsules in a group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            List[Dict[str, Any]]: All capsules in the group
        """
        if group_id not in self.capsule_groups:
            return []
        
        group = self.capsule_groups[group_id]
        capsule_ids = group.get('capsules', [])
        
        return [self.capsules[capsule_id] for capsule_id in capsule_ids if capsule_id in self.capsules]
    
    def expand_group(self, group_id: str) -> bool:
        """
        Expand a capsule group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was expanded successfully, False otherwise
        """
        logger.info("Expanding capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.capsule_groups[group_id]['expanded'] = True
        
        # Notify subscribers
        self._notify_subscribers('group_expanded', {
            'group_id': group_id
        })
        
        return True
    
    def collapse_group(self, group_id: str) -> bool:
        """
        Collapse a capsule group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was collapsed successfully, False otherwise
        """
        logger.info("Collapsing capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.capsule_groups[group_id]['expanded'] = False
        
        # Notify subscribers
        self._notify_subscribers('group_collapsed', {
            'group_id': group_id
        })
        
        return True
    
    def is_group_expanded(self, group_id: str) -> bool:
        """
        Check if a capsule group is expanded.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group is expanded, False otherwise
        """
        if group_id not in self.capsule_groups:
            return False
        
        return self.capsule_groups[group_id].get('expanded', False)
    
    def show_group(self, group_id: str) -> bool:
        """
        Show a capsule group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was shown successfully, False otherwise
        """
        logger.info("Showing capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.capsule_groups[group_id]['visible'] = True
        
        # Notify subscribers
        self._notify_subscribers('group_shown', {
            'group_id': group_id
        })
        
        return True
    
    def hide_group(self, group_id: str) -> bool:
        """
        Hide a capsule group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was hidden successfully, False otherwise
        """
        logger.info("Hiding capsule group: %s", group_id)
        
        if group_id not in self.capsule_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.capsule_groups[group_id]['visible'] = False
        
        # Notify subscribers
        self._notify_subscribers('group_hidden', {
            'group_id': group_id
        })
        
        return True
    
    def is_group_visible(self, group_id: str) -> bool:
        """
        Check if a capsule group is visible.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group is visible, False otherwise
        """
        if group_id not in self.capsule_groups:
            return False
        
        return self.capsule_groups[group_id].get('visible', True)
    
    def arrange_capsules(self) -> bool:
        """
        Arrange capsules in the dock.
        
        Returns:
            bool: True if capsules were arranged successfully, False otherwise
        """
        return self._arrange_capsules()
    
    def get_layout_data(self) -> Dict[str, Any]:
        """
        Get layout data for rendering the dock.
        
        Returns:
            Dict[str, Any]: Layout data
        """
        # Get visible capsules
        visible_capsules = self.get_visible_capsules()
        
        # Get capsule states
        capsule_states = {capsule_id: state for capsule_id, state in self.capsule_states.items() 
                         if capsule_id in visible_capsules}
        
        # Get visible groups
        visible_groups = {group_id: group for group_id, group in self.capsule_groups.items() 
                         if group.get('visible', True)}
        
        # Create layout data
        layout_data = {
            'position': self.position,
            'mode': self.mode,
            'layout': self.layout,
            'capsules': visible_capsules,
            'capsule_states': capsule_states,
            'groups': visible_groups,
            'active_capsule_id': self.active_capsule_id,
            'pinned_capsules': list(self.pinned_capsules),
            'animation_enabled': self.animation_enabled
        }
        
        return layout_data
    
    def get_interaction_history(self) -> List[Dict[str, Any]]:
        """
        Get interaction history.
        
        Returns:
            List[Dict[str, Any]]: Interaction history
        """
        return self.interaction_history
    
    def clear_interaction_history(self) -> bool:
        """
        Clear interaction history.
        
        Returns:
            bool: True if interaction history was cleared successfully, False otherwise
        """
        logger.info("Clearing interaction history")
        
        self.interaction_history = []
        
        # Notify subscribers
        self._notify_subscribers('interaction_history_cleared', {})
        
        return True
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to dock events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from dock events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def _validate_capsule(self, capsule: Dict[str, Any]) -> bool:
        """
        Validate a capsule.
        
        Args:
            capsule: Capsule data
        
        Returns:
            bool: True if capsule is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'name', 'type']
        for field in required_fields:
            if field not in capsule:
                logger.warning("Missing required field in capsule: %s", field)
                return False
        
        return True
    
    def _validate_group(self, group: Dict[str, Any]) -> bool:
        """
        Validate a group.
        
        Args:
            group: Group data
        
        Returns:
            bool: True if group is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'name']
        for field in required_fields:
            if field not in group:
                logger.warning("Missing required field in group: %s", field)
                return False
        
        return True
    
    def _add_capsule_to_groups(self, capsule: Dict[str, Any]):
        """
        Add a capsule to appropriate groups.
        
        Args:
            capsule: Capsule data
        """
        capsule_id = capsule['id']
        
        # Add to active group if it's the active capsule
        if self.active_capsule_id == capsule_id:
            self._add_capsule_to_group('active', capsule_id)
        
        # Add to pinned group if it's pinned
        if capsule_id in self.pinned_capsules:
            self._add_capsule_to_group('pinned', capsule_id)
        
        # Add to layer group if it has a layer
        layer = capsule.get('layer')
        if layer:
            layer_group_id = f"{layer}_layer"
            if 'layer' in self.capsule_groups and 'subgroups' in self.capsule_groups['layer']:
                if layer_group_id in self.capsule_groups['layer']['subgroups']:
                    self._add_capsule_to_group(f"layer.{layer_group_id}", capsule_id)
        
        # Add to industry group if it has an industry
        industry = capsule.get('industry')
        if industry:
            if 'industry' in self.capsule_groups and 'subgroups' in self.capsule_groups['industry']:
                if industry in self.capsule_groups['industry']['subgroups']:
                    self._add_capsule_to_group(f"industry.{industry}", capsule_id)
        
        # Add to recent group
        self._add_capsule_to_group('recent', capsule_id)
        
        # Add to context-aware groups if enabled
        if self.context_aware_grouping and self.context_engine:
            self._add_capsule_to_context_aware_groups(capsule)
    
    def _remove_capsule_from_groups(self, capsule_id: str):
        """
        Remove a capsule from all groups.
        
        Args:
            capsule_id: Unique identifier for the capsule
        """
        # Remove from all groups
        for group_id, group in self.capsule_groups.items():
            if 'capsules' in group and capsule_id in group['capsules']:
                group['capsules'].remove(capsule_id)
            
            # Check subgroups
            if 'subgroups' in group:
                for subgroup_id, subgroup in group['subgroups'].items():
                    if 'capsules' in subgroup and capsule_id in subgroup['capsules']:
                        subgroup['capsules'].remove(capsule_id)
    
    def _add_capsule_to_group(self, group_path: str, capsule_id: str) -> bool:
        """
        Add a capsule to a group.
        
        Args:
            group_path: Path to the group (e.g., 'layer.data_layer')
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was added to group successfully, False otherwise
        """
        # Split group path
        path_parts = group_path.split('.')
        
        # Get group
        if len(path_parts) == 1:
            # Top-level group
            group_id = path_parts[0]
            if group_id not in self.capsule_groups:
                logger.warning("Group not found: %s", group_id)
                return False
            
            group = self.capsule_groups[group_id]
        else:
            # Subgroup
            parent_group_id = path_parts[0]
            subgroup_id = path_parts[1]
            
            if parent_group_id not in self.capsule_groups:
                logger.warning("Parent group not found: %s", parent_group_id)
                return False
            
            parent_group = self.capsule_groups[parent_group_id]
            
            if 'subgroups' not in parent_group or subgroup_id not in parent_group['subgroups']:
                logger.warning("Subgroup not found: %s", subgroup_id)
                return False
            
            group = parent_group['subgroups'][subgroup_id]
        
        # Initialize capsules list if not exists
        if 'capsules' not in group:
            group['capsules'] = []
        
        # Add capsule to group if not already in it
        if capsule_id not in group['capsules']:
            group['capsules'].append(capsule_id)
        
        return True
    
    def _remove_capsule_from_group(self, group_path: str, capsule_id: str) -> bool:
        """
        Remove a capsule from a group.
        
        Args:
            group_path: Path to the group (e.g., 'layer.data_layer')
            capsule_id: Unique identifier for the capsule
        
        Returns:
            bool: True if capsule was removed from group successfully, False otherwise
        """
        # Split group path
        path_parts = group_path.split('.')
        
        # Get group
        if len(path_parts) == 1:
            # Top-level group
            group_id = path_parts[0]
            if group_id not in self.capsule_groups:
                logger.warning("Group not found: %s", group_id)
                return False
            
            group = self.capsule_groups[group_id]
        else:
            # Subgroup
            parent_group_id = path_parts[0]
            subgroup_id = path_parts[1]
            
            if parent_group_id not in self.capsule_groups:
                logger.warning("Parent group not found: %s", parent_group_id)
                return False
            
            parent_group = self.capsule_groups[parent_group_id]
            
            if 'subgroups' not in parent_group or subgroup_id not in parent_group['subgroups']:
                logger.warning("Subgroup not found: %s", subgroup_id)
                return False
            
            group = parent_group['subgroups'][subgroup_id]
        
        # Remove capsule from group
        if 'capsules' in group and capsule_id in group['capsules']:
            group['capsules'].remove(capsule_id)
        
        return True
    
    def _add_capsule_to_context_aware_groups(self, capsule: Dict[str, Any]):
        """
        Add a capsule to context-aware groups.
        
        Args:
            capsule: Capsule data
        """
        # This is a placeholder for context-aware grouping logic
        # In a real implementation, this would use the context engine to determine appropriate groups
        
        # For now, just add to suggested group
        capsule_id = capsule['id']
        self._add_capsule_to_group('suggested', capsule_id)
    
    def _update_recent_group(self):
        """Update the recent group based on interaction history."""
        # Get recent capsules based on last interaction time
        recent_capsules = sorted(
            [(capsule_id, state['last_interaction']) for capsule_id, state in self.capsule_states.items()],
            key=lambda x: x[1],
            reverse=True
        )
        
        # Limit to max visible capsules
        recent_capsules = recent_capsules[:self.max_visible_capsules]
        
        # Update recent group
        if 'recent' in self.capsule_groups:
            self.capsule_groups['recent']['capsules'] = [capsule_id for capsule_id, _ in recent_capsules]
    
    def _update_context_aware_groups(self):
        """Update context-aware groups based on current context."""
        if not self.context_engine:
            return
        
        # This is a placeholder for context-aware grouping logic
        # In a real implementation, this would use the context engine to determine appropriate groups
        
        # For now, just update suggested group with random capsules
        if 'suggested' in self.capsule_groups:
            import random
            capsule_ids = list(self.capsules.keys())
            if capsule_ids:
                suggested_capsules = random.sample(
                    capsule_ids,
                    min(5, len(capsule_ids))
                )
                self.capsule_groups['suggested']['capsules'] = suggested_capsules
    
    def _arrange_capsules(self) -> bool:
        """
        Arrange capsules in the dock.
        
        Returns:
            bool: True if capsules were arranged successfully, False otherwise
        """
        logger.info("Arranging capsules")
        
        # This is a placeholder for layout logic
        # In a real implementation, this would calculate positions and sizes for all visible capsules
        
        # For now, just set some dummy positions
        visible_capsules = self.get_visible_capsules()
        
        # Calculate positions based on layout
        if self.layout == self.LAYOUT_LINEAR:
            self._arrange_linear(visible_capsules)
        elif self.layout == self.LAYOUT_GRID:
            self._arrange_grid(visible_capsules)
        elif self.layout == self.LAYOUT_RADIAL:
            self._arrange_radial(visible_capsules)
        elif self.layout == self.LAYOUT_SWARM:
            self._arrange_swarm(visible_capsules)
        else:  # LAYOUT_ADAPTIVE or fallback
            self._arrange_adaptive(visible_capsules)
        
        # Notify subscribers
        self._notify_subscribers('capsules_arranged', {
            'layout': self.layout,
            'position': self.position,
            'mode': self.mode
        })
        
        return True
    
    def _arrange_linear(self, visible_capsules: Dict[str, Dict[str, Any]]):
        """
        Arrange capsules in a linear layout.
        
        Args:
            visible_capsules: Visible capsules
        """
        # Calculate positions
        spacing = 10
        capsule_width = 60
        capsule_height = 60
        
        # Sort capsules by priority
        sorted_capsules = self._sort_capsules_by_priority(visible_capsules)
        
        # Calculate positions based on dock position
        if self.position in [self.POSITION_TOP, self.POSITION_BOTTOM]:
            # Horizontal layout
            x = spacing
            y = spacing if self.position == self.POSITION_TOP else 0
            
            for capsule_id in sorted_capsules:
                if capsule_id in self.capsule_states:
                    self.capsule_states[capsule_id]['position'] = {'x': x, 'y': y}
                    self.capsule_states[capsule_id]['size'] = {'width': capsule_width, 'height': capsule_height}
                    x += capsule_width + spacing
        else:
            # Vertical layout
            x = spacing if self.position == self.POSITION_LEFT else 0
            y = spacing
            
            for capsule_id in sorted_capsules:
                if capsule_id in self.capsule_states:
                    self.capsule_states[capsule_id]['position'] = {'x': x, 'y': y}
                    self.capsule_states[capsule_id]['size'] = {'width': capsule_width, 'height': capsule_height}
                    y += capsule_height + spacing
    
    def _arrange_grid(self, visible_capsules: Dict[str, Dict[str, Any]]):
        """
        Arrange capsules in a grid layout.
        
        Args:
            visible_capsules: Visible capsules
        """
        # Calculate positions
        spacing = 10
        capsule_width = 60
        capsule_height = 60
        columns = 4
        
        # Sort capsules by priority
        sorted_capsules = self._sort_capsules_by_priority(visible_capsules)
        
        # Calculate positions
        for i, capsule_id in enumerate(sorted_capsules):
            if capsule_id in self.capsule_states:
                row = i // columns
                col = i % columns
                
                x = spacing + col * (capsule_width + spacing)
                y = spacing + row * (capsule_height + spacing)
                
                self.capsule_states[capsule_id]['position'] = {'x': x, 'y': y}
                self.capsule_states[capsule_id]['size'] = {'width': capsule_width, 'height': capsule_height}
    
    def _arrange_radial(self, visible_capsules: Dict[str, Dict[str, Any]]):
        """
        Arrange capsules in a radial layout.
        
        Args:
            visible_capsules: Visible capsules
        """
        # Calculate positions
        import math
        
        center_x = 200
        center_y = 200
        radius = 150
        capsule_width = 60
        capsule_height = 60
        
        # Sort capsules by priority
        sorted_capsules = self._sort_capsules_by_priority(visible_capsules)
        
        # Calculate positions
        num_capsules = len(sorted_capsules)
        
        for i, capsule_id in enumerate(sorted_capsules):
            if capsule_id in self.capsule_states:
                angle = 2 * math.pi * i / num_capsules
                
                x = center_x + radius * math.cos(angle) - capsule_width / 2
                y = center_y + radius * math.sin(angle) - capsule_height / 2
                
                self.capsule_states[capsule_id]['position'] = {'x': x, 'y': y}
                self.capsule_states[capsule_id]['size'] = {'width': capsule_width, 'height': capsule_height}
    
    def _arrange_swarm(self, visible_capsules: Dict[str, Dict[str, Any]]):
        """
        Arrange capsules in a swarm layout.
        
        Args:
            visible_capsules: Visible capsules
        """
        # This is a placeholder for swarm layout logic
        # In a real implementation, this would use a force-directed layout algorithm
        
        # For now, just use a random layout
        import random
        
        # Calculate positions
        max_x = 400
        max_y = 400
        capsule_width = 60
        capsule_height = 60
        
        for capsule_id in visible_capsules:
            if capsule_id in self.capsule_states:
                x = random.uniform(0, max_x - capsule_width)
                y = random.uniform(0, max_y - capsule_height)
                
                self.capsule_states[capsule_id]['position'] = {'x': x, 'y': y}
                self.capsule_states[capsule_id]['size'] = {'width': capsule_width, 'height': capsule_height}
    
    def _arrange_adaptive(self, visible_capsules: Dict[str, Dict[str, Any]]):
        """
        Arrange capsules in an adaptive layout.
        
        Args:
            visible_capsules: Visible capsules
        """
        # This is a placeholder for adaptive layout logic
        # In a real implementation, this would choose the best layout based on context
        
        # For now, just use a linear layout
        self._arrange_linear(visible_capsules)
    
    def _sort_capsules_by_priority(self, visible_capsules: Dict[str, Dict[str, Any]]) -> List[str]:
        """
        Sort capsules by priority.
        
        Args:
            visible_capsules: Visible capsules
        
        Returns:
            List[str]: Sorted capsule IDs
        """
        # Define priority factors
        factors = {
            'pinned': 10.0,
            'active': 5.0,
            'trust_score': 2.0,
            'confidence': 1.5,
            'interaction_count': 1.0,
            'last_interaction': 0.5
        }
        
        # Calculate priority scores
        priorities = []
        
        for capsule_id, capsule in visible_capsules.items():
            if capsule_id in self.capsule_states:
                state = self.capsule_states[capsule_id]
                
                # Calculate base score
                score = 0.0
                
                # Add pinned factor
                if capsule_id in self.pinned_capsules:
                    score += factors['pinned']
                
                # Add active factor
                if capsule_id == self.active_capsule_id:
                    score += factors['active']
                
                # Add trust score factor
                score += state.get('trust_score', 0.5) * factors['trust_score']
                
                # Add confidence factor
                score += state.get('confidence', 0.5) * factors['confidence']
                
                # Add interaction count factor
                score += min(state.get('interaction_count', 0), 100) / 100 * factors['interaction_count']
                
                # Add last interaction factor
                last_interaction = state.get('last_interaction', 0)
                current_time = self._get_current_timestamp()
                time_diff = max(0, current_time - last_interaction) / 1000  # Convert to seconds
                recency = max(0, 1.0 - min(time_diff / (24 * 60 * 60), 1.0))  # 1.0 for now, 0.0 for 24 hours ago
                score += recency * factors['last_interaction']
                
                priorities.append((capsule_id, score))
        
        # Sort by priority score (descending)
        priorities.sort(key=lambda x: x[1], reverse=True)
        
        # Return sorted capsule IDs
        return [capsule_id for capsule_id, _ in priorities]
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        # Update context-aware groups if enabled
        if self.context_aware_grouping:
            self._update_context_aware_groups()
            
            # Arrange capsules if auto-arrange is enabled
            if self.auto_arrange:
                self._arrange_capsules()
    
    def _on_theme_changed(self, event_data: Dict[str, Any]):
        """
        Handle theme changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Theme changed: %s", event_data)
        
        # Notify subscribers
        self._notify_subscribers('theme_changed', event_data)
    
    def _on_accessibility_settings_changed(self, event_data: Dict[str, Any]):
        """
        Handle accessibility settings changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Accessibility settings changed: %s", event_data)
        
        # Update animation enabled based on reduced motion setting
        if 'settings' in event_data:
            settings = event_data['settings']
            if self.FEATURE_REDUCED_MOTION in settings:
                reduced_motion = settings[self.FEATURE_REDUCED_MOTION]
                if reduced_motion.get('enabled', False):
                    self.animation_enabled = False
        
        # Notify subscribers
        self._notify_subscribers('accessibility_settings_changed', event_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]):
        """
        Deep update a dictionary.
        
        Args:
            target: Target dictionary
            source: Source dictionary
        """
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value
    
    def _get_current_timestamp(self) -> int:
        """
        Get current timestamp.
        
        Returns:
            int: Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)
    
    def to_json(self) -> str:
        """
        Serialize dock state to JSON.
        
        Returns:
            str: JSON string representation of dock state
        """
        state = {
            'position': self.position,
            'mode': self.mode,
            'layout': self.layout,
            'max_visible_capsules': self.max_visible_capsules,
            'auto_arrange': self.auto_arrange,
            'trust_weighted_display': self.trust_weighted_display,
            'context_aware_grouping': self.context_aware_grouping,
            'animation_enabled': self.animation_enabled,
            'active_capsule_id': self.active_capsule_id,
            'pinned_capsules': list(self.pinned_capsules),
            'hidden_capsules': list(self.hidden_capsules),
            'capsule_states': self.capsule_states
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize dock state from JSON.
        
        Args:
            json_str: JSON string representation of dock state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        try:
            state = json.loads(json_str)
            
            self.position = state.get('position', self.position)
            self.mode = state.get('mode', self.mode)
            self.layout = state.get('layout', self.layout)
            self.max_visible_capsules = state.get('max_visible_capsules', self.max_visible_capsules)
            self.auto_arrange = state.get('auto_arrange', self.auto_arrange)
            self.trust_weighted_display = state.get('trust_weighted_display', self.trust_weighted_display)
            self.context_aware_grouping = state.get('context_aware_grouping', self.context_aware_grouping)
            self.animation_enabled = state.get('animation_enabled', self.animation_enabled)
            self.active_capsule_id = state.get('active_capsule_id', self.active_capsule_id)
            self.pinned_capsules = set(state.get('pinned_capsules', []))
            self.hidden_capsules = set(state.get('hidden_capsules', []))
            self.capsule_states = state.get('capsule_states', self.capsule_states)
            
            return True
        except Exception as e:
            logger.error("Error deserializing dock state: %s", e)
            return False
