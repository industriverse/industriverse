"""
Timeline View Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Timeline View, a UI element that displays temporal data,
events, and workflows in a chronological format. It provides an intuitive way to visualize
and interact with time-based information across the Industrial Foundry Framework.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set
import json
from datetime import datetime, timedelta

# Initialize logger
logger = logging.getLogger(__name__)

class TimelineView:
    """
    Timeline View component for displaying temporal data and events.
    """
    
    # Timeline mode constants
    MODE_HORIZONTAL = "horizontal"
    MODE_VERTICAL = "vertical"
    MODE_RADIAL = "radial"
    MODE_SPIRAL = "spiral"
    MODE_AMBIENT = "ambient"
    
    # Timeline scale constants
    SCALE_SECONDS = "seconds"
    SCALE_MINUTES = "minutes"
    SCALE_HOURS = "hours"
    SCALE_DAYS = "days"
    SCALE_WEEKS = "weeks"
    SCALE_MONTHS = "months"
    SCALE_QUARTERS = "quarters"
    SCALE_YEARS = "years"
    SCALE_CUSTOM = "custom"
    
    # Timeline grouping constants
    GROUPING_NONE = "none"
    GROUPING_CATEGORY = "category"
    GROUPING_LAYER = "layer"
    GROUPING_AGENT = "agent"
    GROUPING_INDUSTRY = "industry"
    GROUPING_WORKFLOW = "workflow"
    GROUPING_TRUST = "trust"
    GROUPING_CUSTOM = "custom"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Timeline View with optional configuration."""
        self.config = config or {}
        self.events = {}
        self.event_groups = {}
        self.visible_events = set()
        self.hidden_events = set()
        self.pinned_events = set()
        self.highlighted_events = set()
        self.selected_event_id = None
        self.mode = self.config.get('mode', self.MODE_HORIZONTAL)
        self.scale = self.config.get('scale', self.SCALE_DAYS)
        self.grouping = self.config.get('grouping', self.GROUPING_CATEGORY)
        self.start_time = self.config.get('start_time', None)
        self.end_time = self.config.get('end_time', None)
        self.auto_scale = self.config.get('auto_scale', True)
        self.show_now_indicator = self.config.get('show_now_indicator', True)
        self.show_connections = self.config.get('show_connections', True)
        self.trust_weighted_display = self.config.get('trust_weighted_display', True)
        self.animation_enabled = self.config.get('animation_enabled', True)
        self.event_subscribers = {}
        self.event_states = {}
        self.event_connections = {}
        self.custom_scales = {}
        self.custom_groupings = {}
        self.filters = {}
        self.search_query = ""
        self.context_engine = None
        self.rendering_engine = None
        self.theme_manager = None
        self.accessibility_manager = None
        
        logger.info("Timeline View initialized with config: %s", self.config)
    
    def initialize(self, context_engine=None, rendering_engine=None, 
                  theme_manager=None, accessibility_manager=None):
        """Initialize the Timeline View and connect to required services."""
        logger.info("Initializing Timeline View")
        
        # Store references to required services
        self.context_engine = context_engine
        self.rendering_engine = rendering_engine
        self.theme_manager = theme_manager
        self.accessibility_manager = accessibility_manager
        
        # Initialize event groups
        self._initialize_event_groups()
        
        # Initialize custom scales
        self._initialize_custom_scales()
        
        # Initialize custom groupings
        self._initialize_custom_groupings()
        
        # Initialize filters
        self._initialize_filters()
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events('context_changed', self._on_context_changed)
        
        if self.theme_manager:
            self.theme_manager.subscribe_to_events('theme_changed', self._on_theme_changed)
        
        if self.accessibility_manager:
            self.accessibility_manager.subscribe_to_events('settings_changed', self._on_accessibility_settings_changed)
        
        # Set default time range if not specified
        if not self.start_time:
            self.start_time = self._get_default_start_time()
        
        if not self.end_time:
            self.end_time = self._get_default_end_time()
        
        logger.info("Timeline View initialization complete")
        return True
    
    def _initialize_event_groups(self):
        """Initialize default event groups."""
        self.event_groups = {
            'system': {
                'id': 'system',
                'name': 'System',
                'description': 'System events',
                'color': '#0078D4',
                'icon': 'system',
                'visible': True,
                'expanded': True,
                'order': 0
            },
            'user': {
                'id': 'user',
                'name': 'User',
                'description': 'User events',
                'color': '#107C10',
                'icon': 'user',
                'visible': True,
                'expanded': True,
                'order': 1
            },
            'agent': {
                'id': 'agent',
                'name': 'Agent',
                'description': 'Agent events',
                'color': '#5C2D91',
                'icon': 'agent',
                'visible': True,
                'expanded': True,
                'order': 2
            },
            'workflow': {
                'id': 'workflow',
                'name': 'Workflow',
                'description': 'Workflow events',
                'color': '#D83B01',
                'icon': 'workflow',
                'visible': True,
                'expanded': True,
                'order': 3
            },
            'data': {
                'id': 'data',
                'name': 'Data',
                'description': 'Data events',
                'color': '#FFB900',
                'icon': 'data',
                'visible': True,
                'expanded': True,
                'order': 4
            },
            'security': {
                'id': 'security',
                'name': 'Security',
                'description': 'Security events',
                'color': '#E81123',
                'icon': 'security',
                'visible': True,
                'expanded': True,
                'order': 5
            },
            'layer': {
                'id': 'layer',
                'name': 'Layer',
                'description': 'Layer-specific events',
                'color': '#00B7C3',
                'icon': 'layer',
                'visible': True,
                'expanded': False,
                'order': 6,
                'subgroups': {
                    'data_layer': {
                        'id': 'data_layer',
                        'name': 'Data Layer',
                        'description': 'Data Layer events',
                        'color': '#004E8C',
                        'icon': 'data_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 0
                    },
                    'core_ai_layer': {
                        'id': 'core_ai_layer',
                        'name': 'Core AI Layer',
                        'description': 'Core AI Layer events',
                        'color': '#773BD9',
                        'icon': 'core_ai_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 1
                    },
                    'generative_layer': {
                        'id': 'generative_layer',
                        'name': 'Generative Layer',
                        'description': 'Generative Layer events',
                        'color': '#8764B8',
                        'icon': 'generative_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 2
                    },
                    'application_layer': {
                        'id': 'application_layer',
                        'name': 'Application Layer',
                        'description': 'Application Layer events',
                        'color': '#C239B3',
                        'icon': 'application_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 3
                    },
                    'protocol_layer': {
                        'id': 'protocol_layer',
                        'name': 'Protocol Layer',
                        'description': 'Protocol Layer events',
                        'color': '#0099BC',
                        'icon': 'protocol_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 4
                    },
                    'workflow_layer': {
                        'id': 'workflow_layer',
                        'name': 'Workflow Layer',
                        'description': 'Workflow Layer events',
                        'color': '#FF8C00',
                        'icon': 'workflow_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 5
                    },
                    'ui_ux_layer': {
                        'id': 'ui_ux_layer',
                        'name': 'UI/UX Layer',
                        'description': 'UI/UX Layer events',
                        'color': '#00CC6A',
                        'icon': 'ui_ux_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 6
                    },
                    'security_layer': {
                        'id': 'security_layer',
                        'name': 'Security Layer',
                        'description': 'Security Layer events',
                        'color': '#BA141A',
                        'icon': 'security_layer',
                        'visible': True,
                        'expanded': False,
                        'order': 7
                    }
                }
            }
        }
    
    def _initialize_custom_scales(self):
        """Initialize custom time scales."""
        self.custom_scales = {
            'sprint': {
                'id': 'sprint',
                'name': 'Sprint',
                'description': 'Two-week sprint',
                'duration': 14 * 24 * 60 * 60 * 1000,  # 14 days in milliseconds
                'major_tick': 24 * 60 * 60 * 1000,  # 1 day in milliseconds
                'minor_tick': 6 * 60 * 60 * 1000,  # 6 hours in milliseconds
                'format': {
                    'major': '%a %d',  # Day of week and day of month
                    'minor': '%H:%M'  # Hour and minute
                }
            },
            'quarter': {
                'id': 'quarter',
                'name': 'Quarter',
                'description': 'Three-month quarter',
                'duration': 90 * 24 * 60 * 60 * 1000,  # 90 days in milliseconds
                'major_tick': 7 * 24 * 60 * 60 * 1000,  # 1 week in milliseconds
                'minor_tick': 24 * 60 * 60 * 1000,  # 1 day in milliseconds
                'format': {
                    'major': 'Week %W',  # Week number
                    'minor': '%a %d'  # Day of week and day of month
                }
            },
            'fiscal_year': {
                'id': 'fiscal_year',
                'name': 'Fiscal Year',
                'description': 'Fiscal year',
                'duration': 365 * 24 * 60 * 60 * 1000,  # 365 days in milliseconds
                'major_tick': 30 * 24 * 60 * 60 * 1000,  # 30 days in milliseconds
                'minor_tick': 7 * 24 * 60 * 60 * 1000,  # 1 week in milliseconds
                'format': {
                    'major': '%b',  # Month name
                    'minor': 'Week %W'  # Week number
                }
            }
        }
    
    def _initialize_custom_groupings(self):
        """Initialize custom event groupings."""
        self.custom_groupings = {
            'priority': {
                'id': 'priority',
                'name': 'Priority',
                'description': 'Group by priority',
                'groups': {
                    'critical': {
                        'id': 'critical',
                        'name': 'Critical',
                        'description': 'Critical priority events',
                        'color': '#E81123',
                        'icon': 'critical',
                        'visible': True,
                        'expanded': True,
                        'order': 0
                    },
                    'high': {
                        'id': 'high',
                        'name': 'High',
                        'description': 'High priority events',
                        'color': '#FF8C00',
                        'icon': 'high',
                        'visible': True,
                        'expanded': True,
                        'order': 1
                    },
                    'medium': {
                        'id': 'medium',
                        'name': 'Medium',
                        'description': 'Medium priority events',
                        'color': '#FFB900',
                        'icon': 'medium',
                        'visible': True,
                        'expanded': True,
                        'order': 2
                    },
                    'low': {
                        'id': 'low',
                        'name': 'Low',
                        'description': 'Low priority events',
                        'color': '#107C10',
                        'icon': 'low',
                        'visible': True,
                        'expanded': True,
                        'order': 3
                    }
                },
                'get_group': lambda event: event.get('priority', 'medium')
            },
            'status': {
                'id': 'status',
                'name': 'Status',
                'description': 'Group by status',
                'groups': {
                    'completed': {
                        'id': 'completed',
                        'name': 'Completed',
                        'description': 'Completed events',
                        'color': '#107C10',
                        'icon': 'completed',
                        'visible': True,
                        'expanded': True,
                        'order': 0
                    },
                    'in_progress': {
                        'id': 'in_progress',
                        'name': 'In Progress',
                        'description': 'In progress events',
                        'color': '#0078D4',
                        'icon': 'in_progress',
                        'visible': True,
                        'expanded': True,
                        'order': 1
                    },
                    'pending': {
                        'id': 'pending',
                        'name': 'Pending',
                        'description': 'Pending events',
                        'color': '#FFB900',
                        'icon': 'pending',
                        'visible': True,
                        'expanded': True,
                        'order': 2
                    },
                    'failed': {
                        'id': 'failed',
                        'name': 'Failed',
                        'description': 'Failed events',
                        'color': '#E81123',
                        'icon': 'failed',
                        'visible': True,
                        'expanded': True,
                        'order': 3
                    }
                },
                'get_group': lambda event: event.get('status', 'pending')
            },
            'trust': {
                'id': 'trust',
                'name': 'Trust',
                'description': 'Group by trust level',
                'groups': {
                    'high_trust': {
                        'id': 'high_trust',
                        'name': 'High Trust',
                        'description': 'High trust events',
                        'color': '#107C10',
                        'icon': 'high_trust',
                        'visible': True,
                        'expanded': True,
                        'order': 0
                    },
                    'medium_trust': {
                        'id': 'medium_trust',
                        'name': 'Medium Trust',
                        'description': 'Medium trust events',
                        'color': '#FFB900',
                        'icon': 'medium_trust',
                        'visible': True,
                        'expanded': True,
                        'order': 1
                    },
                    'low_trust': {
                        'id': 'low_trust',
                        'name': 'Low Trust',
                        'description': 'Low trust events',
                        'color': '#E81123',
                        'icon': 'low_trust',
                        'visible': True,
                        'expanded': True,
                        'order': 2
                    }
                },
                'get_group': lambda event: 'high_trust' if event.get('trust_score', 0.5) >= 0.7 else ('medium_trust' if event.get('trust_score', 0.5) >= 0.4 else 'low_trust')
            }
        }
    
    def _initialize_filters(self):
        """Initialize default filters."""
        self.filters = {
            'time_range': {
                'id': 'time_range',
                'name': 'Time Range',
                'description': 'Filter by time range',
                'type': 'range',
                'value': {
                    'start': self.start_time,
                    'end': self.end_time
                },
                'enabled': True
            },
            'event_type': {
                'id': 'event_type',
                'name': 'Event Type',
                'description': 'Filter by event type',
                'type': 'multi_select',
                'value': [],
                'options': [],
                'enabled': False
            },
            'group': {
                'id': 'group',
                'name': 'Group',
                'description': 'Filter by group',
                'type': 'multi_select',
                'value': [],
                'options': [],
                'enabled': False
            },
            'layer': {
                'id': 'layer',
                'name': 'Layer',
                'description': 'Filter by layer',
                'type': 'multi_select',
                'value': [],
                'options': [
                    {'id': 'data_layer', 'name': 'Data Layer'},
                    {'id': 'core_ai_layer', 'name': 'Core AI Layer'},
                    {'id': 'generative_layer', 'name': 'Generative Layer'},
                    {'id': 'application_layer', 'name': 'Application Layer'},
                    {'id': 'protocol_layer', 'name': 'Protocol Layer'},
                    {'id': 'workflow_layer', 'name': 'Workflow Layer'},
                    {'id': 'ui_ux_layer', 'name': 'UI/UX Layer'},
                    {'id': 'security_layer', 'name': 'Security Layer'}
                ],
                'enabled': False
            },
            'trust_score': {
                'id': 'trust_score',
                'name': 'Trust Score',
                'description': 'Filter by trust score',
                'type': 'range',
                'value': {
                    'min': 0.0,
                    'max': 1.0
                },
                'enabled': False
            }
        }
    
    def _get_default_start_time(self):
        """Get default start time (24 hours ago)."""
        return int((datetime.now() - timedelta(days=1)).timestamp() * 1000)
    
    def _get_default_end_time(self):
        """Get default end time (now)."""
        return int(datetime.now().timestamp() * 1000)
    
    def add_event(self, event: Dict[str, Any]) -> bool:
        """
        Add an event to the timeline.
        
        Args:
            event: Event data
        
        Returns:
            bool: True if event was added successfully, False otherwise
        """
        logger.info("Adding event: %s", event.get('id'))
        
        # Validate event
        if not self._validate_event(event):
            logger.warning("Invalid event: %s", event.get('id'))
            return False
        
        event_id = event['id']
        
        # Add event to timeline
        self.events[event_id] = event
        
        # Initialize event state
        self.event_states[event_id] = {
            'visible': True,
            'highlighted': False,
            'selected': False,
            'pinned': False,
            'position': {'x': 0, 'y': 0},
            'size': {'width': 0, 'height': 0},
            'expanded': False,
            'last_interaction': self._get_current_timestamp()
        }
        
        # Add to visible events
        self.visible_events.add(event_id)
        
        # Add to appropriate groups
        self._add_event_to_groups(event)
        
        # Add connections if specified
        if 'connections' in event:
            for connection in event['connections']:
                self.add_event_connection(event_id, connection['target_id'], connection.get('type', 'default'))
        
        # Update event type filter options
        self._update_event_type_filter_options()
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('event_added', {
            'event_id': event_id,
            'event': event
        })
        
        # Auto-scale timeline if enabled
        if self.auto_scale:
            self._auto_scale_timeline()
        
        return True
    
    def remove_event(self, event_id: str) -> bool:
        """
        Remove an event from the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was removed successfully, False otherwise
        """
        logger.info("Removing event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Remove from groups
        self._remove_event_from_groups(event_id)
        
        # Remove from visible events
        if event_id in self.visible_events:
            self.visible_events.remove(event_id)
        
        # Remove from hidden events
        if event_id in self.hidden_events:
            self.hidden_events.remove(event_id)
        
        # Remove from pinned events
        if event_id in self.pinned_events:
            self.pinned_events.remove(event_id)
        
        # Remove from highlighted events
        if event_id in self.highlighted_events:
            self.highlighted_events.remove(event_id)
        
        # Clear selected event if it's the one being removed
        if self.selected_event_id == event_id:
            self.selected_event_id = None
        
        # Remove event state
        if event_id in self.event_states:
            del self.event_states[event_id]
        
        # Remove connections
        self._remove_event_connections(event_id)
        
        # Remove event
        del self.events[event_id]
        
        # Update event type filter options
        self._update_event_type_filter_options()
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Notify subscribers
        self._notify_subscribers('event_removed', {
            'event_id': event_id
        })
        
        # Auto-scale timeline if enabled
        if self.auto_scale:
            self._auto_scale_timeline()
        
        return True
    
    def update_event(self, event_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update an event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
            updates: Updates to apply to the event
        
        Returns:
            bool: True if event was updated successfully, False otherwise
        """
        logger.info("Updating event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Get current event
        event = self.events[event_id]
        
        # Apply updates
        for key, value in updates.items():
            if key in event:
                if isinstance(event[key], dict) and isinstance(value, dict):
                    # Deep update for nested dictionaries
                    self._deep_update(event[key], value)
                else:
                    # Simple update for non-dict values
                    event[key] = value
        
        # Update groups if needed
        if 'group' in updates or 'type' in updates or 'layer' in updates:
            self._remove_event_from_groups(event_id)
            self._add_event_to_groups(event)
        
        # Update connections if needed
        if 'connections' in updates:
            self._remove_event_connections(event_id)
            for connection in updates['connections']:
                self.add_event_connection(event_id, connection['target_id'], connection.get('type', 'default'))
        
        # Update event type filter options
        self._update_event_type_filter_options()
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('event_updated', {
            'event_id': event_id,
            'updates': updates,
            'event': event
        })
        
        # Auto-scale timeline if enabled and time-related properties changed
        if self.auto_scale and ('start_time' in updates or 'end_time' in updates or 'time' in updates):
            self._auto_scale_timeline()
        
        return True
    
    def get_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an event by ID.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            Optional[Dict[str, Any]]: Event data or None if not found
        """
        return self.events.get(event_id)
    
    def get_events(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all events.
        
        Returns:
            Dict[str, Dict[str, Any]]: All events
        """
        return self.events
    
    def get_visible_events(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all visible events.
        
        Returns:
            Dict[str, Dict[str, Any]]: All visible events
        """
        return {event_id: event for event_id, event in self.events.items() 
                if event_id in self.visible_events}
    
    def get_event_state(self, event_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the state of an event.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            Optional[Dict[str, Any]]: Event state or None if not found
        """
        return self.event_states.get(event_id)
    
    def get_event_states(self) -> Dict[str, Dict[str, Any]]:
        """
        Get states of all events.
        
        Returns:
            Dict[str, Dict[str, Any]]: States of all events
        """
        return self.event_states
    
    def set_selected_event(self, event_id: str) -> bool:
        """
        Set the selected event.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was set as selected successfully, False otherwise
        """
        logger.info("Setting selected event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Clear previous selected event
        if self.selected_event_id and self.selected_event_id in self.event_states:
            self.event_states[self.selected_event_id]['selected'] = False
        
        # Set new selected event
        self.selected_event_id = event_id
        self.event_states[event_id]['selected'] = True
        self.event_states[event_id]['last_interaction'] = self._get_current_timestamp()
        
        # Notify subscribers
        self._notify_subscribers('selected_event_changed', {
            'event_id': event_id,
            'previous_event_id': self.selected_event_id
        })
        
        return True
    
    def clear_selected_event(self) -> bool:
        """
        Clear the selected event.
        
        Returns:
            bool: True if selected event was cleared successfully, False otherwise
        """
        logger.info("Clearing selected event")
        
        if not self.selected_event_id:
            return True
        
        # Clear selected event
        if self.selected_event_id in self.event_states:
            self.event_states[self.selected_event_id]['selected'] = False
        
        previous_event_id = self.selected_event_id
        self.selected_event_id = None
        
        # Notify subscribers
        self._notify_subscribers('selected_event_changed', {
            'event_id': None,
            'previous_event_id': previous_event_id
        })
        
        return True
    
    def get_selected_event(self) -> Optional[Dict[str, Any]]:
        """
        Get the selected event.
        
        Returns:
            Optional[Dict[str, Any]]: Selected event or None if no selected event
        """
        if not self.selected_event_id:
            return None
        
        return self.events.get(self.selected_event_id)
    
    def get_selected_event_id(self) -> Optional[str]:
        """
        Get the ID of the selected event.
        
        Returns:
            Optional[str]: ID of the selected event or None if no selected event
        """
        return self.selected_event_id
    
    def highlight_event(self, event_id: str) -> bool:
        """
        Highlight an event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was highlighted successfully, False otherwise
        """
        logger.info("Highlighting event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Add to highlighted events
        self.highlighted_events.add(event_id)
        
        # Update event state
        self.event_states[event_id]['highlighted'] = True
        
        # Notify subscribers
        self._notify_subscribers('event_highlighted', {
            'event_id': event_id
        })
        
        return True
    
    def unhighlight_event(self, event_id: str) -> bool:
        """
        Remove highlight from an event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was unhighlighted successfully, False otherwise
        """
        logger.info("Unhighlighting event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        if event_id not in self.highlighted_events:
            logger.warning("Event not highlighted: %s", event_id)
            return False
        
        # Remove from highlighted events
        self.highlighted_events.remove(event_id)
        
        # Update event state
        self.event_states[event_id]['highlighted'] = False
        
        # Notify subscribers
        self._notify_subscribers('event_unhighlighted', {
            'event_id': event_id
        })
        
        return True
    
    def is_event_highlighted(self, event_id: str) -> bool:
        """
        Check if an event is highlighted.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event is highlighted, False otherwise
        """
        return event_id in self.highlighted_events
    
    def pin_event(self, event_id: str) -> bool:
        """
        Pin an event to the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was pinned successfully, False otherwise
        """
        logger.info("Pinning event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Add to pinned events
        self.pinned_events.add(event_id)
        
        # Update event state
        self.event_states[event_id]['pinned'] = True
        
        # Notify subscribers
        self._notify_subscribers('event_pinned', {
            'event_id': event_id
        })
        
        return True
    
    def unpin_event(self, event_id: str) -> bool:
        """
        Unpin an event from the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was unpinned successfully, False otherwise
        """
        logger.info("Unpinning event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        if event_id not in self.pinned_events:
            logger.warning("Event not pinned: %s", event_id)
            return False
        
        # Remove from pinned events
        self.pinned_events.remove(event_id)
        
        # Update event state
        self.event_states[event_id]['pinned'] = False
        
        # Notify subscribers
        self._notify_subscribers('event_unpinned', {
            'event_id': event_id
        })
        
        return True
    
    def is_event_pinned(self, event_id: str) -> bool:
        """
        Check if an event is pinned.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event is pinned, False otherwise
        """
        return event_id in self.pinned_events
    
    def hide_event(self, event_id: str) -> bool:
        """
        Hide an event from the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was hidden successfully, False otherwise
        """
        logger.info("Hiding event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Add to hidden events
        self.hidden_events.add(event_id)
        
        # Remove from visible events
        if event_id in self.visible_events:
            self.visible_events.remove(event_id)
        
        # Update event state
        self.event_states[event_id]['visible'] = False
        
        # Notify subscribers
        self._notify_subscribers('event_hidden', {
            'event_id': event_id
        })
        
        return True
    
    def show_event(self, event_id: str) -> bool:
        """
        Show a hidden event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was shown successfully, False otherwise
        """
        logger.info("Showing event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        if event_id not in self.hidden_events:
            logger.warning("Event not hidden: %s", event_id)
            return False
        
        # Remove from hidden events
        self.hidden_events.remove(event_id)
        
        # Add to visible events
        self.visible_events.add(event_id)
        
        # Update event state
        self.event_states[event_id]['visible'] = True
        
        # Notify subscribers
        self._notify_subscribers('event_shown', {
            'event_id': event_id
        })
        
        return True
    
    def is_event_visible(self, event_id: str) -> bool:
        """
        Check if an event is visible.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event is visible, False otherwise
        """
        return event_id in self.visible_events
    
    def expand_event(self, event_id: str) -> bool:
        """
        Expand an event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was expanded successfully, False otherwise
        """
        logger.info("Expanding event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Update event state
        self.event_states[event_id]['expanded'] = True
        
        # Notify subscribers
        self._notify_subscribers('event_expanded', {
            'event_id': event_id
        })
        
        return True
    
    def collapse_event(self, event_id: str) -> bool:
        """
        Collapse an event in the timeline.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was collapsed successfully, False otherwise
        """
        logger.info("Collapsing event: %s", event_id)
        
        if event_id not in self.events:
            logger.warning("Event not found: %s", event_id)
            return False
        
        # Update event state
        self.event_states[event_id]['expanded'] = False
        
        # Notify subscribers
        self._notify_subscribers('event_collapsed', {
            'event_id': event_id
        })
        
        return True
    
    def is_event_expanded(self, event_id: str) -> bool:
        """
        Check if an event is expanded.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event is expanded, False otherwise
        """
        if event_id not in self.event_states:
            return False
        
        return self.event_states[event_id].get('expanded', False)
    
    def add_event_connection(self, source_id: str, target_id: str, connection_type: str = 'default') -> bool:
        """
        Add a connection between events.
        
        Args:
            source_id: Unique identifier for the source event
            target_id: Unique identifier for the target event
            connection_type: Type of connection
        
        Returns:
            bool: True if connection was added successfully, False otherwise
        """
        logger.info("Adding connection from %s to %s of type %s", source_id, target_id, connection_type)
        
        if source_id not in self.events:
            logger.warning("Source event not found: %s", source_id)
            return False
        
        if target_id not in self.events:
            logger.warning("Target event not found: %s", target_id)
            return False
        
        # Initialize connections for source if not exists
        if source_id not in self.event_connections:
            self.event_connections[source_id] = {}
        
        # Initialize connections for target if not exists
        if target_id not in self.event_connections:
            self.event_connections[target_id] = {}
        
        # Add outgoing connection to source
        if 'outgoing' not in self.event_connections[source_id]:
            self.event_connections[source_id]['outgoing'] = []
        
        # Add incoming connection to target
        if 'incoming' not in self.event_connections[target_id]:
            self.event_connections[target_id]['incoming'] = []
        
        # Check if connection already exists
        for connection in self.event_connections[source_id].get('outgoing', []):
            if connection['target_id'] == target_id and connection['type'] == connection_type:
                logger.warning("Connection already exists")
                return False
        
        # Add connection
        connection = {
            'source_id': source_id,
            'target_id': target_id,
            'type': connection_type
        }
        
        self.event_connections[source_id]['outgoing'].append(connection)
        self.event_connections[target_id]['incoming'].append(connection)
        
        # Notify subscribers
        self._notify_subscribers('connection_added', {
            'source_id': source_id,
            'target_id': target_id,
            'type': connection_type
        })
        
        return True
    
    def remove_event_connection(self, source_id: str, target_id: str, connection_type: str = None) -> bool:
        """
        Remove a connection between events.
        
        Args:
            source_id: Unique identifier for the source event
            target_id: Unique identifier for the target event
            connection_type: Type of connection (if None, remove all connections between source and target)
        
        Returns:
            bool: True if connection was removed successfully, False otherwise
        """
        logger.info("Removing connection from %s to %s of type %s", source_id, target_id, connection_type)
        
        if source_id not in self.event_connections or 'outgoing' not in self.event_connections[source_id]:
            logger.warning("Source event has no outgoing connections: %s", source_id)
            return False
        
        if target_id not in self.event_connections or 'incoming' not in self.event_connections[target_id]:
            logger.warning("Target event has no incoming connections: %s", target_id)
            return False
        
        # Find connections to remove
        outgoing_connections_to_remove = []
        for i, connection in enumerate(self.event_connections[source_id]['outgoing']):
            if connection['target_id'] == target_id and (connection_type is None or connection['type'] == connection_type):
                outgoing_connections_to_remove.append(i)
        
        incoming_connections_to_remove = []
        for i, connection in enumerate(self.event_connections[target_id]['incoming']):
            if connection['source_id'] == source_id and (connection_type is None or connection['type'] == connection_type):
                incoming_connections_to_remove.append(i)
        
        if not outgoing_connections_to_remove:
            logger.warning("No matching connections found")
            return False
        
        # Remove connections (in reverse order to avoid index issues)
        for i in reversed(outgoing_connections_to_remove):
            removed_connection = self.event_connections[source_id]['outgoing'].pop(i)
            
            # Notify subscribers
            self._notify_subscribers('connection_removed', {
                'source_id': source_id,
                'target_id': target_id,
                'type': removed_connection['type']
            })
        
        for i in reversed(incoming_connections_to_remove):
            self.event_connections[target_id]['incoming'].pop(i)
        
        return True
    
    def _remove_event_connections(self, event_id: str):
        """
        Remove all connections for an event.
        
        Args:
            event_id: Unique identifier for the event
        """
        if event_id not in self.event_connections:
            return
        
        # Get all connections
        outgoing_connections = self.event_connections[event_id].get('outgoing', [])
        incoming_connections = self.event_connections[event_id].get('incoming', [])
        
        # Remove outgoing connections
        for connection in outgoing_connections:
            target_id = connection['target_id']
            if target_id in self.event_connections and 'incoming' in self.event_connections[target_id]:
                # Find and remove the corresponding incoming connection
                for i, incoming in enumerate(self.event_connections[target_id]['incoming']):
                    if incoming['source_id'] == event_id:
                        self.event_connections[target_id]['incoming'].pop(i)
                        break
        
        # Remove incoming connections
        for connection in incoming_connections:
            source_id = connection['source_id']
            if source_id in self.event_connections and 'outgoing' in self.event_connections[source_id]:
                # Find and remove the corresponding outgoing connection
                for i, outgoing in enumerate(self.event_connections[source_id]['outgoing']):
                    if outgoing['target_id'] == event_id:
                        self.event_connections[source_id]['outgoing'].pop(i)
                        break
        
        # Remove event from connections
        del self.event_connections[event_id]
    
    def get_event_connections(self, event_id: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get connections for an event.
        
        Args:
            event_id: Unique identifier for the event
        
        Returns:
            Dict[str, List[Dict[str, Any]]]: Connections for the event
        """
        if event_id not in self.event_connections:
            return {'incoming': [], 'outgoing': []}
        
        return self.event_connections[event_id]
    
    def get_all_connections(self) -> Dict[str, Dict[str, List[Dict[str, Any]]]]:
        """
        Get all connections.
        
        Returns:
            Dict[str, Dict[str, List[Dict[str, Any]]]]: All connections
        """
        return self.event_connections
    
    def set_mode(self, mode: str) -> bool:
        """
        Set the mode of the timeline.
        
        Args:
            mode: Mode of the timeline (MODE_HORIZONTAL, MODE_VERTICAL, MODE_RADIAL, MODE_SPIRAL, MODE_AMBIENT)
        
        Returns:
            bool: True if mode was set successfully, False otherwise
        """
        logger.info("Setting timeline mode: %s", mode)
        
        valid_modes = [self.MODE_HORIZONTAL, self.MODE_VERTICAL, self.MODE_RADIAL, 
                      self.MODE_SPIRAL, self.MODE_AMBIENT]
        
        if mode not in valid_modes:
            logger.warning("Invalid mode: %s", mode)
            return False
        
        self.mode = mode
        
        # Notify subscribers
        self._notify_subscribers('mode_changed', {
            'mode': mode
        })
        
        return True
    
    def get_mode(self) -> str:
        """
        Get the mode of the timeline.
        
        Returns:
            str: Mode of the timeline
        """
        return self.mode
    
    def set_scale(self, scale: str) -> bool:
        """
        Set the scale of the timeline.
        
        Args:
            scale: Scale of the timeline (SCALE_SECONDS, SCALE_MINUTES, SCALE_HOURS, SCALE_DAYS, SCALE_WEEKS, SCALE_MONTHS, SCALE_QUARTERS, SCALE_YEARS, SCALE_CUSTOM)
        
        Returns:
            bool: True if scale was set successfully, False otherwise
        """
        logger.info("Setting timeline scale: %s", scale)
        
        valid_scales = [self.SCALE_SECONDS, self.SCALE_MINUTES, self.SCALE_HOURS, 
                       self.SCALE_DAYS, self.SCALE_WEEKS, self.SCALE_MONTHS, 
                       self.SCALE_QUARTERS, self.SCALE_YEARS, self.SCALE_CUSTOM]
        
        if scale not in valid_scales:
            logger.warning("Invalid scale: %s", scale)
            return False
        
        self.scale = scale
        
        # Notify subscribers
        self._notify_subscribers('scale_changed', {
            'scale': scale
        })
        
        return True
    
    def get_scale(self) -> str:
        """
        Get the scale of the timeline.
        
        Returns:
            str: Scale of the timeline
        """
        return self.scale
    
    def set_grouping(self, grouping: str) -> bool:
        """
        Set the grouping of the timeline.
        
        Args:
            grouping: Grouping of the timeline (GROUPING_NONE, GROUPING_CATEGORY, GROUPING_LAYER, GROUPING_AGENT, GROUPING_INDUSTRY, GROUPING_WORKFLOW, GROUPING_TRUST, GROUPING_CUSTOM)
        
        Returns:
            bool: True if grouping was set successfully, False otherwise
        """
        logger.info("Setting timeline grouping: %s", grouping)
        
        valid_groupings = [self.GROUPING_NONE, self.GROUPING_CATEGORY, self.GROUPING_LAYER, 
                          self.GROUPING_AGENT, self.GROUPING_INDUSTRY, self.GROUPING_WORKFLOW, 
                          self.GROUPING_TRUST, self.GROUPING_CUSTOM]
        
        if grouping not in valid_groupings and grouping not in self.custom_groupings:
            logger.warning("Invalid grouping: %s", grouping)
            return False
        
        self.grouping = grouping
        
        # Notify subscribers
        self._notify_subscribers('grouping_changed', {
            'grouping': grouping
        })
        
        return True
    
    def get_grouping(self) -> str:
        """
        Get the grouping of the timeline.
        
        Returns:
            str: Grouping of the timeline
        """
        return self.grouping
    
    def set_time_range(self, start_time: int, end_time: int) -> bool:
        """
        Set the time range of the timeline.
        
        Args:
            start_time: Start time in milliseconds since epoch
            end_time: End time in milliseconds since epoch
        
        Returns:
            bool: True if time range was set successfully, False otherwise
        """
        logger.info("Setting timeline time range: %s to %s", start_time, end_time)
        
        if start_time >= end_time:
            logger.warning("Invalid time range: start_time must be less than end_time")
            return False
        
        self.start_time = start_time
        self.end_time = end_time
        
        # Update time range filter
        if 'time_range' in self.filters:
            self.filters['time_range']['value'] = {
                'start': start_time,
                'end': end_time
            }
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('time_range_changed', {
            'start_time': start_time,
            'end_time': end_time
        })
        
        return True
    
    def get_time_range(self) -> Dict[str, int]:
        """
        Get the time range of the timeline.
        
        Returns:
            Dict[str, int]: Time range of the timeline
        """
        return {
            'start_time': self.start_time,
            'end_time': self.end_time
        }
    
    def set_auto_scale(self, auto_scale: bool) -> bool:
        """
        Set whether the timeline should automatically scale.
        
        Args:
            auto_scale: Whether the timeline should automatically scale
        
        Returns:
            bool: True if auto scale was set successfully, False otherwise
        """
        logger.info("Setting timeline auto scale: %s", auto_scale)
        
        self.auto_scale = auto_scale
        
        # Auto-scale timeline if enabled
        if self.auto_scale:
            self._auto_scale_timeline()
        
        # Notify subscribers
        self._notify_subscribers('auto_scale_changed', {
            'auto_scale': auto_scale
        })
        
        return True
    
    def get_auto_scale(self) -> bool:
        """
        Get whether the timeline should automatically scale.
        
        Returns:
            bool: Whether the timeline should automatically scale
        """
        return self.auto_scale
    
    def set_show_now_indicator(self, show_now_indicator: bool) -> bool:
        """
        Set whether the timeline should show the now indicator.
        
        Args:
            show_now_indicator: Whether the timeline should show the now indicator
        
        Returns:
            bool: True if show now indicator was set successfully, False otherwise
        """
        logger.info("Setting timeline show now indicator: %s", show_now_indicator)
        
        self.show_now_indicator = show_now_indicator
        
        # Notify subscribers
        self._notify_subscribers('show_now_indicator_changed', {
            'show_now_indicator': show_now_indicator
        })
        
        return True
    
    def get_show_now_indicator(self) -> bool:
        """
        Get whether the timeline should show the now indicator.
        
        Returns:
            bool: Whether the timeline should show the now indicator
        """
        return self.show_now_indicator
    
    def set_show_connections(self, show_connections: bool) -> bool:
        """
        Set whether the timeline should show connections between events.
        
        Args:
            show_connections: Whether the timeline should show connections between events
        
        Returns:
            bool: True if show connections was set successfully, False otherwise
        """
        logger.info("Setting timeline show connections: %s", show_connections)
        
        self.show_connections = show_connections
        
        # Notify subscribers
        self._notify_subscribers('show_connections_changed', {
            'show_connections': show_connections
        })
        
        return True
    
    def get_show_connections(self) -> bool:
        """
        Get whether the timeline should show connections between events.
        
        Returns:
            bool: Whether the timeline should show connections between events
        """
        return self.show_connections
    
    def set_trust_weighted_display(self, trust_weighted_display: bool) -> bool:
        """
        Set whether the timeline should display events based on trust scores.
        
        Args:
            trust_weighted_display: Whether the timeline should display events based on trust scores
        
        Returns:
            bool: True if trust weighted display was set successfully, False otherwise
        """
        logger.info("Setting timeline trust weighted display: %s", trust_weighted_display)
        
        self.trust_weighted_display = trust_weighted_display
        
        # Notify subscribers
        self._notify_subscribers('trust_weighted_display_changed', {
            'trust_weighted_display': trust_weighted_display
        })
        
        return True
    
    def get_trust_weighted_display(self) -> bool:
        """
        Get whether the timeline should display events based on trust scores.
        
        Returns:
            bool: Whether the timeline should display events based on trust scores
        """
        return self.trust_weighted_display
    
    def set_animation_enabled(self, animation_enabled: bool) -> bool:
        """
        Set whether animations should be enabled.
        
        Args:
            animation_enabled: Whether animations should be enabled
        
        Returns:
            bool: True if animation enabled was set successfully, False otherwise
        """
        logger.info("Setting timeline animation enabled: %s", animation_enabled)
        
        self.animation_enabled = animation_enabled
        
        # Notify subscribers
        self._notify_subscribers('animation_enabled_changed', {
            'animation_enabled': animation_enabled
        })
        
        return True
    
    def get_animation_enabled(self) -> bool:
        """
        Get whether animations should be enabled.
        
        Returns:
            bool: Whether animations should be enabled
        """
        return self.animation_enabled
    
    def add_custom_scale(self, scale: Dict[str, Any]) -> bool:
        """
        Add a custom time scale.
        
        Args:
            scale: Custom scale data
        
        Returns:
            bool: True if custom scale was added successfully, False otherwise
        """
        logger.info("Adding custom scale: %s", scale.get('id'))
        
        # Validate scale
        if not self._validate_custom_scale(scale):
            logger.warning("Invalid custom scale: %s", scale.get('id'))
            return False
        
        scale_id = scale['id']
        
        # Add custom scale
        self.custom_scales[scale_id] = scale
        
        # Notify subscribers
        self._notify_subscribers('custom_scale_added', {
            'scale_id': scale_id,
            'scale': scale
        })
        
        return True
    
    def remove_custom_scale(self, scale_id: str) -> bool:
        """
        Remove a custom time scale.
        
        Args:
            scale_id: Unique identifier for the custom scale
        
        Returns:
            bool: True if custom scale was removed successfully, False otherwise
        """
        logger.info("Removing custom scale: %s", scale_id)
        
        if scale_id not in self.custom_scales:
            logger.warning("Custom scale not found: %s", scale_id)
            return False
        
        # Remove custom scale
        del self.custom_scales[scale_id]
        
        # Reset scale if it was the one being removed
        if self.scale == scale_id:
            self.scale = self.SCALE_DAYS
        
        # Notify subscribers
        self._notify_subscribers('custom_scale_removed', {
            'scale_id': scale_id
        })
        
        return True
    
    def get_custom_scale(self, scale_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a custom time scale by ID.
        
        Args:
            scale_id: Unique identifier for the custom scale
        
        Returns:
            Optional[Dict[str, Any]]: Custom scale data or None if not found
        """
        return self.custom_scales.get(scale_id)
    
    def get_custom_scales(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all custom time scales.
        
        Returns:
            Dict[str, Dict[str, Any]]: All custom time scales
        """
        return self.custom_scales
    
    def add_custom_grouping(self, grouping: Dict[str, Any]) -> bool:
        """
        Add a custom event grouping.
        
        Args:
            grouping: Custom grouping data
        
        Returns:
            bool: True if custom grouping was added successfully, False otherwise
        """
        logger.info("Adding custom grouping: %s", grouping.get('id'))
        
        # Validate grouping
        if not self._validate_custom_grouping(grouping):
            logger.warning("Invalid custom grouping: %s", grouping.get('id'))
            return False
        
        grouping_id = grouping['id']
        
        # Add custom grouping
        self.custom_groupings[grouping_id] = grouping
        
        # Notify subscribers
        self._notify_subscribers('custom_grouping_added', {
            'grouping_id': grouping_id,
            'grouping': grouping
        })
        
        return True
    
    def remove_custom_grouping(self, grouping_id: str) -> bool:
        """
        Remove a custom event grouping.
        
        Args:
            grouping_id: Unique identifier for the custom grouping
        
        Returns:
            bool: True if custom grouping was removed successfully, False otherwise
        """
        logger.info("Removing custom grouping: %s", grouping_id)
        
        if grouping_id not in self.custom_groupings:
            logger.warning("Custom grouping not found: %s", grouping_id)
            return False
        
        # Remove custom grouping
        del self.custom_groupings[grouping_id]
        
        # Reset grouping if it was the one being removed
        if self.grouping == grouping_id:
            self.grouping = self.GROUPING_CATEGORY
        
        # Notify subscribers
        self._notify_subscribers('custom_grouping_removed', {
            'grouping_id': grouping_id
        })
        
        return True
    
    def get_custom_grouping(self, grouping_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a custom event grouping by ID.
        
        Args:
            grouping_id: Unique identifier for the custom grouping
        
        Returns:
            Optional[Dict[str, Any]]: Custom grouping data or None if not found
        """
        return self.custom_groupings.get(grouping_id)
    
    def get_custom_groupings(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all custom event groupings.
        
        Returns:
            Dict[str, Dict[str, Any]]: All custom event groupings
        """
        return self.custom_groupings
    
    def add_event_group(self, group: Dict[str, Any]) -> bool:
        """
        Add an event group.
        
        Args:
            group: Group data
        
        Returns:
            bool: True if group was added successfully, False otherwise
        """
        logger.info("Adding event group: %s", group.get('id'))
        
        # Validate group
        if not self._validate_group(group):
            logger.warning("Invalid group: %s", group.get('id'))
            return False
        
        group_id = group['id']
        
        # Add group
        self.event_groups[group_id] = group
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Notify subscribers
        self._notify_subscribers('group_added', {
            'group_id': group_id,
            'group': group
        })
        
        return True
    
    def remove_event_group(self, group_id: str) -> bool:
        """
        Remove an event group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was removed successfully, False otherwise
        """
        logger.info("Removing event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Remove group
        del self.event_groups[group_id]
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Notify subscribers
        self._notify_subscribers('group_removed', {
            'group_id': group_id
        })
        
        return True
    
    def update_event_group(self, group_id: str, updates: Dict[str, Any]) -> bool:
        """
        Update an event group.
        
        Args:
            group_id: Unique identifier for the group
            updates: Updates to apply to the group
        
        Returns:
            bool: True if group was updated successfully, False otherwise
        """
        logger.info("Updating event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Get current group
        group = self.event_groups[group_id]
        
        # Apply updates
        for key, value in updates.items():
            if key in group:
                if isinstance(group[key], dict) and isinstance(value, dict):
                    # Deep update for nested dictionaries
                    self._deep_update(group[key], value)
                else:
                    # Simple update for non-dict values
                    group[key] = value
        
        # Update group filter options
        self._update_group_filter_options()
        
        # Notify subscribers
        self._notify_subscribers('group_updated', {
            'group_id': group_id,
            'updates': updates,
            'group': group
        })
        
        return True
    
    def get_event_group(self, group_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an event group by ID.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            Optional[Dict[str, Any]]: Group data or None if not found
        """
        return self.event_groups.get(group_id)
    
    def get_event_groups(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all event groups.
        
        Returns:
            Dict[str, Dict[str, Any]]: All event groups
        """
        return self.event_groups
    
    def expand_group(self, group_id: str) -> bool:
        """
        Expand an event group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was expanded successfully, False otherwise
        """
        logger.info("Expanding event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.event_groups[group_id]['expanded'] = True
        
        # Notify subscribers
        self._notify_subscribers('group_expanded', {
            'group_id': group_id
        })
        
        return True
    
    def collapse_group(self, group_id: str) -> bool:
        """
        Collapse an event group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was collapsed successfully, False otherwise
        """
        logger.info("Collapsing event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.event_groups[group_id]['expanded'] = False
        
        # Notify subscribers
        self._notify_subscribers('group_collapsed', {
            'group_id': group_id
        })
        
        return True
    
    def is_group_expanded(self, group_id: str) -> bool:
        """
        Check if an event group is expanded.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group is expanded, False otherwise
        """
        if group_id not in self.event_groups:
            return False
        
        return self.event_groups[group_id].get('expanded', False)
    
    def show_group(self, group_id: str) -> bool:
        """
        Show an event group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was shown successfully, False otherwise
        """
        logger.info("Showing event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.event_groups[group_id]['visible'] = True
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('group_shown', {
            'group_id': group_id
        })
        
        return True
    
    def hide_group(self, group_id: str) -> bool:
        """
        Hide an event group.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group was hidden successfully, False otherwise
        """
        logger.info("Hiding event group: %s", group_id)
        
        if group_id not in self.event_groups:
            logger.warning("Group not found: %s", group_id)
            return False
        
        # Update group
        self.event_groups[group_id]['visible'] = False
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('group_hidden', {
            'group_id': group_id
        })
        
        return True
    
    def is_group_visible(self, group_id: str) -> bool:
        """
        Check if an event group is visible.
        
        Args:
            group_id: Unique identifier for the group
        
        Returns:
            bool: True if group is visible, False otherwise
        """
        if group_id not in self.event_groups:
            return False
        
        return self.event_groups[group_id].get('visible', True)
    
    def set_filter(self, filter_id: str, filter_value: Any, enabled: bool = True) -> bool:
        """
        Set a filter.
        
        Args:
            filter_id: Unique identifier for the filter
            filter_value: Value for the filter
            enabled: Whether the filter is enabled
        
        Returns:
            bool: True if filter was set successfully, False otherwise
        """
        logger.info("Setting filter: %s", filter_id)
        
        if filter_id not in self.filters:
            logger.warning("Filter not found: %s", filter_id)
            return False
        
        # Update filter
        self.filters[filter_id]['value'] = filter_value
        self.filters[filter_id]['enabled'] = enabled
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('filter_changed', {
            'filter_id': filter_id,
            'value': filter_value,
            'enabled': enabled
        })
        
        return True
    
    def enable_filter(self, filter_id: str) -> bool:
        """
        Enable a filter.
        
        Args:
            filter_id: Unique identifier for the filter
        
        Returns:
            bool: True if filter was enabled successfully, False otherwise
        """
        logger.info("Enabling filter: %s", filter_id)
        
        if filter_id not in self.filters:
            logger.warning("Filter not found: %s", filter_id)
            return False
        
        # Update filter
        self.filters[filter_id]['enabled'] = True
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('filter_enabled', {
            'filter_id': filter_id
        })
        
        return True
    
    def disable_filter(self, filter_id: str) -> bool:
        """
        Disable a filter.
        
        Args:
            filter_id: Unique identifier for the filter
        
        Returns:
            bool: True if filter was disabled successfully, False otherwise
        """
        logger.info("Disabling filter: %s", filter_id)
        
        if filter_id not in self.filters:
            logger.warning("Filter not found: %s", filter_id)
            return False
        
        # Update filter
        self.filters[filter_id]['enabled'] = False
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('filter_disabled', {
            'filter_id': filter_id
        })
        
        return True
    
    def get_filter(self, filter_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a filter by ID.
        
        Args:
            filter_id: Unique identifier for the filter
        
        Returns:
            Optional[Dict[str, Any]]: Filter data or None if not found
        """
        return self.filters.get(filter_id)
    
    def get_filters(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all filters.
        
        Returns:
            Dict[str, Dict[str, Any]]: All filters
        """
        return self.filters
    
    def set_search_query(self, query: str) -> bool:
        """
        Set the search query.
        
        Args:
            query: Search query
        
        Returns:
            bool: True if search query was set successfully, False otherwise
        """
        logger.info("Setting search query: %s", query)
        
        self.search_query = query
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('search_query_changed', {
            'query': query
        })
        
        return True
    
    def get_search_query(self) -> str:
        """
        Get the search query.
        
        Returns:
            str: Search query
        """
        return self.search_query
    
    def clear_search_query(self) -> bool:
        """
        Clear the search query.
        
        Returns:
            bool: True if search query was cleared successfully, False otherwise
        """
        logger.info("Clearing search query")
        
        self.search_query = ""
        
        # Apply filters
        self._apply_filters()
        
        # Notify subscribers
        self._notify_subscribers('search_query_changed', {
            'query': ""
        })
        
        return True
    
    def get_layout_data(self) -> Dict[str, Any]:
        """
        Get layout data for rendering the timeline.
        
        Returns:
            Dict[str, Any]: Layout data
        """
        # Get visible events
        visible_events = self.get_visible_events()
        
        # Get event states
        event_states = {event_id: state for event_id, state in self.event_states.items() 
                       if event_id in visible_events}
        
        # Get visible groups
        visible_groups = {group_id: group for group_id, group in self.event_groups.items() 
                         if group.get('visible', True)}
        
        # Get connections for visible events
        visible_connections = []
        for event_id in visible_events:
            if event_id in self.event_connections:
                for connection in self.event_connections[event_id].get('outgoing', []):
                    if connection['target_id'] in visible_events:
                        visible_connections.append(connection)
        
        # Create layout data
        layout_data = {
            'mode': self.mode,
            'scale': self.scale,
            'grouping': self.grouping,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'events': visible_events,
            'event_states': event_states,
            'groups': visible_groups,
            'connections': visible_connections,
            'selected_event_id': self.selected_event_id,
            'highlighted_events': list(self.highlighted_events),
            'pinned_events': list(self.pinned_events),
            'show_now_indicator': self.show_now_indicator,
            'show_connections': self.show_connections,
            'animation_enabled': self.animation_enabled,
            'current_time': self._get_current_timestamp()
        }
        
        return layout_data
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to timeline events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from timeline events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def _validate_event(self, event: Dict[str, Any]) -> bool:
        """
        Validate an event.
        
        Args:
            event: Event data
        
        Returns:
            bool: True if event is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'title', 'time']
        for field in required_fields:
            if field not in event:
                logger.warning("Missing required field in event: %s", field)
                return False
        
        return True
    
    def _validate_custom_scale(self, scale: Dict[str, Any]) -> bool:
        """
        Validate a custom scale.
        
        Args:
            scale: Custom scale data
        
        Returns:
            bool: True if custom scale is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'name', 'duration', 'major_tick', 'minor_tick']
        for field in required_fields:
            if field not in scale:
                logger.warning("Missing required field in custom scale: %s", field)
                return False
        
        return True
    
    def _validate_custom_grouping(self, grouping: Dict[str, Any]) -> bool:
        """
        Validate a custom grouping.
        
        Args:
            grouping: Custom grouping data
        
        Returns:
            bool: True if custom grouping is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'name', 'groups', 'get_group']
        for field in required_fields:
            if field not in grouping:
                logger.warning("Missing required field in custom grouping: %s", field)
                return False
        
        return True
    
    def _validate_group(self, group: Dict[str, Any]) -> bool:
        """
        Validate a group.
        
        Args:
            group: Group data
        
        Returns:
            bool: True if group is valid, False otherwise
        """
        # Check required fields
        required_fields = ['id', 'name']
        for field in required_fields:
            if field not in group:
                logger.warning("Missing required field in group: %s", field)
                return False
        
        return True
    
    def _add_event_to_groups(self, event: Dict[str, Any]):
        """
        Add an event to appropriate groups.
        
        Args:
            event: Event data
        """
        event_id = event['id']
        
        # Add to group based on event type
        event_type = event.get('type', 'default')
        if event_type in self.event_groups:
            self._add_event_to_group(event_type, event_id)
        
        # Add to layer group if it has a layer
        layer = event.get('layer')
        if layer:
            layer_group_id = f"{layer}_layer"
            if 'layer' in self.event_groups and 'subgroups' in self.event_groups['layer']:
                if layer_group_id in self.event_groups['layer']['subgroups']:
                    self._add_event_to_group(f"layer.{layer_group_id}", event_id)
    
    def _remove_event_from_groups(self, event_id: str):
        """
        Remove an event from all groups.
        
        Args:
            event_id: Unique identifier for the event
        """
        # Remove from all groups
        for group_id, group in self.event_groups.items():
            if 'events' in group and event_id in group['events']:
                group['events'].remove(event_id)
            
            # Check subgroups
            if 'subgroups' in group:
                for subgroup_id, subgroup in group['subgroups'].items():
                    if 'events' in subgroup and event_id in subgroup['events']:
                        subgroup['events'].remove(event_id)
    
    def _add_event_to_group(self, group_path: str, event_id: str) -> bool:
        """
        Add an event to a group.
        
        Args:
            group_path: Path to the group (e.g., 'layer.data_layer')
            event_id: Unique identifier for the event
        
        Returns:
            bool: True if event was added to group successfully, False otherwise
        """
        # Split group path
        path_parts = group_path.split('.')
        
        # Get group
        if len(path_parts) == 1:
            # Top-level group
            group_id = path_parts[0]
            if group_id not in self.event_groups:
                logger.warning("Group not found: %s", group_id)
                return False
            
            group = self.event_groups[group_id]
        else:
            # Subgroup
            parent_group_id = path_parts[0]
            subgroup_id = path_parts[1]
            
            if parent_group_id not in self.event_groups:
                logger.warning("Parent group not found: %s", parent_group_id)
                return False
            
            parent_group = self.event_groups[parent_group_id]
            
            if 'subgroups' not in parent_group or subgroup_id not in parent_group['subgroups']:
                logger.warning("Subgroup not found: %s", subgroup_id)
                return False
            
            group = parent_group['subgroups'][subgroup_id]
        
        # Initialize events list if not exists
        if 'events' not in group:
            group['events'] = []
        
        # Add event to group if not already in it
        if event_id not in group['events']:
            group['events'].append(event_id)
        
        return True
    
    def _update_event_type_filter_options(self):
        """Update event type filter options based on available event types."""
        if 'event_type' in self.filters:
            # Get unique event types
            event_types = set()
            for event in self.events.values():
                event_type = event.get('type')
                if event_type:
                    event_types.add(event_type)
            
            # Update options
            self.filters['event_type']['options'] = [
                {'id': event_type, 'name': event_type}
                for event_type in sorted(event_types)
            ]
    
    def _update_group_filter_options(self):
        """Update group filter options based on available groups."""
        if 'group' in self.filters:
            # Get top-level groups
            groups = []
            for group_id, group in self.event_groups.items():
                groups.append({
                    'id': group_id,
                    'name': group.get('name', group_id)
                })
            
            # Update options
            self.filters['group']['options'] = sorted(groups, key=lambda x: x['name'])
    
    def _apply_filters(self):
        """Apply filters to events."""
        logger.debug("Applying filters")
        
        # Reset visible events
        self.visible_events = set(self.events.keys())
        
        # Apply time range filter
        if 'time_range' in self.filters and self.filters['time_range']['enabled']:
            time_range = self.filters['time_range']['value']
            start_time = time_range.get('start')
            end_time = time_range.get('end')
            
            if start_time is not None and end_time is not None:
                filtered_events = set()
                for event_id, event in self.events.items():
                    event_time = event.get('time')
                    event_start_time = event.get('start_time', event_time)
                    event_end_time = event.get('end_time', event_time)
                    
                    # Check if event overlaps with time range
                    if (event_start_time is not None and event_end_time is not None and
                        event_start_time <= end_time and event_end_time >= start_time):
                        filtered_events.add(event_id)
                    elif event_time is not None and start_time <= event_time <= end_time:
                        filtered_events.add(event_id)
                
                self.visible_events &= filtered_events
        
        # Apply event type filter
        if 'event_type' in self.filters and self.filters['event_type']['enabled']:
            event_types = self.filters['event_type']['value']
            
            if event_types:
                filtered_events = set()
                for event_id, event in self.events.items():
                    event_type = event.get('type')
                    if event_type in event_types:
                        filtered_events.add(event_id)
                
                self.visible_events &= filtered_events
        
        # Apply group filter
        if 'group' in self.filters and self.filters['group']['enabled']:
            groups = self.filters['group']['value']
            
            if groups:
                filtered_events = set()
                for group_id in groups:
                    if group_id in self.event_groups:
                        group = self.event_groups[group_id]
                        if 'events' in group:
                            filtered_events.update(group['events'])
                
                self.visible_events &= filtered_events
        
        # Apply layer filter
        if 'layer' in self.filters and self.filters['layer']['enabled']:
            layers = self.filters['layer']['value']
            
            if layers:
                filtered_events = set()
                for event_id, event in self.events.items():
                    event_layer = event.get('layer')
                    if event_layer in layers:
                        filtered_events.add(event_id)
                
                self.visible_events &= filtered_events
        
        # Apply trust score filter
        if 'trust_score' in self.filters and self.filters['trust_score']['enabled']:
            trust_range = self.filters['trust_score']['value']
            min_trust = trust_range.get('min', 0.0)
            max_trust = trust_range.get('max', 1.0)
            
            filtered_events = set()
            for event_id, event in self.events.items():
                trust_score = event.get('trust_score', 0.5)
                if min_trust <= trust_score <= max_trust:
                    filtered_events.add(event_id)
            
            self.visible_events &= filtered_events
        
        # Apply search query
        if self.search_query:
            filtered_events = set()
            query = self.search_query.lower()
            
            for event_id, event in self.events.items():
                # Search in title
                if query in event.get('title', '').lower():
                    filtered_events.add(event_id)
                    continue
                
                # Search in description
                if query in event.get('description', '').lower():
                    filtered_events.add(event_id)
                    continue
                
                # Search in tags
                tags = event.get('tags', [])
                if any(query in tag.lower() for tag in tags):
                    filtered_events.add(event_id)
                    continue
            
            self.visible_events &= filtered_events
        
        # Apply hidden events
        self.visible_events -= self.hidden_events
        
        # Notify subscribers
        self._notify_subscribers('filters_applied', {
            'visible_events': list(self.visible_events)
        })
    
    def _auto_scale_timeline(self):
        """Automatically scale the timeline based on visible events."""
        logger.debug("Auto-scaling timeline")
        
        # Get time range of visible events
        min_time = None
        max_time = None
        
        for event_id in self.visible_events:
            event = self.events[event_id]
            
            event_time = event.get('time')
            event_start_time = event.get('start_time', event_time)
            event_end_time = event.get('end_time', event_time)
            
            if event_start_time is not None:
                if min_time is None or event_start_time < min_time:
                    min_time = event_start_time
            
            if event_end_time is not None:
                if max_time is None or event_end_time > max_time:
                    max_time = event_end_time
            
            if event_time is not None:
                if min_time is None or event_time < min_time:
                    min_time = event_time
                
                if max_time is None or event_time > max_time:
                    max_time = event_time
        
        # If no events, use default time range
        if min_time is None or max_time is None:
            min_time = self._get_default_start_time()
            max_time = self._get_default_end_time()
        
        # Add padding
        time_range = max_time - min_time
        padding = time_range * 0.1  # 10% padding
        
        min_time = max(0, min_time - padding)
        max_time = max_time + padding
        
        # Set time range
        self.start_time = int(min_time)
        self.end_time = int(max_time)
        
        # Update time range filter
        if 'time_range' in self.filters:
            self.filters['time_range']['value'] = {
                'start': self.start_time,
                'end': self.end_time
            }
        
        # Determine appropriate scale
        time_range_seconds = (max_time - min_time) / 1000
        
        if time_range_seconds <= 60:  # 1 minute
            self.scale = self.SCALE_SECONDS
        elif time_range_seconds <= 60 * 60:  # 1 hour
            self.scale = self.SCALE_MINUTES
        elif time_range_seconds <= 24 * 60 * 60:  # 1 day
            self.scale = self.SCALE_HOURS
        elif time_range_seconds <= 7 * 24 * 60 * 60:  # 1 week
            self.scale = self.SCALE_DAYS
        elif time_range_seconds <= 30 * 24 * 60 * 60:  # 1 month
            self.scale = self.SCALE_DAYS
        elif time_range_seconds <= 90 * 24 * 60 * 60:  # 3 months
            self.scale = self.SCALE_WEEKS
        elif time_range_seconds <= 365 * 24 * 60 * 60:  # 1 year
            self.scale = self.SCALE_MONTHS
        else:
            self.scale = self.SCALE_QUARTERS
        
        # Notify subscribers
        self._notify_subscribers('time_range_changed', {
            'start_time': self.start_time,
            'end_time': self.end_time
        })
        
        self._notify_subscribers('scale_changed', {
            'scale': self.scale
        })
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        # Notify subscribers
        self._notify_subscribers('context_changed', event_data)
    
    def _on_theme_changed(self, event_data: Dict[str, Any]):
        """
        Handle theme changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Theme changed: %s", event_data)
        
        # Notify subscribers
        self._notify_subscribers('theme_changed', event_data)
    
    def _on_accessibility_settings_changed(self, event_data: Dict[str, Any]):
        """
        Handle accessibility settings changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Accessibility settings changed: %s", event_data)
        
        # Update animation enabled based on reduced motion setting
        if 'settings' in event_data:
            settings = event_data['settings']
            if self.FEATURE_REDUCED_MOTION in settings:
                reduced_motion = settings[self.FEATURE_REDUCED_MOTION]
                if reduced_motion.get('enabled', False):
                    self.animation_enabled = False
        
        # Notify subscribers
        self._notify_subscribers('accessibility_settings_changed', event_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]):
        """
        Deep update a dictionary.
        
        Args:
            target: Target dictionary
            source: Source dictionary
        """
        for key, value in source.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value
    
    def _get_current_timestamp(self) -> int:
        """
        Get current timestamp.
        
        Returns:
            int: Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)
    
    def to_json(self) -> str:
        """
        Serialize timeline state to JSON.
        
        Returns:
            str: JSON string representation of timeline state
        """
        state = {
            'mode': self.mode,
            'scale': self.scale,
            'grouping': self.grouping,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'auto_scale': self.auto_scale,
            'show_now_indicator': self.show_now_indicator,
            'show_connections': self.show_connections,
            'trust_weighted_display': self.trust_weighted_display,
            'animation_enabled': self.animation_enabled,
            'selected_event_id': self.selected_event_id,
            'pinned_events': list(self.pinned_events),
            'hidden_events': list(self.hidden_events),
            'highlighted_events': list(self.highlighted_events),
            'filters': self.filters,
            'search_query': self.search_query
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize timeline state from JSON.
        
        Args:
            json_str: JSON string representation of timeline state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        try:
            state = json.loads(json_str)
            
            self.mode = state.get('mode', self.mode)
            self.scale = state.get('scale', self.scale)
            self.grouping = state.get('grouping', self.grouping)
            self.start_time = state.get('start_time', self.start_time)
            self.end_time = state.get('end_time', self.end_time)
            self.auto_scale = state.get('auto_scale', self.auto_scale)
            self.show_now_indicator = state.get('show_now_indicator', self.show_now_indicator)
            self.show_connections = state.get('show_connections', self.show_connections)
            self.trust_weighted_display = state.get('trust_weighted_display', self.trust_weighted_display)
            self.animation_enabled = state.get('animation_enabled', self.animation_enabled)
            self.selected_event_id = state.get('selected_event_id', self.selected_event_id)
            self.pinned_events = set(state.get('pinned_events', []))
            self.hidden_events = set(state.get('hidden_events', []))
            self.highlighted_events = set(state.get('highlighted_events', []))
            self.filters = state.get('filters', self.filters)
            self.search_query = state.get('search_query', self.search_query)
            
            # Apply filters
            self._apply_filters()
            
            return True
        except Exception as e:
            logger.error("Error deserializing timeline state: %s", e)
            return False
