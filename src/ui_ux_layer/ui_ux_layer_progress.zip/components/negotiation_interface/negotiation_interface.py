"""
Negotiation Interface Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements a negotiation interface that enables trust-weighted negotiation
between humans and agents, with protocol-native visualization of negotiation state,
trust pathways, and decision boundaries.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union, Tuple
import json
import os
import time
import math
import uuid
from datetime import datetime

# Initialize logger
logger = logging.getLogger(__name__)

class NegotiationInterface:
    """
    Negotiation Interface component for enabling trust-weighted negotiation between
    humans and agents with protocol-native visualization of negotiation state.
    """
    
    # Negotiation state constants
    STATE_INITIAL = "initial"
    STATE_PROPOSAL = "proposal"
    STATE_COUNTER = "counter"
    STATE_ACCEPTED = "accepted"
    STATE_REJECTED = "rejected"
    STATE_MODIFIED = "modified"
    STATE_COMPLETED = "completed"
    STATE_FAILED = "failed"
    
    # Negotiation type constants
    TYPE_WORKFLOW = "workflow"
    TYPE_RESOURCE = "resource"
    TYPE_PERMISSION = "permission"
    TYPE_TASK = "task"
    TYPE_DECISION = "decision"
    TYPE_CUSTOM = "custom"
    
    # Trust level constants
    TRUST_LOW = "low"
    TRUST_MEDIUM = "medium"
    TRUST_HIGH = "high"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Negotiation Interface component with optional configuration."""
        self.config = config or {}
        self.negotiations = {}
        self.active_negotiation_id = None
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.protocol_bridge = None
        self.rendering_engine = None
        self.workflow_layer = None
        
        logger.info("Negotiation Interface component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, protocol_bridge=None, 
                  rendering_engine=None, workflow_layer=None):
        """Initialize the Negotiation Interface component and connect to required services."""
        logger.info("Initializing Negotiation Interface component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.protocol_bridge = protocol_bridge
        self.rendering_engine = rendering_engine
        self.workflow_layer = workflow_layer
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        if self.workflow_layer:
            self.workflow_layer.subscribe_to_events("workflow_state_changed", self._on_workflow_state_changed)
        
        logger.info("Negotiation Interface component initialization complete")
        return True
    
    def create_negotiation(self, negotiation_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a new negotiation.
        
        Args:
            negotiation_data: Negotiation data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating negotiation: %s", negotiation_data.get("title", ""))
        
        # Validate required fields
        required_fields = ["title", "type", "initiator", "responder"]
        for field in required_fields:
            if field not in negotiation_data:
                logger.warning("Missing required field in negotiation: %s", field)
                return None
        
        # Generate negotiation ID
        negotiation_id = negotiation_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "description" not in negotiation_data:
            negotiation_data["description"] = ""
        
        if "state" not in negotiation_data:
            negotiation_data["state"] = self.STATE_INITIAL
        
        if "proposals" not in negotiation_data:
            negotiation_data["proposals"] = []
        
        if "trust_level" not in negotiation_data:
            negotiation_data["trust_level"] = self.TRUST_MEDIUM
        
        if "trust_pathway" not in negotiation_data:
            negotiation_data["trust_pathway"] = []
        
        if "decision_boundaries" not in negotiation_data:
            negotiation_data["decision_boundaries"] = {}
        
        if "metadata" not in negotiation_data:
            negotiation_data["metadata"] = {}
        
        if "created_at" not in negotiation_data:
            negotiation_data["created_at"] = datetime.now().isoformat()
        
        if "updated_at" not in negotiation_data:
            negotiation_data["updated_at"] = datetime.now().isoformat()
        
        # Store negotiation
        negotiation_data["id"] = negotiation_id
        self.negotiations[negotiation_id] = negotiation_data
        
        # Set as active negotiation if this is the first one
        if len(self.negotiations) == 1:
            self.active_negotiation_id = negotiation_id
        
        # Notify subscribers
        self._notify_subscribers("negotiation_created", {
            "negotiation_id": negotiation_id,
            "negotiation": negotiation_data
        })
        
        return negotiation_id
    
    def update_negotiation(self, negotiation_id: str, negotiation_data: Dict[str, Any]) -> bool:
        """
        Update an existing negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            negotiation_data: Updated negotiation data
        
        Returns:
            bool: True if negotiation was updated successfully, False otherwise
        """
        logger.info("Updating negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        # Get current negotiation data
        current_data = self.negotiations[negotiation_id]
        
        # Update fields
        for key, value in negotiation_data.items():
            # Don't update id, created_at
            if key in ["id", "created_at"]:
                continue
            
            current_data[key] = value
        
        # Update timestamp
        current_data["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("negotiation_updated", {
            "negotiation_id": negotiation_id,
            "negotiation": current_data
        })
        
        return True
    
    def delete_negotiation(self, negotiation_id: str) -> bool:
        """
        Delete a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            bool: True if negotiation was deleted successfully, False otherwise
        """
        logger.info("Deleting negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        # Remove negotiation
        del self.negotiations[negotiation_id]
        
        # Update active negotiation if this was the active one
        if self.active_negotiation_id == negotiation_id:
            if self.negotiations:
                self.active_negotiation_id = next(iter(self.negotiations))
            else:
                self.active_negotiation_id = None
        
        # Notify subscribers
        self._notify_subscribers("negotiation_deleted", {
            "negotiation_id": negotiation_id
        })
        
        return True
    
    def get_negotiation(self, negotiation_id: str) -> Optional[Dict[str, Any]]:
        """
        Get negotiation by ID.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            Optional[Dict[str, Any]]: Negotiation if found, None otherwise
        """
        if negotiation_id in self.negotiations:
            return self.negotiations[negotiation_id]
        else:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
    
    def get_all_negotiations(self, negotiation_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all negotiations, optionally filtered by type.
        
        Args:
            negotiation_type: Optional negotiation type to filter by
        
        Returns:
            List[Dict[str, Any]]: List of negotiations
        """
        if negotiation_type:
            return [negotiation for negotiation in self.negotiations.values() 
                   if negotiation.get("type") == negotiation_type]
        else:
            return list(self.negotiations.values())
    
    def set_active_negotiation(self, negotiation_id: Optional[str]) -> bool:
        """
        Set the active negotiation.
        
        Args:
            negotiation_id: Negotiation identifier, or None to clear active negotiation
        
        Returns:
            bool: True if active negotiation was set successfully, False otherwise
        """
        logger.info("Setting active negotiation: %s", negotiation_id)
        
        if negotiation_id is not None and negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        previous_negotiation_id = self.active_negotiation_id
        self.active_negotiation_id = negotiation_id
        
        # Notify subscribers
        self._notify_subscribers("active_negotiation_changed", {
            "previous_negotiation_id": previous_negotiation_id,
            "negotiation_id": negotiation_id
        })
        
        return True
    
    def get_active_negotiation(self) -> Optional[Dict[str, Any]]:
        """
        Get the active negotiation.
        
        Returns:
            Optional[Dict[str, Any]]: Active negotiation if set, None otherwise
        """
        if self.active_negotiation_id is not None and self.active_negotiation_id in self.negotiations:
            return self.negotiations[self.active_negotiation_id]
        else:
            return None
    
    def add_proposal(self, negotiation_id: str, proposal_data: Dict[str, Any]) -> Optional[str]:
        """
        Add a proposal to a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            proposal_data: Proposal data
        
        Returns:
            Optional[str]: Proposal ID if added successfully, None otherwise
        """
        logger.info("Adding proposal to negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
        
        # Validate required fields
        required_fields = ["proposer", "content"]
        for field in required_fields:
            if field not in proposal_data:
                logger.warning("Missing required field in proposal: %s", field)
                return None
        
        # Generate proposal ID
        proposal_id = proposal_data.get("id", str(uuid.uuid4()))
        
        # Add default fields if not present
        if "type" not in proposal_data:
            proposal_data["type"] = "initial" if not self.negotiations[negotiation_id]["proposals"] else "counter"
        
        if "state" not in proposal_data:
            proposal_data["state"] = "pending"
        
        if "trust_score" not in proposal_data:
            proposal_data["trust_score"] = 0.5
        
        if "metadata" not in proposal_data:
            proposal_data["metadata"] = {}
        
        if "created_at" not in proposal_data:
            proposal_data["created_at"] = datetime.now().isoformat()
        
        # Store proposal ID
        proposal_data["id"] = proposal_id
        
        # Add proposal to negotiation
        negotiation = self.negotiations[negotiation_id]
        negotiation["proposals"].append(proposal_data)
        negotiation["state"] = self.STATE_PROPOSAL
        negotiation["updated_at"] = datetime.now().isoformat()
        
        # Update trust pathway
        trust_pathway = negotiation.get("trust_pathway", [])
        trust_pathway.append({
            "timestamp": datetime.now().isoformat(),
            "action": "proposal_added",
            "actor": proposal_data["proposer"],
            "trust_score": proposal_data["trust_score"]
        })
        negotiation["trust_pathway"] = trust_pathway
        
        # Notify subscribers
        self._notify_subscribers("proposal_added", {
            "negotiation_id": negotiation_id,
            "proposal_id": proposal_id,
            "proposal": proposal_data
        })
        
        return proposal_id
    
    def update_proposal(self, negotiation_id: str, proposal_id: str, 
                      proposal_data: Dict[str, Any]) -> bool:
        """
        Update a proposal in a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            proposal_id: Proposal identifier
            proposal_data: Updated proposal data
        
        Returns:
            bool: True if proposal was updated successfully, False otherwise
        """
        logger.info("Updating proposal %s in negotiation %s", proposal_id, negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Find proposal in negotiation
        for i, proposal in enumerate(negotiation["proposals"]):
            if proposal.get("id") == proposal_id:
                # Update fields
                for key, value in proposal_data.items():
                    # Don't update id, created_at
                    if key in ["id", "created_at"]:
                        continue
                    
                    proposal[key] = value
                
                # Update negotiation
                negotiation["proposals"][i] = proposal
                negotiation["state"] = self.STATE_MODIFIED
                negotiation["updated_at"] = datetime.now().isoformat()
                
                # Update trust pathway
                trust_pathway = negotiation.get("trust_pathway", [])
                trust_pathway.append({
                    "timestamp": datetime.now().isoformat(),
                    "action": "proposal_updated",
                    "actor": proposal_data.get("updater", proposal.get("proposer")),
                    "trust_score": proposal.get("trust_score", 0.5)
                })
                negotiation["trust_pathway"] = trust_pathway
                
                # Notify subscribers
                self._notify_subscribers("proposal_updated", {
                    "negotiation_id": negotiation_id,
                    "proposal_id": proposal_id,
                    "proposal": proposal
                })
                
                return True
        
        logger.warning("Proposal not found in negotiation: %s", proposal_id)
        return False
    
    def accept_proposal(self, negotiation_id: str, proposal_id: str, 
                      acceptor: str, comments: Optional[str] = None) -> bool:
        """
        Accept a proposal in a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            proposal_id: Proposal identifier
            acceptor: Entity accepting the proposal
            comments: Optional comments
        
        Returns:
            bool: True if proposal was accepted successfully, False otherwise
        """
        logger.info("Accepting proposal %s in negotiation %s", proposal_id, negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Find proposal in negotiation
        for i, proposal in enumerate(negotiation["proposals"]):
            if proposal.get("id") == proposal_id:
                # Update proposal state
                proposal["state"] = "accepted"
                proposal["acceptor"] = acceptor
                proposal["accepted_at"] = datetime.now().isoformat()
                
                if comments:
                    proposal["comments"] = comments
                
                # Update negotiation
                negotiation["proposals"][i] = proposal
                negotiation["state"] = self.STATE_ACCEPTED
                negotiation["updated_at"] = datetime.now().isoformat()
                
                # Update trust pathway
                trust_pathway = negotiation.get("trust_pathway", [])
                trust_pathway.append({
                    "timestamp": datetime.now().isoformat(),
                    "action": "proposal_accepted",
                    "actor": acceptor,
                    "trust_score": proposal.get("trust_score", 0.5) + 0.1  # Increase trust score
                })
                negotiation["trust_pathway"] = trust_pathway
                
                # Notify subscribers
                self._notify_subscribers("proposal_accepted", {
                    "negotiation_id": negotiation_id,
                    "proposal_id": proposal_id,
                    "acceptor": acceptor,
                    "comments": comments
                })
                
                return True
        
        logger.warning("Proposal not found in negotiation: %s", proposal_id)
        return False
    
    def reject_proposal(self, negotiation_id: str, proposal_id: str, 
                      rejector: str, reason: Optional[str] = None) -> bool:
        """
        Reject a proposal in a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            proposal_id: Proposal identifier
            rejector: Entity rejecting the proposal
            reason: Optional reason for rejection
        
        Returns:
            bool: True if proposal was rejected successfully, False otherwise
        """
        logger.info("Rejecting proposal %s in negotiation %s", proposal_id, negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Find proposal in negotiation
        for i, proposal in enumerate(negotiation["proposals"]):
            if proposal.get("id") == proposal_id:
                # Update proposal state
                proposal["state"] = "rejected"
                proposal["rejector"] = rejector
                proposal["rejected_at"] = datetime.now().isoformat()
                
                if reason:
                    proposal["reason"] = reason
                
                # Update negotiation
                negotiation["proposals"][i] = proposal
                negotiation["state"] = self.STATE_REJECTED
                negotiation["updated_at"] = datetime.now().isoformat()
                
                # Update trust pathway
                trust_pathway = negotiation.get("trust_pathway", [])
                trust_pathway.append({
                    "timestamp": datetime.now().isoformat(),
                    "action": "proposal_rejected",
                    "actor": rejector,
                    "trust_score": max(0.1, proposal.get("trust_score", 0.5) - 0.1)  # Decrease trust score
                })
                negotiation["trust_pathway"] = trust_pathway
                
                # Notify subscribers
                self._notify_subscribers("proposal_rejected", {
                    "negotiation_id": negotiation_id,
                    "proposal_id": proposal_id,
                    "rejector": rejector,
                    "reason": reason
                })
                
                return True
        
        logger.warning("Proposal not found in negotiation: %s", proposal_id)
        return False
    
    def counter_proposal(self, negotiation_id: str, original_proposal_id: str, 
                       counter_proposal_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a counter-proposal in a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            original_proposal_id: Original proposal identifier
            counter_proposal_data: Counter-proposal data
        
        Returns:
            Optional[str]: Counter-proposal ID if created successfully, None otherwise
        """
        logger.info("Creating counter-proposal in negotiation %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
        
        negotiation = self.negotiations[negotiation_id]
        
        # Find original proposal
        original_proposal = None
        for proposal in negotiation["proposals"]:
            if proposal.get("id") == original_proposal_id:
                original_proposal = proposal
                break
        
        if not original_proposal:
            logger.warning("Original proposal not found: %s", original_proposal_id)
            return None
        
        # Set counter-proposal type
        counter_proposal_data["type"] = "counter"
        counter_proposal_data["original_proposal_id"] = original_proposal_id
        
        # Add counter-proposal
        counter_proposal_id = self.add_proposal(negotiation_id, counter_proposal_data)
        
        if counter_proposal_id:
            # Update negotiation state
            negotiation["state"] = self.STATE_COUNTER
            negotiation["updated_at"] = datetime.now().isoformat()
            
            # Notify subscribers
            self._notify_subscribers("counter_proposal_created", {
                "negotiation_id": negotiation_id,
                "original_proposal_id": original_proposal_id,
                "counter_proposal_id": counter_proposal_id
            })
        
        return counter_proposal_id
    
    def complete_negotiation(self, negotiation_id: str, outcome: Dict[str, Any]) -> bool:
        """
        Complete a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            outcome: Negotiation outcome
        
        Returns:
            bool: True if negotiation was completed successfully, False otherwise
        """
        logger.info("Completing negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Update negotiation
        negotiation["state"] = self.STATE_COMPLETED
        negotiation["outcome"] = outcome
        negotiation["completed_at"] = datetime.now().isoformat()
        negotiation["updated_at"] = datetime.now().isoformat()
        
        # Update trust pathway
        trust_pathway = negotiation.get("trust_pathway", [])
        trust_pathway.append({
            "timestamp": datetime.now().isoformat(),
            "action": "negotiation_completed",
            "actor": outcome.get("completed_by", "system"),
            "trust_score": outcome.get("final_trust_score", 0.5)
        })
        negotiation["trust_pathway"] = trust_pathway
        
        # Notify subscribers
        self._notify_subscribers("negotiation_completed", {
            "negotiation_id": negotiation_id,
            "outcome": outcome
        })
        
        return True
    
    def fail_negotiation(self, negotiation_id: str, reason: str) -> bool:
        """
        Mark a negotiation as failed.
        
        Args:
            negotiation_id: Negotiation identifier
            reason: Failure reason
        
        Returns:
            bool: True if negotiation was marked as failed successfully, False otherwise
        """
        logger.info("Marking negotiation as failed: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Update negotiation
        negotiation["state"] = self.STATE_FAILED
        negotiation["failure_reason"] = reason
        negotiation["failed_at"] = datetime.now().isoformat()
        negotiation["updated_at"] = datetime.now().isoformat()
        
        # Update trust pathway
        trust_pathway = negotiation.get("trust_pathway", [])
        trust_pathway.append({
            "timestamp": datetime.now().isoformat(),
            "action": "negotiation_failed",
            "actor": "system",
            "trust_score": 0.0
        })
        negotiation["trust_pathway"] = trust_pathway
        
        # Notify subscribers
        self._notify_subscribers("negotiation_failed", {
            "negotiation_id": negotiation_id,
            "reason": reason
        })
        
        return True
    
    def set_decision_boundaries(self, negotiation_id: str, 
                              boundaries: Dict[str, Any]) -> bool:
        """
        Set decision boundaries for a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            boundaries: Decision boundaries
        
        Returns:
            bool: True if decision boundaries were set successfully, False otherwise
        """
        logger.info("Setting decision boundaries for negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Update decision boundaries
        negotiation["decision_boundaries"] = boundaries
        negotiation["updated_at"] = datetime.now().isoformat()
        
        # Notify subscribers
        self._notify_subscribers("decision_boundaries_set", {
            "negotiation_id": negotiation_id,
            "boundaries": boundaries
        })
        
        return True
    
    def get_decision_boundaries(self, negotiation_id: str) -> Optional[Dict[str, Any]]:
        """
        Get decision boundaries for a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            Optional[Dict[str, Any]]: Decision boundaries if found, None otherwise
        """
        if negotiation_id in self.negotiations:
            return self.negotiations[negotiation_id].get("decision_boundaries", {})
        else:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
    
    def set_trust_level(self, negotiation_id: str, trust_level: str) -> bool:
        """
        Set trust level for a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
            trust_level: Trust level
        
        Returns:
            bool: True if trust level was set successfully, False otherwise
        """
        logger.info("Setting trust level for negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return False
        
        # Validate trust level
        valid_levels = [self.TRUST_LOW, self.TRUST_MEDIUM, self.TRUST_HIGH]
        if trust_level not in valid_levels:
            logger.warning("Invalid trust level: %s", trust_level)
            return False
        
        negotiation = self.negotiations[negotiation_id]
        
        # Update trust level
        negotiation["trust_level"] = trust_level
        negotiation["updated_at"] = datetime.now().isoformat()
        
        # Update trust pathway
        trust_pathway = negotiation.get("trust_pathway", [])
        trust_pathway.append({
            "timestamp": datetime.now().isoformat(),
            "action": "trust_level_set",
            "actor": "system",
            "trust_score": 0.3 if trust_level == self.TRUST_LOW else 0.6 if trust_level == self.TRUST_MEDIUM else 0.9
        })
        negotiation["trust_pathway"] = trust_pathway
        
        # Notify subscribers
        self._notify_subscribers("trust_level_set", {
            "negotiation_id": negotiation_id,
            "trust_level": trust_level
        })
        
        return True
    
    def get_trust_level(self, negotiation_id: str) -> Optional[str]:
        """
        Get trust level for a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            Optional[str]: Trust level if found, None otherwise
        """
        if negotiation_id in self.negotiations:
            return self.negotiations[negotiation_id].get("trust_level")
        else:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
    
    def get_trust_pathway(self, negotiation_id: str) -> Optional[List[Dict[str, Any]]]:
        """
        Get trust pathway for a negotiation.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            Optional[List[Dict[str, Any]]]: Trust pathway if found, None otherwise
        """
        if negotiation_id in self.negotiations:
            return self.negotiations[negotiation_id].get("trust_pathway", [])
        else:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
    
    def create_workflow_negotiation(self, title: str, workflow_id: str, 
                                  initiator: str, responder: str,
                                  workflow_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a workflow negotiation.
        
        Args:
            title: Negotiation title
            workflow_id: Workflow identifier
            initiator: Negotiation initiator
            responder: Negotiation responder
            workflow_data: Workflow data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating workflow negotiation: %s", title)
        
        # Create negotiation data
        negotiation_data = {
            "title": title,
            "type": self.TYPE_WORKFLOW,
            "initiator": initiator,
            "responder": responder,
            "metadata": {
                "workflow_id": workflow_id,
                "workflow_data": workflow_data
            }
        }
        
        # Create negotiation
        return self.create_negotiation(negotiation_data)
    
    def create_resource_negotiation(self, title: str, resource_id: str, 
                                  initiator: str, responder: str,
                                  resource_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a resource negotiation.
        
        Args:
            title: Negotiation title
            resource_id: Resource identifier
            initiator: Negotiation initiator
            responder: Negotiation responder
            resource_data: Resource data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating resource negotiation: %s", title)
        
        # Create negotiation data
        negotiation_data = {
            "title": title,
            "type": self.TYPE_RESOURCE,
            "initiator": initiator,
            "responder": responder,
            "metadata": {
                "resource_id": resource_id,
                "resource_data": resource_data
            }
        }
        
        # Create negotiation
        return self.create_negotiation(negotiation_data)
    
    def create_permission_negotiation(self, title: str, permission_id: str, 
                                    initiator: str, responder: str,
                                    permission_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a permission negotiation.
        
        Args:
            title: Negotiation title
            permission_id: Permission identifier
            initiator: Negotiation initiator
            responder: Negotiation responder
            permission_data: Permission data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating permission negotiation: %s", title)
        
        # Create negotiation data
        negotiation_data = {
            "title": title,
            "type": self.TYPE_PERMISSION,
            "initiator": initiator,
            "responder": responder,
            "metadata": {
                "permission_id": permission_id,
                "permission_data": permission_data
            }
        }
        
        # Create negotiation
        return self.create_negotiation(negotiation_data)
    
    def create_task_negotiation(self, title: str, task_id: str, 
                              initiator: str, responder: str,
                              task_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a task negotiation.
        
        Args:
            title: Negotiation title
            task_id: Task identifier
            initiator: Negotiation initiator
            responder: Negotiation responder
            task_data: Task data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating task negotiation: %s", title)
        
        # Create negotiation data
        negotiation_data = {
            "title": title,
            "type": self.TYPE_TASK,
            "initiator": initiator,
            "responder": responder,
            "metadata": {
                "task_id": task_id,
                "task_data": task_data
            }
        }
        
        # Create negotiation
        return self.create_negotiation(negotiation_data)
    
    def create_decision_negotiation(self, title: str, decision_id: str, 
                                  initiator: str, responder: str,
                                  decision_data: Dict[str, Any]) -> Optional[str]:
        """
        Create a decision negotiation.
        
        Args:
            title: Negotiation title
            decision_id: Decision identifier
            initiator: Negotiation initiator
            responder: Negotiation responder
            decision_data: Decision data
        
        Returns:
            Optional[str]: Negotiation ID if created successfully, None otherwise
        """
        logger.info("Creating decision negotiation: %s", title)
        
        # Create negotiation data
        negotiation_data = {
            "title": title,
            "type": self.TYPE_DECISION,
            "initiator": initiator,
            "responder": responder,
            "metadata": {
                "decision_id": decision_id,
                "decision_data": decision_data
            }
        }
        
        # Create negotiation
        return self.create_negotiation(negotiation_data)
    
    def export_negotiation(self, negotiation_id: str) -> Optional[Dict[str, Any]]:
        """
        Export a negotiation to a serializable format.
        
        Args:
            negotiation_id: Negotiation identifier
        
        Returns:
            Optional[Dict[str, Any]]: Exported negotiation if successful, None otherwise
        """
        logger.info("Exporting negotiation: %s", negotiation_id)
        
        if negotiation_id not in self.negotiations:
            logger.warning("Negotiation not found: %s", negotiation_id)
            return None
        
        negotiation = self.negotiations[negotiation_id]
        
        # Create export data
        export_data = {
            "negotiation": negotiation,
            "metadata": {
                "exported_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }
        
        return export_data
    
    def import_negotiation(self, import_data: Dict[str, Any]) -> Optional[str]:
        """
        Import a negotiation from a serialized format.
        
        Args:
            import_data: Imported negotiation data
        
        Returns:
            Optional[str]: Negotiation ID if import was successful, None otherwise
        """
        logger.info("Importing negotiation")
        
        # Validate import data
        if "negotiation" not in import_data:
            logger.warning("Invalid import data")
            return None
        
        # Import negotiation
        negotiation_data = import_data["negotiation"]
        negotiation_id = negotiation_data.get("id", str(uuid.uuid4()))
        negotiation_data["id"] = negotiation_id
        
        # Store negotiation
        self.negotiations[negotiation_id] = negotiation_data
        
        # Set as active negotiation
        self.set_active_negotiation(negotiation_id)
        
        # Notify subscribers
        self._notify_subscribers("negotiation_imported", {
            "negotiation_id": negotiation_id,
            "metadata": import_data.get("metadata", {})
        })
        
        return negotiation_id
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        context_data = event_data.get("context_data", {})
        
        # Check if context includes a negotiation
        negotiation_id = context_data.get("negotiation_id")
        if negotiation_id and negotiation_id in self.negotiations:
            self.set_active_negotiation(negotiation_id)
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        input_data = event_data.get("input_data", {})
        
        # Handle negotiation-related inputs
        if self.active_negotiation_id:
            negotiation = self.negotiations[self.active_negotiation_id]
            
            # Handle proposal acceptance shortcut
            if input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+A":
                # Find latest pending proposal
                pending_proposals = [p for p in negotiation["proposals"] if p.get("state") == "pending"]
                if pending_proposals:
                    latest_proposal = pending_proposals[-1]
                    self.accept_proposal(
                        self.active_negotiation_id,
                        latest_proposal["id"],
                        "user",
                        "Accepted via keyboard shortcut"
                    )
            
            # Handle proposal rejection shortcut
            elif input_type == "keyboard" and input_data.get("shortcut") == "Ctrl+R":
                # Find latest pending proposal
                pending_proposals = [p for p in negotiation["proposals"] if p.get("state") == "pending"]
                if pending_proposals:
                    latest_proposal = pending_proposals[-1]
                    self.reject_proposal(
                        self.active_negotiation_id,
                        latest_proposal["id"],
                        "user",
                        "Rejected via keyboard shortcut"
                    )
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        # Handle negotiation-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "negotiation_request":
            # Create new negotiation
            negotiation_data = message.get("negotiation_data", {})
            
            if negotiation_data:
                negotiation_id = self.create_negotiation(negotiation_data)
                
                if negotiation_id:
                    # Set as active negotiation
                    self.set_active_negotiation(negotiation_id)
        
        elif message_type == "proposal_request":
            # Add proposal to negotiation
            negotiation_id = message.get("negotiation_id")
            proposal_data = message.get("proposal_data", {})
            
            if negotiation_id and proposal_data and negotiation_id in self.negotiations:
                self.add_proposal(negotiation_id, proposal_data)
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        # Handle negotiation-related messages
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        if message_type == "negotiation_update":
            # Update negotiation
            negotiation_id = message.get("negotiation_id")
            negotiation_data = message.get("negotiation_data", {})
            
            if negotiation_id and negotiation_data and negotiation_id in self.negotiations:
                self.update_negotiation(negotiation_id, negotiation_data)
    
    def _on_workflow_state_changed(self, event_data: Dict[str, Any]):
        """
        Handle workflow state changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Workflow state changed: %s", event_data)
        
        workflow_id = event_data.get("workflow_id")
        state = event_data.get("state")
        
        if not workflow_id or not state:
            return
        
        # Find negotiations related to this workflow
        for negotiation_id, negotiation in self.negotiations.items():
            if (negotiation.get("type") == self.TYPE_WORKFLOW and
                negotiation.get("metadata", {}).get("workflow_id") == workflow_id):
                # Update negotiation metadata
                negotiation["metadata"]["workflow_data"] = state
                negotiation["updated_at"] = datetime.now().isoformat()
                
                # Notify subscribers
                self._notify_subscribers("negotiation_updated", {
                    "negotiation_id": negotiation_id,
                    "negotiation": negotiation
                })
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Negotiation Interface events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Negotiation Interface events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
