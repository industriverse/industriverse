"""
Ambient Veil Component - A specialized UI component for the Universal Skin UI/UX Layer

This component implements the Ambient Veil, which provides subtle, non-intrusive
ambient intelligence signals through the interface. It creates a layer of
ambient awareness that communicates system state, agent activities, and
contextual information through visual, auditory, and haptic cues.
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Set, Union
import json
import os
import time
import math
import uuid
from datetime import datetime
import random

# Initialize logger
logger = logging.getLogger(__name__)

class AmbientVeil:
    """
    Ambient Veil component for providing subtle, non-intrusive ambient intelligence
    signals through the interface, creating a layer of ambient awareness.
    """
    
    # Signal type constants
    SIGNAL_VISUAL = "visual"
    SIGNAL_AUDITORY = "auditory"
    SIGNAL_HAPTIC = "haptic"
    
    # Signal category constants
    CATEGORY_SYSTEM = "system"
    CATEGORY_AGENT = "agent"
    CATEGORY_WORKFLOW = "workflow"
    CATEGORY_SECURITY = "security"
    CATEGORY_TRUST = "trust"
    CATEGORY_CONTEXT = "context"
    CATEGORY_ACTIVITY = "activity"
    
    # Signal intensity constants
    INTENSITY_SUBTLE = "subtle"
    INTENSITY_MODERATE = "moderate"
    INTENSITY_PROMINENT = "prominent"
    
    # Visual signal type constants
    VISUAL_PULSE = "pulse"
    VISUAL_GLOW = "glow"
    VISUAL_RIPPLE = "ripple"
    VISUAL_PARTICLE = "particle"
    VISUAL_COLOR_SHIFT = "color_shift"
    VISUAL_PATTERN = "pattern"
    
    # Auditory signal type constants
    AUDITORY_TONE = "tone"
    AUDITORY_CHORD = "chord"
    AUDITORY_AMBIENT = "ambient"
    AUDITORY_NOTIFICATION = "notification"
    
    # Haptic signal type constants
    HAPTIC_PULSE = "pulse"
    HAPTIC_VIBRATION = "vibration"
    HAPTIC_PATTERN = "pattern"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Ambient Veil component with optional configuration."""
        self.config = config or {}
        self.signals = {}
        self.active_signals = {}
        self.signal_history = []
        self.signal_categories = {}
        self.veil_visibility = True
        self.veil_intensity = 0.5  # 0.0 to 1.0
        self.veil_mode = "adaptive"  # adaptive, minimal, standard, immersive
        self.event_subscribers = {}
        self.universal_skin_shell = None
        self.context_engine = None
        self.interaction_orchestrator = None
        self.capsule_manager = None
        self.avatar_manager = None
        self.protocol_bridge = None
        self.rendering_engine = None
        
        # Initialize signal categories
        self._initialize_categories()
        
        logger.info("Ambient Veil component initialized with config: %s", self.config)
    
    def initialize(self, universal_skin_shell=None, context_engine=None, 
                  interaction_orchestrator=None, capsule_manager=None, 
                  avatar_manager=None, protocol_bridge=None, rendering_engine=None):
        """Initialize the Ambient Veil component and connect to required services."""
        logger.info("Initializing Ambient Veil component")
        
        # Store references to required services
        self.universal_skin_shell = universal_skin_shell
        self.context_engine = context_engine
        self.interaction_orchestrator = interaction_orchestrator
        self.capsule_manager = capsule_manager
        self.avatar_manager = avatar_manager
        self.protocol_bridge = protocol_bridge
        self.rendering_engine = rendering_engine
        
        # Register default signals
        self._register_default_signals()
        
        # Subscribe to relevant events
        if self.context_engine:
            self.context_engine.subscribe_to_events("context_changed", self._on_context_changed)
            self.context_engine.subscribe_to_events("focus_changed", self._on_focus_changed)
        
        if self.interaction_orchestrator:
            self.interaction_orchestrator.subscribe_to_events("input_detected", self._on_input_detected)
        
        if self.protocol_bridge:
            self.protocol_bridge.subscribe_to_events("mcp_message_received", self._on_mcp_message_received)
            self.protocol_bridge.subscribe_to_events("a2a_message_received", self._on_a2a_message_received)
        
        if self.capsule_manager:
            self.capsule_manager.subscribe_to_events("capsule_activated", self._on_capsule_activated)
            self.capsule_manager.subscribe_to_events("capsule_deactivated", self._on_capsule_deactivated)
        
        logger.info("Ambient Veil component initialization complete")
        return True
    
    def _initialize_categories(self):
        """Initialize signal categories with default settings."""
        logger.info("Initializing signal categories")
        
        self.signal_categories = {
            self.CATEGORY_SYSTEM: {
                "id": self.CATEGORY_SYSTEM,
                "name": "System",
                "icon": "system_icon",
                "order": 0,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_AGENT: {
                "id": self.CATEGORY_AGENT,
                "name": "Agent",
                "icon": "agent_icon",
                "order": 1,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_WORKFLOW: {
                "id": self.CATEGORY_WORKFLOW,
                "name": "Workflow",
                "icon": "workflow_icon",
                "order": 2,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_SECURITY: {
                "id": self.CATEGORY_SECURITY,
                "name": "Security",
                "icon": "security_icon",
                "order": 3,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_TRUST: {
                "id": self.CATEGORY_TRUST,
                "name": "Trust",
                "icon": "trust_icon",
                "order": 4,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_CONTEXT: {
                "id": self.CATEGORY_CONTEXT,
                "name": "Context",
                "icon": "context_icon",
                "order": 5,
                "enabled": True,
                "signals": []
            },
            self.CATEGORY_ACTIVITY: {
                "id": self.CATEGORY_ACTIVITY,
                "name": "Activity",
                "icon": "activity_icon",
                "order": 6,
                "enabled": True,
                "signals": []
            }
        }
    
    def _register_default_signals(self):
        """Register default ambient signals."""
        logger.info("Registering default ambient signals")
        
        # System signals
        self.register_signal({
            "id": "system_heartbeat",
            "name": "System Heartbeat",
            "description": "Subtle pulse indicating system is active",
            "category": self.CATEGORY_SYSTEM,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_PULSE,
            "intensity": self.INTENSITY_SUBTLE,
            "color": "#3498db",
            "duration": 2000,
            "interval": 5000,
            "position": "global",
            "enabled": True,
            "handler": self._handle_system_heartbeat
        })
        
        self.register_signal({
            "id": "system_load",
            "name": "System Load",
            "description": "Visual indication of system load",
            "category": self.CATEGORY_SYSTEM,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_GLOW,
            "intensity": self.INTENSITY_SUBTLE,
            "color": "#2ecc71",
            "duration": 0,  # Continuous
            "interval": 0,
            "position": "status_bar",
            "enabled": True,
            "handler": self._handle_system_load
        })
        
        # Agent signals
        self.register_signal({
            "id": "agent_activity",
            "name": "Agent Activity",
            "description": "Visual indication of agent activity",
            "category": self.CATEGORY_AGENT,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_PARTICLE,
            "intensity": self.INTENSITY_MODERATE,
            "color": "#9b59b6",
            "duration": 1000,
            "interval": 0,  # Event-based
            "position": "agent_area",
            "enabled": True,
            "handler": self._handle_agent_activity
        })
        
        self.register_signal({
            "id": "agent_communication",
            "name": "Agent Communication",
            "description": "Visual indication of agent communication",
            "category": self.CATEGORY_AGENT,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_RIPPLE,
            "intensity": self.INTENSITY_MODERATE,
            "color": "#e74c3c",
            "duration": 2000,
            "interval": 0,  # Event-based
            "position": "between_agents",
            "enabled": True,
            "handler": self._handle_agent_communication
        })
        
        # Workflow signals
        self.register_signal({
            "id": "workflow_progress",
            "name": "Workflow Progress",
            "description": "Visual indication of workflow progress",
            "category": self.CATEGORY_WORKFLOW,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_PATTERN,
            "intensity": self.INTENSITY_MODERATE,
            "color": "#f39c12",
            "duration": 0,  # Continuous
            "interval": 0,
            "position": "workflow_area",
            "enabled": True,
            "handler": self._handle_workflow_progress
        })
        
        # Security signals
        self.register_signal({
            "id": "security_status",
            "name": "Security Status",
            "description": "Visual indication of security status",
            "category": self.CATEGORY_SECURITY,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_COLOR_SHIFT,
            "intensity": self.INTENSITY_SUBTLE,
            "color": "#27ae60",
            "duration": 0,  # Continuous
            "interval": 0,
            "position": "global_border",
            "enabled": True,
            "handler": self._handle_security_status
        })
        
        # Trust signals
        self.register_signal({
            "id": "trust_level",
            "name": "Trust Level",
            "description": "Visual indication of trust level",
            "category": self.CATEGORY_TRUST,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_GLOW,
            "intensity": self.INTENSITY_MODERATE,
            "color": "#1abc9c",
            "duration": 0,  # Continuous
            "interval": 0,
            "position": "trust_ribbon",
            "enabled": True,
            "handler": self._handle_trust_level
        })
        
        # Context signals
        self.register_signal({
            "id": "context_shift",
            "name": "Context Shift",
            "description": "Visual indication of context changes",
            "category": self.CATEGORY_CONTEXT,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_RIPPLE,
            "intensity": self.INTENSITY_MODERATE,
            "color": "#3498db",
            "duration": 3000,
            "interval": 0,  # Event-based
            "position": "global",
            "enabled": True,
            "handler": self._handle_context_shift
        })
        
        # Activity signals
        self.register_signal({
            "id": "activity_level",
            "name": "Activity Level",
            "description": "Visual indication of overall activity level",
            "category": self.CATEGORY_ACTIVITY,
            "type": self.SIGNAL_VISUAL,
            "visual_type": self.VISUAL_PARTICLE,
            "intensity": self.INTENSITY_SUBTLE,
            "color": "#e67e22",
            "duration": 0,  # Continuous
            "interval": 0,
            "position": "background",
            "enabled": True,
            "handler": self._handle_activity_level
        })
        
        # Auditory signals
        self.register_signal({
            "id": "system_tone",
            "name": "System Tone",
            "description": "Subtle auditory indication of system status",
            "category": self.CATEGORY_SYSTEM,
            "type": self.SIGNAL_AUDITORY,
            "auditory_type": self.AUDITORY_AMBIENT,
            "intensity": self.INTENSITY_SUBTLE,
            "duration": 0,  # Continuous
            "interval": 0,
            "enabled": True,
            "handler": self._handle_system_tone
        })
        
        # Haptic signals
        self.register_signal({
            "id": "notification_haptic",
            "name": "Notification Haptic",
            "description": "Haptic feedback for important notifications",
            "category": self.CATEGORY_SYSTEM,
            "type": self.SIGNAL_HAPTIC,
            "haptic_type": self.HAPTIC_PULSE,
            "intensity": self.INTENSITY_MODERATE,
            "duration": 200,
            "interval": 0,  # Event-based
            "enabled": True,
            "handler": self._handle_notification_haptic
        })
    
    def register_signal(self, signal: Dict[str, Any]) -> bool:
        """
        Register a new ambient signal.
        
        Args:
            signal: Signal definition
        
        Returns:
            bool: True if signal was registered successfully, False otherwise
        """
        logger.info("Registering signal: %s", signal.get("id"))
        
        # Validate required fields
        required_fields = ["id", "name", "category", "type", "handler"]
        for field in required_fields:
            if field not in signal:
                logger.warning("Missing required field in signal: %s", field)
                return False
        
        # Validate category
        if signal["category"] not in self.signal_categories:
            logger.warning("Invalid signal category: %s", signal["category"])
            return False
        
        # Validate type
        valid_types = [
            self.SIGNAL_VISUAL,
            self.SIGNAL_AUDITORY,
            self.SIGNAL_HAPTIC
        ]
        
        if signal["type"] not in valid_types:
            logger.warning("Invalid signal type: %s", signal["type"])
            return False
        
        # Validate type-specific fields
        if signal["type"] == self.SIGNAL_VISUAL:
            if "visual_type" not in signal:
                logger.warning("Missing visual_type for visual signal")
                return False
            
            valid_visual_types = [
                self.VISUAL_PULSE,
                self.VISUAL_GLOW,
                self.VISUAL_RIPPLE,
                self.VISUAL_PARTICLE,
                self.VISUAL_COLOR_SHIFT,
                self.VISUAL_PATTERN
            ]
            
            if signal["visual_type"] not in valid_visual_types:
                logger.warning("Invalid visual_type: %s", signal["visual_type"])
                return False
        
        elif signal["type"] == self.SIGNAL_AUDITORY:
            if "auditory_type" not in signal:
                logger.warning("Missing auditory_type for auditory signal")
                return False
            
            valid_auditory_types = [
                self.AUDITORY_TONE,
                self.AUDITORY_CHORD,
                self.AUDITORY_AMBIENT,
                self.AUDITORY_NOTIFICATION
            ]
            
            if signal["auditory_type"] not in valid_auditory_types:
                logger.warning("Invalid auditory_type: %s", signal["auditory_type"])
                return False
        
        elif signal["type"] == self.SIGNAL_HAPTIC:
            if "haptic_type" not in signal:
                logger.warning("Missing haptic_type for haptic signal")
                return False
            
            valid_haptic_types = [
                self.HAPTIC_PULSE,
                self.HAPTIC_VIBRATION,
                self.HAPTIC_PATTERN
            ]
            
            if signal["haptic_type"] not in valid_haptic_types:
                logger.warning("Invalid haptic_type: %s", signal["haptic_type"])
                return False
        
        # Add default fields if not present
        if "description" not in signal:
            signal["description"] = signal["name"]
        
        if "intensity" not in signal:
            signal["intensity"] = self.INTENSITY_SUBTLE
        
        if "duration" not in signal:
            signal["duration"] = 0
        
        if "interval" not in signal:
            signal["interval"] = 0
        
        if "enabled" not in signal:
            signal["enabled"] = True
        
        if "position" not in signal and signal["type"] == self.SIGNAL_VISUAL:
            signal["position"] = "global"
        
        if "color" not in signal and signal["type"] == self.SIGNAL_VISUAL:
            signal["color"] = "#3498db"
        
        # Store signal
        self.signals[signal["id"]] = signal
        
        # Add to category
        if signal["id"] not in self.signal_categories[signal["category"]]["signals"]:
            self.signal_categories[signal["category"]]["signals"].append(signal["id"])
        
        # Notify subscribers
        self._notify_subscribers("signal_registered", {
            "signal_id": signal["id"],
            "signal": signal
        })
        
        return True
    
    def unregister_signal(self, signal_id: str) -> bool:
        """
        Unregister an ambient signal.
        
        Args:
            signal_id: Signal identifier
        
        Returns:
            bool: True if signal was unregistered successfully, False otherwise
        """
        logger.info("Unregistering signal: %s", signal_id)
        
        if signal_id not in self.signals:
            logger.warning("Signal not found: %s", signal_id)
            return False
        
        # Get signal category
        category = self.signals[signal_id]["category"]
        
        # Remove from category
        if signal_id in self.signal_categories[category]["signals"]:
            self.signal_categories[category]["signals"].remove(signal_id)
        
        # Remove from active signals
        if signal_id in self.active_signals:
            del self.active_signals[signal_id]
        
        # Remove from signals
        del self.signals[signal_id]
        
        # Notify subscribers
        self._notify_subscribers("signal_unregistered", {
            "signal_id": signal_id
        })
        
        return True
    
    def get_signal(self, signal_id: str) -> Optional[Dict[str, Any]]:
        """
        Get signal by ID.
        
        Args:
            signal_id: Signal identifier
        
        Returns:
            Optional[Dict[str, Any]]: Signal if found, None otherwise
        """
        if signal_id in self.signals:
            return self.signals[signal_id]
        else:
            logger.warning("Signal not found: %s", signal_id)
            return None
    
    def get_signals_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Get signals by category.
        
        Args:
            category: Category identifier
        
        Returns:
            List[Dict[str, Any]]: List of signals in the category
        """
        if category not in self.signal_categories:
            logger.warning("Category not found: %s", category)
            return []
        
        # Get signal IDs in category
        signal_ids = self.signal_categories[category]["signals"]
        
        # Get signals
        signals = []
        for signal_id in signal_ids:
            if signal_id in self.signals:
                signals.append(self.signals[signal_id])
        
        return signals
    
    def get_all_signals(self) -> List[Dict[str, Any]]:
        """
        Get all registered signals.
        
        Returns:
            List[Dict[str, Any]]: List of all signals
        """
        return list(self.signals.values())
    
    def get_active_signals(self) -> List[Dict[str, Any]]:
        """
        Get currently active signals.
        
        Returns:
            List[Dict[str, Any]]: List of active signals
        """
        active_signals = []
        for signal_id, signal_instance in self.active_signals.items():
            if signal_id in self.signals:
                signal = self.signals[signal_id].copy()
                signal["instance"] = signal_instance
                active_signals.append(signal)
        
        return active_signals
    
    def activate_signal(self, signal_id: str, params: Optional[Dict[str, Any]] = None) -> bool:
        """
        Activate an ambient signal.
        
        Args:
            signal_id: Signal identifier
            params: Optional parameters for the signal
        
        Returns:
            bool: True if signal was activated successfully, False otherwise
        """
        logger.info("Activating signal: %s", signal_id)
        
        if signal_id not in self.signals:
            logger.warning("Signal not found: %s", signal_id)
            return False
        
        signal = self.signals[signal_id]
        
        # Check if signal is enabled
        if not signal.get("enabled", True):
            logger.warning("Signal is disabled: %s", signal_id)
            return False
        
        # Check if veil is visible
        if not self.veil_visibility:
            logger.warning("Ambient Veil is not visible, signal not activated: %s", signal_id)
            return False
        
        # Create signal instance
        instance_id = str(uuid.uuid4())
        
        # Merge params with signal defaults
        instance_params = {
            "id": instance_id,
            "signal_id": signal_id,
            "start_time": time.time(),
            "params": params or {}
        }
        
        # Add to active signals
        self.active_signals[signal_id] = instance_params
        
        # Add to signal history
        self.signal_history.append({
            "signal_id": signal_id,
            "instance_id": instance_id,
            "timestamp": datetime.now().isoformat(),
            "params": params
        })
        
        # Limit history size
        max_history = 100
        if len(self.signal_history) > max_history:
            self.signal_history = self.signal_history[-max_history:]
        
        # Execute signal handler
        try:
            handler = signal["handler"]
            result = handler(instance_params)
            
            # Notify subscribers
            self._notify_subscribers("signal_activated", {
                "signal_id": signal_id,
                "instance_id": instance_id,
                "params": params,
                "result": result
            })
            
            # Schedule deactivation if duration is set
            duration = signal.get("duration", 0)
            if duration > 0:
                # In a real implementation, this would use a timer or similar mechanism
                # For now, we'll just log it
                logger.debug("Signal %s will deactivate after %s ms", signal_id, duration)
            
            return True
        except Exception as e:
            logger.error("Error activating signal: %s - %s", signal_id, e)
            return False
    
    def deactivate_signal(self, signal_id: str) -> bool:
        """
        Deactivate an ambient signal.
        
        Args:
            signal_id: Signal identifier
        
        Returns:
            bool: True if signal was deactivated successfully, False otherwise
        """
        logger.info("Deactivating signal: %s", signal_id)
        
        if signal_id not in self.active_signals:
            logger.warning("Signal not active: %s", signal_id)
            return False
        
        instance_params = self.active_signals[signal_id]
        
        # Remove from active signals
        del self.active_signals[signal_id]
        
        # Notify subscribers
        self._notify_subscribers("signal_deactivated", {
            "signal_id": signal_id,
            "instance_id": instance_params["id"]
        })
        
        return True
    
    def deactivate_all_signals(self) -> bool:
        """
        Deactivate all ambient signals.
        
        Returns:
            bool: True if all signals were deactivated successfully, False otherwise
        """
        logger.info("Deactivating all signals")
        
        # Get list of active signal IDs
        active_signal_ids = list(self.active_signals.keys())
        
        # Deactivate each signal
        for signal_id in active_signal_ids:
            self.deactivate_signal(signal_id)
        
        return True
    
    def set_veil_visibility(self, visible: bool) -> bool:
        """
        Set visibility of the Ambient Veil.
        
        Args:
            visible: Whether veil should be visible
        
        Returns:
            bool: True if visibility was set successfully, False otherwise
        """
        logger.info("Setting Ambient Veil visibility: %s", visible)
        
        self.veil_visibility = visible
        
        # If hiding veil, deactivate all signals
        if not visible:
            self.deactivate_all_signals()
        
        # Notify subscribers
        self._notify_subscribers("veil_visibility_changed", {
            "visible": visible
        })
        
        return True
    
    def is_veil_visible(self) -> bool:
        """
        Check if Ambient Veil is visible.
        
        Returns:
            bool: True if veil is visible, False otherwise
        """
        return self.veil_visibility
    
    def set_veil_intensity(self, intensity: float) -> bool:
        """
        Set intensity of the Ambient Veil.
        
        Args:
            intensity: Intensity value (0.0 to 1.0)
        
        Returns:
            bool: True if intensity was set successfully, False otherwise
        """
        logger.info("Setting Ambient Veil intensity: %s", intensity)
        
        # Clamp intensity to valid range
        intensity = max(0.0, min(1.0, intensity))
        
        self.veil_intensity = intensity
        
        # Notify subscribers
        self._notify_subscribers("veil_intensity_changed", {
            "intensity": intensity
        })
        
        return True
    
    def get_veil_intensity(self) -> float:
        """
        Get intensity of the Ambient Veil.
        
        Returns:
            float: Intensity value (0.0 to 1.0)
        """
        return self.veil_intensity
    
    def set_veil_mode(self, mode: str) -> bool:
        """
        Set mode of the Ambient Veil.
        
        Args:
            mode: Veil mode (adaptive, minimal, standard, immersive)
        
        Returns:
            bool: True if mode was set successfully, False otherwise
        """
        logger.info("Setting Ambient Veil mode: %s", mode)
        
        valid_modes = ["adaptive", "minimal", "standard", "immersive"]
        
        if mode not in valid_modes:
            logger.warning("Invalid veil mode: %s", mode)
            return False
        
        self.veil_mode = mode
        
        # Adjust intensity based on mode
        if mode == "minimal":
            self.set_veil_intensity(0.2)
        elif mode == "standard":
            self.set_veil_intensity(0.5)
        elif mode == "immersive":
            self.set_veil_intensity(0.8)
        
        # Notify subscribers
        self._notify_subscribers("veil_mode_changed", {
            "mode": mode
        })
        
        return True
    
    def get_veil_mode(self) -> str:
        """
        Get mode of the Ambient Veil.
        
        Returns:
            str: Veil mode
        """
        return self.veil_mode
    
    def set_category_enabled(self, category: str, enabled: bool) -> bool:
        """
        Set enabled state of a signal category.
        
        Args:
            category: Category identifier
            enabled: Whether category should be enabled
        
        Returns:
            bool: True if enabled state was set successfully, False otherwise
        """
        logger.info("Setting signal category enabled: %s -> %s", category, enabled)
        
        if category not in self.signal_categories:
            logger.warning("Category not found: %s", category)
            return False
        
        self.signal_categories[category]["enabled"] = enabled
        
        # If disabling category, deactivate all signals in category
        if not enabled:
            for signal_id in self.signal_categories[category]["signals"]:
                if signal_id in self.active_signals:
                    self.deactivate_signal(signal_id)
        
        # Notify subscribers
        self._notify_subscribers("category_enabled_changed", {
            "category": category,
            "enabled": enabled
        })
        
        return True
    
    def is_category_enabled(self, category: str) -> Optional[bool]:
        """
        Check if a signal category is enabled.
        
        Args:
            category: Category identifier
        
        Returns:
            Optional[bool]: Whether category is enabled if found, None otherwise
        """
        if category not in self.signal_categories:
            logger.warning("Category not found: %s", category)
            return None
        
        return self.signal_categories[category]["enabled"]
    
    def get_all_categories(self) -> List[Dict[str, Any]]:
        """
        Get all signal categories.
        
        Returns:
            List[Dict[str, Any]]: List of all categories
        """
        # Convert to list and sort by order
        categories = list(self.signal_categories.values())
        categories.sort(key=lambda c: c.get("order", 0))
        
        return categories
    
    def _on_context_changed(self, event_data: Dict[str, Any]):
        """
        Handle context changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Context changed: %s", event_data)
        
        context_type = event_data.get("context_type")
        
        # Activate context shift signal
        self.activate_signal("context_shift", {
            "context_type": context_type
        })
        
        # Adjust veil mode based on context
        if context_type == "focused":
            self.set_veil_mode("minimal")
        elif context_type == "ambient":
            self.set_veil_mode("standard")
        elif context_type == "immersive":
            self.set_veil_mode("immersive")
    
    def _on_focus_changed(self, event_data: Dict[str, Any]):
        """
        Handle focus changed event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Focus changed: %s", event_data)
        
        focus_type = event_data.get("focus_type")
        
        # Adjust veil intensity based on focus
        if focus_type == "deep":
            self.set_veil_intensity(0.2)  # Subtle when user is deeply focused
        elif focus_type == "active":
            self.set_veil_intensity(0.5)  # Standard when user is actively engaged
        elif focus_type == "passive":
            self.set_veil_intensity(0.7)  # More prominent when user is passively observing
    
    def _on_input_detected(self, event_data: Dict[str, Any]):
        """
        Handle input detected event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Input detected: %s", event_data)
        
        input_type = event_data.get("input_type")
        
        # Temporarily increase veil intensity on user input
        if input_type in ["keyboard", "mouse", "touch", "voice"]:
            current_intensity = self.veil_intensity
            self.set_veil_intensity(min(1.0, current_intensity + 0.2))
            
            # In a real implementation, this would use a timer to restore original intensity
            # For now, we'll just log it
            logger.debug("Veil intensity will restore to %s after input effect", current_intensity)
    
    def _on_mcp_message_received(self, event_data: Dict[str, Any]):
        """
        Handle MCP message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("MCP message received: %s", event_data)
        
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        # Activate agent communication signal for agent messages
        if message_type == "agent_message":
            self.activate_signal("agent_communication", {
                "source": message.get("source", ""),
                "target": message.get("target", ""),
                "message_type": message_type
            })
    
    def _on_a2a_message_received(self, event_data: Dict[str, Any]):
        """
        Handle A2A message received event.
        
        Args:
            event_data: Event data
        """
        logger.debug("A2A message received: %s", event_data)
        
        message = event_data.get("message", {})
        message_type = message.get("type")
        
        # Activate agent activity signal for agent messages
        self.activate_signal("agent_activity", {
            "agent_id": message.get("agent_id", ""),
            "message_type": message_type
        })
    
    def _on_capsule_activated(self, event_data: Dict[str, Any]):
        """
        Handle capsule activated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule activated: %s", event_data)
        
        capsule_type = event_data.get("capsule_type")
        
        # Activate agent activity signal for agent capsules
        if capsule_type == "agent":
            self.activate_signal("agent_activity", {
                "agent_id": event_data.get("agent_id", ""),
                "capsule_id": event_data.get("capsule_id", "")
            })
    
    def _on_capsule_deactivated(self, event_data: Dict[str, Any]):
        """
        Handle capsule deactivated event.
        
        Args:
            event_data: Event data
        """
        logger.debug("Capsule deactivated: %s", event_data)
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to Ambient Veil events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = set()
        
        self.event_subscribers[event_type].add(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from Ambient Veil events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    # Default signal handlers
    
    def _handle_system_heartbeat(self, params: Dict[str, Any]) -> bool:
        """
        Handle system heartbeat signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling system heartbeat signal")
        
        # In a real implementation, this would create a visual pulse effect
        # For now, we'll just log it
        logger.debug("System heartbeat pulse effect")
        
        return True
    
    def _handle_system_load(self, params: Dict[str, Any]) -> bool:
        """
        Handle system load signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling system load signal")
        
        # In a real implementation, this would create a visual glow effect based on system load
        # For now, we'll simulate it with random values
        load = random.random()
        
        # Adjust color based on load (green to yellow to red)
        if load < 0.3:
            color = "#2ecc71"  # Green
        elif load < 0.7:
            color = "#f39c12"  # Yellow
        else:
            color = "#e74c3c"  # Red
        
        logger.debug("System load glow effect: %s (%s)", load, color)
        
        return True
    
    def _handle_agent_activity(self, params: Dict[str, Any]) -> bool:
        """
        Handle agent activity signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling agent activity signal")
        
        # In a real implementation, this would create a visual particle effect
        # For now, we'll just log it
        agent_id = params.get("params", {}).get("agent_id", "unknown")
        logger.debug("Agent activity particle effect for agent: %s", agent_id)
        
        return True
    
    def _handle_agent_communication(self, params: Dict[str, Any]) -> bool:
        """
        Handle agent communication signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling agent communication signal")
        
        # In a real implementation, this would create a visual ripple effect
        # For now, we'll just log it
        signal_params = params.get("params", {})
        source = signal_params.get("source", "unknown")
        target = signal_params.get("target", "unknown")
        logger.debug("Agent communication ripple effect: %s -> %s", source, target)
        
        return True
    
    def _handle_workflow_progress(self, params: Dict[str, Any]) -> bool:
        """
        Handle workflow progress signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling workflow progress signal")
        
        # In a real implementation, this would create a visual pattern effect
        # For now, we'll simulate it with random values
        progress = random.random()
        
        logger.debug("Workflow progress pattern effect: %s", progress)
        
        return True
    
    def _handle_security_status(self, params: Dict[str, Any]) -> bool:
        """
        Handle security status signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling security status signal")
        
        # In a real implementation, this would create a visual color shift effect
        # For now, we'll simulate it with random values
        status = random.choice(["secure", "warning", "alert"])
        
        # Adjust color based on status
        if status == "secure":
            color = "#27ae60"  # Green
        elif status == "warning":
            color = "#f39c12"  # Yellow
        else:
            color = "#e74c3c"  # Red
        
        logger.debug("Security status color shift effect: %s (%s)", status, color)
        
        return True
    
    def _handle_trust_level(self, params: Dict[str, Any]) -> bool:
        """
        Handle trust level signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling trust level signal")
        
        # In a real implementation, this would create a visual glow effect
        # For now, we'll simulate it with random values
        trust_level = random.random()
        
        # Adjust color based on trust level (red to yellow to green)
        if trust_level < 0.3:
            color = "#e74c3c"  # Red
        elif trust_level < 0.7:
            color = "#f39c12"  # Yellow
        else:
            color = "#2ecc71"  # Green
        
        logger.debug("Trust level glow effect: %s (%s)", trust_level, color)
        
        return True
    
    def _handle_context_shift(self, params: Dict[str, Any]) -> bool:
        """
        Handle context shift signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling context shift signal")
        
        # In a real implementation, this would create a visual ripple effect
        # For now, we'll just log it
        context_type = params.get("params", {}).get("context_type", "unknown")
        logger.debug("Context shift ripple effect for context: %s", context_type)
        
        return True
    
    def _handle_activity_level(self, params: Dict[str, Any]) -> bool:
        """
        Handle activity level signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling activity level signal")
        
        # In a real implementation, this would create a visual particle effect
        # For now, we'll simulate it with random values
        activity_level = random.random()
        
        logger.debug("Activity level particle effect: %s", activity_level)
        
        return True
    
    def _handle_system_tone(self, params: Dict[str, Any]) -> bool:
        """
        Handle system tone signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling system tone signal")
        
        # In a real implementation, this would create an auditory ambient effect
        # For now, we'll just log it
        logger.debug("System tone ambient effect")
        
        return True
    
    def _handle_notification_haptic(self, params: Dict[str, Any]) -> bool:
        """
        Handle notification haptic signal.
        
        Args:
            params: Signal parameters
        
        Returns:
            bool: True if signal was handled successfully, False otherwise
        """
        logger.debug("Handling notification haptic signal")
        
        # In a real implementation, this would create a haptic pulse effect
        # For now, we'll just log it
        logger.debug("Notification haptic pulse effect")
        
        return True
