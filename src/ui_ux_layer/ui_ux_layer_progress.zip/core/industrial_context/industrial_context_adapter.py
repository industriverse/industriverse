"""
Industrial Context Adapter for the Industriverse UI/UX Layer.

This module provides industry-specific context adaptation capabilities for the Universal Skin
and Agent Capsules, enabling seamless integration with various industrial environments and workflows.

Author: Manus
"""

import logging
import time
import threading
import uuid
import json
from typing import Dict, List, Optional, Any, Callable, Tuple, Set, Union
from enum import Enum
from dataclasses import dataclass

class IndustryType(Enum):
    """Enumeration of supported industry types."""
    MANUFACTURING = "manufacturing"
    LOGISTICS = "logistics"
    ENERGY = "energy"
    RETAIL = "retail"
    AEROSPACE = "aerospace"
    DEFENSE = "defense"
    DATA_CENTERS = "data_centers"
    EDGE_COMPUTING = "edge_computing"
    IOT = "iot"
    CUSTOM = "custom"

class ContextAdaptationType(Enum):
    """Enumeration of context adaptation types."""
    TERMINOLOGY = "terminology"
    VISUALIZATION = "visualization"
    WORKFLOW = "workflow"
    METRICS = "metrics"
    ALERTS = "alerts"
    ROLES = "roles"
    PERMISSIONS = "permissions"
    CUSTOM = "custom"

@dataclass
class IndustryContext:
    """Data class representing an industry context."""
    industry_type: IndustryType
    name: str
    description: str
    terminology_map: Dict[str, str]
    role_definitions: Dict[str, Dict[str, Any]]
    metric_definitions: Dict[str, Dict[str, Any]]
    visualization_preferences: Dict[str, Any]
    workflow_templates: Dict[str, Any]
    alert_thresholds: Dict[str, Any]
    metadata: Dict[str, Any]

class IndustrialContextAdapter:
    """
    Provides industry-specific context adaptation capabilities for the Industriverse UI/UX Layer.
    
    This class provides:
    - Industry-specific terminology adaptation
    - Role-based view customization
    - Industry-specific visualization preferences
    - Workflow template adaptation
    - Metric and alert threshold customization
    - Integration with the Universal Skin and Capsule Framework
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Industrial Context Adapter.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.is_active = False
        self.industry_contexts: Dict[str, IndustryContext] = {}
        self.active_context_id: Optional[str] = None
        self.context_listeners: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}
        self.event_listeners: List[Callable[[Dict[str, Any]], None]] = []
        self.logger = logging.getLogger(__name__)
        
        # Load industry contexts from config
        self._load_industry_contexts_from_config()
        
    def start(self) -> bool:
        """
        Start the Industrial Context Adapter.
        
        Returns:
            True if the adapter was started, False if already active
        """
        if self.is_active:
            return False
            
        self.is_active = True
        
        # Dispatch event
        self._dispatch_event({
            "event_type": "industrial_context_adapter_started"
        })
        
        self.logger.info("Industrial Context Adapter started.")
        return True
    
    def stop(self) -> bool:
        """
        Stop the Industrial Context Adapter.
        
        Returns:
            True if the adapter was stopped, False if not active
        """
        if not self.is_active:
            return False
            
        self.is_active = False
        
        # Dispatch event
        self._dispatch_event({
            "event_type": "industrial_context_adapter_stopped"
        })
        
        self.logger.info("Industrial Context Adapter stopped.")
        return True
    
    def register_industry_context(self,
                                context_id: str,
                                industry_type: IndustryType,
                                name: str,
                                description: str,
                                terminology_map: Dict[str, str],
                                role_definitions: Dict[str, Dict[str, Any]],
                                metric_definitions: Dict[str, Dict[str, Any]],
                                visualization_preferences: Dict[str, Any],
                                workflow_templates: Dict[str, Any],
                                alert_thresholds: Dict[str, Any],
                                metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        Register a new industry context.
        
        Args:
            context_id: Unique identifier for this context
            industry_type: Type of industry
            name: Human-readable name
            description: Context description
            terminology_map: Mapping of generic terms to industry-specific terms
            role_definitions: Definitions of industry-specific roles
            metric_definitions: Definitions of industry-specific metrics
            visualization_preferences: Industry-specific visualization preferences
            workflow_templates: Industry-specific workflow templates
            alert_thresholds: Industry-specific alert thresholds
            metadata: Additional metadata for this context
            
        Returns:
            True if the context was registered, False if already exists
        """
        if context_id in self.industry_contexts:
            self.logger.warning(f"Industry context {context_id} already exists.")
            return False
            
        context = IndustryContext(
            industry_type=industry_type,
            name=name,
            description=description,
            terminology_map=terminology_map,
            role_definitions=role_definitions,
            metric_definitions=metric_definitions,
            visualization_preferences=visualization_preferences,
            workflow_templates=workflow_templates,
            alert_thresholds=alert_thresholds,
            metadata=metadata or {}
        )
        
        self.industry_contexts[context_id] = context
        self.context_listeners[context_id] = []
        
        # Dispatch event
        self._dispatch_event({
            "event_type": "industry_context_registered",
            "context_id": context_id,
            "industry_type": industry_type.value,
            "name": name
        })
        
        self.logger.debug(f"Registered industry context: {context_id} ({name})")
        return True
    
    def unregister_industry_context(self, context_id: str) -> bool:
        """
        Unregister an industry context.
        
        Args:
            context_id: ID of the context to unregister
            
        Returns:
            True if the context was unregistered, False if not found
        """
        if context_id not in self.industry_contexts:
            return False
            
        # If this is the active context, deactivate it first
        if self.active_context_id == context_id:
            self.deactivate_context()
            
        # Remove context
        del self.industry_contexts[context_id]
        
        # Remove context listeners
        if context_id in self.context_listeners:
            del self.context_listeners[context_id]
            
        # Dispatch event
        self._dispatch_event({
            "event_type": "industry_context_unregistered",
            "context_id": context_id
        })
        
        self.logger.debug(f"Unregistered industry context: {context_id}")
        return True
    
    def activate_context(self, context_id: str) -> bool:
        """
        Activate an industry context.
        
        Args:
            context_id: ID of the context to activate
            
        Returns:
            True if the context was activated, False if not found
        """
        if context_id not in self.industry_contexts:
            self.logger.warning(f"Industry context {context_id} not found.")
            return False
            
        # Deactivate current context if any
        if self.active_context_id is not None:
            self.deactivate_context()
            
        self.active_context_id = context_id
        context = self.industry_contexts[context_id]
        
        # Dispatch event
        self._dispatch_event({
            "event_type": "industry_context_activated",
            "context_id": context_id,
            "industry_type": context.industry_type.value,
            "name": context.name
        })
        
        # Notify context listeners
        context_event = {
            "event_type": "industry_context_activated",
            "context_id": context_id,
            "industry_type": context.industry_type.value,
            "name": context.name,
            "timestamp": time.time()
        }
        
        for listener in self.context_listeners[context_id]:
            try:
                listener(context_event)
            except Exception as e:
                self.logger.error(f"Error in context listener for {context_id}: {e}")
                
        self.logger.debug(f"Activated industry context: {context_id} ({context.name})")
        return True
    
    def deactivate_context(self) -> bool:
        """
        Deactivate the current industry context.
        
        Returns:
            True if a context was deactivated, False if no active context
        """
        if self.active_context_id is None:
            return False
            
        context_id = self.active_context_id
        context = self.industry_contexts[context_id]
        
        self.active_context_id = None
        
        # Dispatch event
        self._dispatch_event({
            "event_type": "industry_context_deactivated",
            "context_id": context_id,
            "industry_type": context.industry_type.value,
            "name": context.name
        })
        
        # Notify context listeners
        context_event = {
            "event_type": "industry_context_deactivated",
            "context_id": context_id,
            "industry_type": context.industry_type.value,
            "name": context.name,
            "timestamp": time.time()
        }
        
        for listener in self.context_listeners[context_id]:
            try:
                listener(context_event)
            except Exception as e:
                self.logger.error(f"Error in context listener for {context_id}: {e}")
                
        self.logger.debug(f"Deactivated industry context: {context_id} ({context.name})")
        return True
    
    def get_active_context(self) -> Optional[IndustryContext]:
        """
        Get the currently active industry context.
        
        Returns:
            The active industry context, or None if no active context
        """
        if self.active_context_id is None:
            return None
            
        return self.industry_contexts[self.active_context_id]
    
    def get_industry_context(self, context_id: str) -> Optional[IndustryContext]:
        """
        Get an industry context by ID.
        
        Args:
            context_id: ID of the context to get
            
        Returns:
            The industry context, or None if not found
        """
        if context_id not in self.industry_contexts:
            return None
            
        return self.industry_contexts[context_id]
    
    def get_all_industry_contexts(self) -> Dict[str, IndustryContext]:
        """
        Get all registered industry contexts.
        
        Returns:
            Map of context ID to industry context
        """
        return self.industry_contexts
    
    def adapt_terminology(self, generic_term: str) -> str:
        """
        Adapt a generic term to the industry-specific terminology.
        
        Args:
            generic_term: The generic term to adapt
            
        Returns:
            The industry-specific term, or the original term if no adaptation available
        """
        if self.active_context_id is None:
            return generic_term
            
        context = self.industry_contexts[self.active_context_id]
        return context.terminology_map.get(generic_term, generic_term)
    
    def get_role_definition(self, role_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an industry-specific role definition.
        
        Args:
            role_id: ID of the role to get
            
        Returns:
            The role definition, or None if not found or no active context
        """
        if self.active_context_id is None:
            return None
            
        context = self.industry_contexts[self.active_context_id]
        return context.role_definitions.get(role_id)
    
    def get_metric_definition(self, metric_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an industry-specific metric definition.
        
        Args:
            metric_id: ID of the metric to get
            
        Returns:
            The metric definition, or None if not found or no active context
        """
        if self.active_context_id is None:
            return None
            
        context = self.industry_contexts[self.active_context_id]
        return context.metric_definitions.get(metric_id)
    
    def get_visualization_preferences(self) -> Dict[str, Any]:
        """
        Get industry-specific visualization preferences.
        
        Returns:
            The visualization preferences, or an empty dict if no active context
        """
        if self.active_context_id is None:
            return {}
            
        context = self.industry_contexts[self.active_context_id]
        return context.visualization_preferences
    
    def get_workflow_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """
        Get an industry-specific workflow template.
        
        Args:
            template_id: ID of the template to get
            
        Returns:
            The workflow template, or None if not found or no active context
        """
        if self.active_context_id is None:
            return None
            
        context = self.industry_contexts[self.active_context_id]
        return context.workflow_templates.get(template_id)
    
    def get_alert_threshold(self, alert_id: str) -> Optional[Any]:
        """
        Get an industry-specific alert threshold.
        
        Args:
            alert_id: ID of the alert threshold to get
            
        Returns:
            The alert threshold, or None if not found or no active context
        """
        if self.active_context_id is None:
            return None
            
        context = self.industry_contexts[self.active_context_id]
        return context.alert_thresholds.get(alert_id)
    
    def add_context_listener(self, context_id: str, listener: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Add a listener for a specific industry context.
        
        Args:
            context_id: ID of the context
            listener: Callback function that will be called when the context is activated or deactivated
            
        Returns:
            True if the listener was added, False if context not found
        """
        if context_id not in self.industry_contexts:
            self.logger.warning(f"Industry context {context_id} not found.")
            return False
            
        self.context_listeners[context_id].append(listener)
        return True
    
    def add_event_listener(self, listener: Callable[[Dict[str, Any]], None]) -> None:
        """
        Add a listener for all industrial context adapter events.
        
        Args:
            listener: Callback function that will be called with event data
        """
        self.event_listeners.append(listener)
        
    def remove_event_listener(self, listener: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Remove an event listener.
        
        Args:
            listener: The listener to remove
            
        Returns:
            True if the listener was removed, False if not found
        """
        if listener in self.event_listeners:
            self.event_listeners.remove(listener)
            return True
            
        return False
    
    def _dispatch_event(self, event_data: Dict[str, Any]) -> None:
        """
        Dispatch an event to all listeners.
        
        Args:
            event_data: The event data to dispatch
        """
        # Add source if not present
        if "source" not in event_data:
            event_data["source"] = "IndustrialContextAdapter"
            
        # Add timestamp if not present
        if "timestamp" not in event_data:
            event_data["timestamp"] = time.time()
            
        # Dispatch to global event listeners
        for listener in self.event_listeners:
            try:
                listener(event_data)
            except Exception as e:
                self.logger.error(f"Error in industrial context event listener: {e}")
                
    def _load_industry_contexts_from_config(self) -> None:
        """Load industry contexts from the configuration."""
        contexts_config = self.config.get("industry_contexts", [])
        
        for context_config in contexts_config:
            try:
                context_id = context_config["context_id"]
                industry_type = IndustryType(context_config["industry_type"])
                name = context_config["name"]
                description = context_config["description"]
                terminology_map = context_config["terminology_map"]
                role_definitions = context_config["role_definitions"]
                metric_definitions = context_config["metric_definitions"]
                visualization_preferences = context_config["visualization_preferences"]
                workflow_templates = context_config["workflow_templates"]
                alert_thresholds = context_config["alert_thresholds"]
                metadata = context_config.get("metadata")
                
                self.register_industry_context(
                    context_id=context_id,
                    industry_type=industry_type,
                    name=name,
                    description=description,
                    terminology_map=terminology_map,
                    role_definitions=role_definitions,
                    metric_definitions=metric_definitions,
                    visualization_preferences=visualization_preferences,
                    workflow_templates=workflow_templates,
                    alert_thresholds=alert_thresholds,
                    metadata=metadata
                )
                
            except (KeyError, ValueError) as e:
                self.logger.warning(f"Error loading industry context from config: {e}")

# Example Usage
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Create industrial context adapter
    adapter_config = {
        "industry_contexts": [
            {
                "context_id": "manufacturing",
                "industry_type": "manufacturing",
                "name": "Precision Manufacturing",
                "description": "Context for precision manufacturing environments",
                "terminology_map": {
                    "user": "operator",
                    "process": "production line",
                    "data": "telemetry",
                    "alert": "production alert",
                    "task": "work order"
                },
                "role_definitions": {
                    "line_operator": {
                        "name": "Line Operator",
                        "description": "Operates production line equipment",
                        "permissions": ["view_telemetry", "acknowledge_alerts", "update_status"]
                    },
                    "production_manager": {
                        "name": "Production Manager",
                        "description": "Manages production lines and schedules",
                        "permissions": ["view_all", "manage_schedules", "approve_changes"]
                    },
                    "quality_inspector": {
                        "name": "Quality Inspector",
                        "description": "Inspects product quality and compliance",
                        "permissions": ["view_quality_data", "flag_issues", "approve_quality"]
                    }
                },
                "metric_definitions": {
                    "oee": {
                        "name": "Overall Equipment Effectiveness",
                        "description": "Measure of manufacturing productivity",
                        "unit": "percentage",
                        "thresholds": {
                            "low": 60,
                            "medium": 75,
                            "high": 85
                        }
                    },
                    "cycle_time": {
                        "name": "Cycle Time",
                        "description": "Time to complete one production cycle",
                        "unit": "seconds",
                        "thresholds": {
                            "optimal": 120,
                            "warning": 150,
                            "critical": 180
                        }
                    }
                },
                "visualization_preferences": {
                    "color_scheme": "industrial",
                    "default_view": "production_floor",
                    "chart_types": {
                        "productivity": "gauge",
                        "quality": "bar",
                        "maintenance": "timeline"
                    }
                },
                "workflow_templates": {
                    "quality_inspection": {
                        "name": "Quality Inspection Workflow",
                        "description": "Standard workflow for quality inspection",
                        "steps": [
                            {"id": "sample", "name": "Collect Sample", "role": "line_operator"},
                            {"id": "measure", "name": "Measure Parameters", "role": "quality_inspector"},
                            {"id": "analyze", "name": "Analyze Results", "role": "quality_inspector"},
                            {"id": "approve", "name": "Approve or Reject", "role": "quality_inspector"},
                            {"id": "document", "name": "Document Findings", "role": "quality_inspector"}
                        ]
                    },
                    "maintenance": {
                        "name": "Preventive Maintenance Workflow",
                        "description": "Standard workflow for preventive maintenance",
                        "steps": [
                            {"id": "schedule", "name": "Schedule Maintenance", "role": "production_manager"},
                            {"id": "prepare", "name": "Prepare Equipment", "role": "line_operator"},
                            {"id": "inspect", "name": "Inspect Components", "role": "maintenance_technician"},
                            {"id": "service", "name": "Service Components", "role": "maintenance_technician"},
                            {"id": "test", "name": "Test Operation", "role": "maintenance_technician"},
                            {"id": "document", "name": "Document Maintenance", "role": "maintenance_technician"}
                        ]
                    }
                },
                "alert_thresholds": {
                    "temperature": {
                        "warning": 80,
                        "critical": 90
                    },
                    "pressure": {
                        "warning": 120,
                        "critical": 150
                    },
                    "vibration": {
                        "warning": 5,
                        "critical": 8
                    }
                },
                "metadata": {
                    "version": "1.0",
                    "last_updated": "2025-05-01"
                }
            },
            {
                "context_id": "logistics",
                "industry_type": "logistics",
                "name": "Supply Chain Logistics",
                "description": "Context for supply chain and logistics environments",
                "terminology_map": {
                    "user": "logistics coordinator",
                    "process": "shipment",
                    "data": "tracking data",
                    "alert": "logistics alert",
                    "task": "delivery order"
                },
                "role_definitions": {
                    "logistics_coordinator": {
                        "name": "Logistics Coordinator",
                        "description": "Coordinates shipments and deliveries",
                        "permissions": ["view_shipments", "update_status", "create_orders"]
                    },
                    "warehouse_manager": {
                        "name": "Warehouse Manager",
                        "description": "Manages warehouse operations and inventory",
                        "permissions": ["view_all", "manage_inventory", "approve_shipments"]
                    },
                    "delivery_driver": {
                        "name": "Delivery Driver",
                        "description": "Delivers shipments to customers",
                        "permissions": ["view_assigned_deliveries", "update_delivery_status"]
                    }
                },
                "metric_definitions": {
                    "on_time_delivery": {
                        "name": "On-Time Delivery Rate",
                        "description": "Percentage of deliveries made on time",
                        "unit": "percentage",
                        "thresholds": {
                            "low": 80,
                            "medium": 90,
                            "high": 95
                        }
                    },
                    "inventory_turnover": {
                        "name": "Inventory Turnover",
                        "description": "Rate at which inventory is sold and replaced",
                        "unit": "ratio",
                        "thresholds": {
                            "low": 4,
                            "medium": 6,
                            "high": 8
                        }
                    }
                },
                "visualization_preferences": {
                    "color_scheme": "logistics",
                    "default_view": "map",
                    "chart_types": {
                        "delivery_performance": "line",
                        "inventory_levels": "bar",
                        "route_efficiency": "map"
                    }
                },
                "workflow_templates": {
                    "order_fulfillment": {
                        "name": "Order Fulfillment Workflow",
                        "description": "Standard workflow for order fulfillment",
                        "steps": [
                            {"id": "receive", "name": "Receive Order", "role": "logistics_coordinator"},
                            {"id": "pick", "name": "Pick Items", "role": "warehouse_staff"},
                            {"id": "pack", "name": "Pack Order", "role": "warehouse_staff"},
                            {"id": "ship", "name": "Ship Order", "role": "logistics_coordinator"},
                            {"id": "deliver", "name": "Deliver Order", "role": "delivery_driver"},
                            {"id": "confirm", "name": "Confirm Delivery", "role": "delivery_driver"}
                        ]
                    },
                    "returns_processing": {
                        "name": "Returns Processing Workflow",
                        "description": "Standard workflow for processing returns",
                        "steps": [
                            {"id": "receive_return", "name": "Receive Return", "role": "warehouse_staff"},
                            {"id": "inspect", "name": "Inspect Items", "role": "quality_inspector"},
                            {"id": "process", "name": "Process Return", "role": "logistics_coordinator"},
                            {"id": "restock", "name": "Restock or Dispose", "role": "warehouse_staff"},
                            {"id": "refund", "name": "Process Refund", "role": "accounting_staff"}
                        ]
                    }
                },
                "alert_thresholds": {
                    "delivery_delay": {
                        "warning": 30,
                        "critical": 60
                    },
                    "inventory_level": {
                        "warning": 20,
                        "critical": 10
                    },
                    "route_deviation": {
                        "warning": 5,
                        "critical": 10
                    }
                },
                "metadata": {
                    "version": "1.0",
                    "last_updated": "2025-05-01"
                }
            }
        ]
    }
    
    context_adapter = IndustrialContextAdapter(config=adapter_config)
    
    # Start the adapter
    context_adapter.start()
    
    # Add an event listener
    def on_event(event):
        print(f"Event: {event['event_type']}")
        
    context_adapter.add_event_listener(on_event)
    
    # Activate the manufacturing context
    context_adapter.activate_context("manufacturing")
    
    # Get adapted terminology
    print(f"Generic: user, Adapted: {context_adapter.adapt_terminology('user')}")
    print(f"Generic: process, Adapted: {context_adapter.adapt_terminology('process')}")
    
    # Get role definition
    line_operator = context_adapter.get_role_definition("line_operator")
    print(f"Line Operator Role: {line_operator['name']} - {line_operator['description']}")
    
    # Get metric definition
    oee = context_adapter.get_metric_definition("oee")
    print(f"OEE Metric: {oee['name']} ({oee['unit']})")
    
    # Switch to logistics context
    context_adapter.activate_context("logistics")
    
    # Get adapted terminology in new context
    print(f"Generic: user, Adapted: {context_adapter.adapt_terminology('user')}")
    print(f"Generic: process, Adapted: {context_adapter.adapt_terminology('process')}")
    
    # Stop the adapter
    context_adapter.stop()
"""
