"""
Rendering Engine - Core rendering system for the Universal Skin UI/UX Layer

This module implements the core rendering functionality for the Universal Skin UI/UX Layer,
providing adaptive, context-aware rendering across different devices and modalities.
It serves as the visual foundation for the Ambient Intelligence experience.
"""

import logging
import json
from typing import Dict, List, Any, Optional, Callable, Tuple

# Initialize logger
logger = logging.getLogger(__name__)

class RenderingEngine:
    """
    Core rendering system for the Universal Skin UI/UX Layer.
    """
    
    # Rendering mode constants
    MODE_STANDARD = "standard"
    MODE_HIGH_PERFORMANCE = "high_performance"
    MODE_HIGH_FIDELITY = "high_fidelity"
    MODE_ACCESSIBILITY = "accessibility"
    MODE_LOW_POWER = "low_power"
    MODE_AMBIENT = "ambient"
    
    # Rendering target constants
    TARGET_WEB = "web"
    TARGET_NATIVE = "native"
    TARGET_MOBILE = "mobile"
    TARGET_DESKTOP = "desktop"
    TARGET_AR = "ar"
    TARGET_VR = "vr"
    TARGET_EDGE = "edge"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Rendering Engine with optional configuration."""
        self.config = config or {}
        self.renderers = {}
        self.render_targets = {}
        self.render_pipelines = {}
        self.render_cache = {}
        self.theme_manager = None
        self.animation_manager = None
        self.layout_manager = None
        self.accessibility_manager = None
        self.event_subscribers = {}
        self.current_mode = self.config.get('default_mode', self.MODE_STANDARD)
        self.current_target = self.config.get('default_target', self.TARGET_WEB)
        
        logger.info("Rendering Engine initialized with config: %s", self.config)
    
    def initialize(self):
        """Initialize the Rendering Engine and all its components."""
        logger.info("Initializing Rendering Engine components")
        
        # Import dependencies here to avoid circular imports
        from .theme_manager import ThemeManager
        from .animation_manager import AnimationManager
        from .layout_manager import LayoutManager
        from .accessibility_manager import AccessibilityManager
        from .render_pipeline_manager import RenderPipelineManager
        from .render_cache_manager import RenderCacheManager
        
        # Initialize components
        self.theme_manager = ThemeManager(self.config.get('theme_manager', {}))
        self.animation_manager = AnimationManager(self.config.get('animation_manager', {}))
        self.layout_manager = LayoutManager(self.config.get('layout_manager', {}))
        self.accessibility_manager = AccessibilityManager(self.config.get('accessibility_manager', {}))
        self.pipeline_manager = RenderPipelineManager(self.config.get('pipeline_manager', {}))
        self.cache_manager = RenderCacheManager(self.config.get('cache_manager', {}))
        
        # Initialize each component
        self.theme_manager.initialize()
        self.animation_manager.initialize()
        self.layout_manager.initialize()
        self.accessibility_manager.initialize()
        self.pipeline_manager.initialize()
        self.cache_manager.initialize()
        
        # Register default renderers
        self._register_default_renderers()
        
        # Register default render targets
        self._register_default_render_targets()
        
        # Register default render pipelines
        self._register_default_render_pipelines()
        
        logger.info("Rendering Engine initialization complete")
        return True
    
    def _register_default_renderers(self):
        """Register default renderers."""
        from .renderers.web_renderer import WebRenderer
        from .renderers.canvas_renderer import CanvasRenderer
        from .renderers.svg_renderer import SVGRenderer
        from .renderers.webgl_renderer import WebGLRenderer
        from .renderers.native_renderer import NativeRenderer
        from .renderers.ar_renderer import ARRenderer
        
        # Create and register renderers
        self.register_renderer('web', WebRenderer(self.config.get('web_renderer', {})))
        self.register_renderer('canvas', CanvasRenderer(self.config.get('canvas_renderer', {})))
        self.register_renderer('svg', SVGRenderer(self.config.get('svg_renderer', {})))
        self.register_renderer('webgl', WebGLRenderer(self.config.get('webgl_renderer', {})))
        self.register_renderer('native', NativeRenderer(self.config.get('native_renderer', {})))
        self.register_renderer('ar', ARRenderer(self.config.get('ar_renderer', {})))
        
        logger.info("Registered default renderers")
    
    def _register_default_render_targets(self):
        """Register default render targets."""
        # Web targets
        self.register_render_target(self.TARGET_WEB, {
            'renderer': 'web',
            'resolution': (1920, 1080),
            'pixel_ratio': 1.0,
            'color_space': 'srgb',
            'capabilities': ['dom', 'css', 'canvas', 'webgl', 'svg']
        })
        
        # Native targets
        self.register_render_target(self.TARGET_NATIVE, {
            'renderer': 'native',
            'resolution': (1920, 1080),
            'pixel_ratio': 1.0,
            'color_space': 'srgb',
            'capabilities': ['native_ui', 'hardware_acceleration', 'system_integration']
        })
        
        # Mobile targets
        self.register_render_target(self.TARGET_MOBILE, {
            'renderer': 'web',
            'resolution': (750, 1334),
            'pixel_ratio': 2.0,
            'color_space': 'srgb',
            'capabilities': ['touch', 'responsive', 'low_power']
        })
        
        # Desktop targets
        self.register_render_target(self.TARGET_DESKTOP, {
            'renderer': 'web',
            'resolution': (2560, 1440),
            'pixel_ratio': 1.5,
            'color_space': 'srgb',
            'capabilities': ['high_performance', 'multi_window', 'system_integration']
        })
        
        # AR targets
        self.register_render_target(self.TARGET_AR, {
            'renderer': 'ar',
            'resolution': (1920, 1080),
            'pixel_ratio': 2.0,
            'color_space': 'srgb',
            'capabilities': ['spatial', 'transparent', 'world_anchors', 'gesture']
        })
        
        # VR targets
        self.register_render_target(self.TARGET_VR, {
            'renderer': 'webgl',
            'resolution': (2880, 1600),
            'pixel_ratio': 1.0,
            'color_space': 'srgb',
            'capabilities': ['spatial', 'immersive', 'controllers']
        })
        
        # Edge targets
        self.register_render_target(self.TARGET_EDGE, {
            'renderer': 'canvas',
            'resolution': (800, 480),
            'pixel_ratio': 1.0,
            'color_space': 'srgb',
            'capabilities': ['low_power', 'minimal_ui', 'offline']
        })
        
        logger.info("Registered default render targets")
    
    def _register_default_render_pipelines(self):
        """Register default render pipelines."""
        # Standard pipeline
        self.register_render_pipeline(self.MODE_STANDARD, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'accessibility', 'processor': 'accessibility_processor'},
                {'name': 'render', 'processor': 'render_processor'},
                {'name': 'animation', 'processor': 'animation_processor'},
                {'name': 'post_process', 'processor': 'post_processor'}
            ],
            'cache_strategy': 'standard',
            'optimization_level': 'balanced'
        })
        
        # High performance pipeline
        self.register_render_pipeline(self.MODE_HIGH_PERFORMANCE, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'render', 'processor': 'render_processor'},
                {'name': 'animation', 'processor': 'animation_processor'}
            ],
            'cache_strategy': 'aggressive',
            'optimization_level': 'performance'
        })
        
        # High fidelity pipeline
        self.register_render_pipeline(self.MODE_HIGH_FIDELITY, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'accessibility', 'processor': 'accessibility_processor'},
                {'name': 'render', 'processor': 'render_processor'},
                {'name': 'animation', 'processor': 'animation_processor'},
                {'name': 'post_process', 'processor': 'post_processor'},
                {'name': 'effects', 'processor': 'effects_processor'}
            ],
            'cache_strategy': 'minimal',
            'optimization_level': 'quality'
        })
        
        # Accessibility pipeline
        self.register_render_pipeline(self.MODE_ACCESSIBILITY, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'accessibility', 'processor': 'accessibility_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'render', 'processor': 'render_processor'},
                {'name': 'animation', 'processor': 'animation_processor'}
            ],
            'cache_strategy': 'standard',
            'optimization_level': 'balanced'
        })
        
        # Low power pipeline
        self.register_render_pipeline(self.MODE_LOW_POWER, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'render', 'processor': 'render_processor'}
            ],
            'cache_strategy': 'aggressive',
            'optimization_level': 'performance'
        })
        
        # Ambient pipeline
        self.register_render_pipeline(self.MODE_AMBIENT, {
            'stages': [
                {'name': 'layout', 'processor': 'layout_processor'},
                {'name': 'theme', 'processor': 'theme_processor'},
                {'name': 'render', 'processor': 'render_processor'},
                {'name': 'animation', 'processor': 'animation_processor'},
                {'name': 'ambient', 'processor': 'ambient_processor'}
            ],
            'cache_strategy': 'standard',
            'optimization_level': 'balanced'
        })
        
        logger.info("Registered default render pipelines")
    
    def register_renderer(self, renderer_id: str, renderer: Any) -> bool:
        """
        Register a renderer.
        
        Args:
            renderer_id: Unique identifier for the renderer
            renderer: Renderer instance
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        logger.info("Registering renderer: %s", renderer_id)
        
        if renderer_id in self.renderers:
            logger.warning("Renderer already registered: %s", renderer_id)
            return False
        
        self.renderers[renderer_id] = renderer
        return True
    
    def unregister_renderer(self, renderer_id: str) -> bool:
        """
        Unregister a renderer.
        
        Args:
            renderer_id: Unique identifier for the renderer
        
        Returns:
            bool: True if unregistration was successful, False otherwise
        """
        logger.info("Unregistering renderer: %s", renderer_id)
        
        if renderer_id not in self.renderers:
            logger.warning("Renderer not found: %s", renderer_id)
            return False
        
        del self.renderers[renderer_id]
        return True
    
    def register_render_target(self, target_id: str, target_config: Dict[str, Any]) -> bool:
        """
        Register a render target.
        
        Args:
            target_id: Unique identifier for the render target
            target_config: Configuration for the render target
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        logger.info("Registering render target: %s", target_id)
        
        if target_id in self.render_targets:
            logger.warning("Render target already registered: %s", target_id)
            return False
        
        self.render_targets[target_id] = target_config
        return True
    
    def unregister_render_target(self, target_id: str) -> bool:
        """
        Unregister a render target.
        
        Args:
            target_id: Unique identifier for the render target
        
        Returns:
            bool: True if unregistration was successful, False otherwise
        """
        logger.info("Unregistering render target: %s", target_id)
        
        if target_id not in self.render_targets:
            logger.warning("Render target not found: %s", target_id)
            return False
        
        del self.render_targets[target_id]
        return True
    
    def register_render_pipeline(self, pipeline_id: str, pipeline_config: Dict[str, Any]) -> bool:
        """
        Register a render pipeline.
        
        Args:
            pipeline_id: Unique identifier for the render pipeline
            pipeline_config: Configuration for the render pipeline
        
        Returns:
            bool: True if registration was successful, False otherwise
        """
        logger.info("Registering render pipeline: %s", pipeline_id)
        
        if pipeline_id in self.render_pipelines:
            logger.warning("Render pipeline already registered: %s", pipeline_id)
            return False
        
        # Register with pipeline manager if available
        if self.pipeline_manager:
            return self.pipeline_manager.register_pipeline(pipeline_id, pipeline_config)
        
        # Simple pipeline storage if pipeline manager not available
        self.render_pipelines[pipeline_id] = pipeline_config
        return True
    
    def unregister_render_pipeline(self, pipeline_id: str) -> bool:
        """
        Unregister a render pipeline.
        
        Args:
            pipeline_id: Unique identifier for the render pipeline
        
        Returns:
            bool: True if unregistration was successful, False otherwise
        """
        logger.info("Unregistering render pipeline: %s", pipeline_id)
        
        # Unregister from pipeline manager if available
        if self.pipeline_manager:
            return self.pipeline_manager.unregister_pipeline(pipeline_id)
        
        # Simple pipeline removal if pipeline manager not available
        if pipeline_id not in self.render_pipelines:
            logger.warning("Render pipeline not found: %s", pipeline_id)
            return False
        
        del self.render_pipelines[pipeline_id]
        return True
    
    def set_render_mode(self, mode: str) -> bool:
        """
        Set the current rendering mode.
        
        Args:
            mode: Rendering mode to set
        
        Returns:
            bool: True if mode was set successfully, False otherwise
        """
        logger.info("Setting render mode: %s", mode)
        
        if mode not in self.render_pipelines and not self.pipeline_manager:
            logger.warning("Render pipeline not found for mode: %s", mode)
            return False
        
        # Check if pipeline exists in pipeline manager
        if self.pipeline_manager and not self.pipeline_manager.has_pipeline(mode):
            logger.warning("Render pipeline not found for mode: %s", mode)
            return False
        
        self.current_mode = mode
        
        # Notify subscribers
        self._notify_subscribers('mode_changed', {
            'mode': mode
        })
        
        logger.info("Render mode set to: %s", mode)
        return True
    
    def set_render_target(self, target: str) -> bool:
        """
        Set the current rendering target.
        
        Args:
            target: Rendering target to set
        
        Returns:
            bool: True if target was set successfully, False otherwise
        """
        logger.info("Setting render target: %s", target)
        
        if target not in self.render_targets:
            logger.warning("Render target not found: %s", target)
            return False
        
        self.current_target = target
        
        # Notify subscribers
        self._notify_subscribers('target_changed', {
            'target': target
        })
        
        logger.info("Render target set to: %s", target)
        return True
    
    def render(self, scene_graph: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Any:
        """
        Render a scene graph using the current mode and target.
        
        Args:
            scene_graph: Scene graph to render
            context: Optional rendering context
        
        Returns:
            Any: Rendered output
        """
        logger.debug("Rendering scene graph with mode %s and target %s", 
                    self.current_mode, self.current_target)
        
        # Get render target configuration
        target_config = self.render_targets.get(self.current_target)
        if not target_config:
            logger.error("Render target not found: %s", self.current_target)
            return None
        
        # Get renderer
        renderer_id = target_config.get('renderer')
        renderer = self.renderers.get(renderer_id)
        if not renderer:
            logger.error("Renderer not found: %s", renderer_id)
            return None
        
        # Create rendering context if not provided
        if not context:
            context = {}
        
        # Add target configuration to context
        context['target'] = target_config
        
        # Add theme to context
        if self.theme_manager:
            current_theme = self.theme_manager.get_current_theme()
            context['theme'] = current_theme
        
        # Add accessibility settings to context
        if self.accessibility_manager:
            accessibility_settings = self.accessibility_manager.get_settings()
            context['accessibility'] = accessibility_settings
        
        # Check cache
        cache_key = self._generate_cache_key(scene_graph, context)
        cached_result = self._check_cache(cache_key)
        if cached_result:
            logger.debug("Using cached render result")
            return cached_result
        
        # Process scene graph through pipeline
        processed_scene_graph = self._process_pipeline(scene_graph, context)
        if not processed_scene_graph:
            logger.error("Pipeline processing failed")
            return None
        
        try:
            # Render processed scene graph
            result = renderer.render(processed_scene_graph, context)
            
            # Cache result
            self._cache_result(cache_key, result)
            
            # Notify subscribers
            self._notify_subscribers('render_completed', {
                'scene_graph_id': scene_graph.get('id'),
                'mode': self.current_mode,
                'target': self.current_target
            })
            
            return result
        
        except Exception as e:
            logger.error("Error rendering scene graph: %s", e)
            return None
    
    def _process_pipeline(self, scene_graph: Dict[str, Any], context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Process a scene graph through the current pipeline.
        
        Args:
            scene_graph: Scene graph to process
            context: Rendering context
        
        Returns:
            Optional[Dict[str, Any]]: Processed scene graph or None if processing failed
        """
        # Use pipeline manager if available
        if self.pipeline_manager:
            return self.pipeline_manager.process(self.current_mode, scene_graph, context)
        
        # Simple pipeline processing if pipeline manager not available
        pipeline_config = self.render_pipelines.get(self.current_mode)
        if not pipeline_config:
            logger.error("Render pipeline not found for mode: %s", self.current_mode)
            return None
        
        # Process each stage in the pipeline
        current_scene_graph = scene_graph
        
        for stage in pipeline_config.get('stages', []):
            stage_name = stage.get('name')
            processor_name = stage.get('processor')
            
            logger.debug("Processing pipeline stage: %s with processor %s", 
                        stage_name, processor_name)
            
            # Apply layout processing
            if stage_name == 'layout' and self.layout_manager:
                current_scene_graph = self.layout_manager.process(current_scene_graph, context)
            
            # Apply theme processing
            elif stage_name == 'theme' and self.theme_manager:
                current_scene_graph = self.theme_manager.process(current_scene_graph, context)
            
            # Apply accessibility processing
            elif stage_name == 'accessibility' and self.accessibility_manager:
                current_scene_graph = self.accessibility_manager.process(current_scene_graph, context)
            
            # Apply animation processing
            elif stage_name == 'animation' and self.animation_manager:
                current_scene_graph = self.animation_manager.process(current_scene_graph, context)
            
            # Skip other stages in simple processing
            
            if not current_scene_graph:
                logger.error("Pipeline stage %s failed", stage_name)
                return None
        
        return current_scene_graph
    
    def _generate_cache_key(self, scene_graph: Dict[str, Any], context: Dict[str, Any]) -> str:
        """
        Generate a cache key for a scene graph and context.
        
        Args:
            scene_graph: Scene graph
            context: Rendering context
        
        Returns:
            str: Cache key
        """
        # Use cache manager if available
        if self.cache_manager:
            return self.cache_manager.generate_key(scene_graph, context)
        
        # Simple cache key generation if cache manager not available
        import hashlib
        import json
        
        # Extract relevant parts of scene graph and context for caching
        cache_data = {
            'scene_graph_id': scene_graph.get('id'),
            'scene_graph_version': scene_graph.get('version'),
            'mode': self.current_mode,
            'target': self.current_target,
            'theme': context.get('theme', {}).get('id') if context.get('theme') else None,
            'accessibility': context.get('accessibility', {}).get('id') if context.get('accessibility') else None
        }
        
        # Generate hash
        cache_key = hashlib.md5(json.dumps(cache_data).encode()).hexdigest()
        return cache_key
    
    def _check_cache(self, cache_key: str) -> Optional[Any]:
        """
        Check if a render result is cached.
        
        Args:
            cache_key: Cache key
        
        Returns:
            Optional[Any]: Cached result or None if not found
        """
        # Use cache manager if available
        if self.cache_manager:
            return self.cache_manager.get(cache_key)
        
        # Simple cache lookup if cache manager not available
        return self.render_cache.get(cache_key)
    
    def _cache_result(self, cache_key: str, result: Any) -> bool:
        """
        Cache a render result.
        
        Args:
            cache_key: Cache key
            result: Render result
        
        Returns:
            bool: True if caching was successful, False otherwise
        """
        # Use cache manager if available
        if self.cache_manager:
            return self.cache_manager.set(cache_key, result)
        
        # Simple caching if cache manager not available
        self.render_cache[cache_key] = result
        
        # Limit cache size
        max_cache_size = self.config.get('max_cache_size', 100)
        if len(self.render_cache) > max_cache_size:
            # Remove oldest entries
            keys_to_remove = list(self.render_cache.keys())[:-max_cache_size]
            for key in keys_to_remove:
                del self.render_cache[key]
        
        return True
    
    def clear_cache(self) -> bool:
        """
        Clear the render cache.
        
        Returns:
            bool: True if cache was cleared successfully, False otherwise
        """
        # Use cache manager if available
        if self.cache_manager:
            return self.cache_manager.clear()
        
        # Simple cache clearing if cache manager not available
        self.render_cache.clear()
        return True
    
    def get_renderer(self, renderer_id: str) -> Optional[Any]:
        """
        Get a renderer by ID.
        
        Args:
            renderer_id: Unique identifier for the renderer
        
        Returns:
            Optional[Any]: Renderer instance or None if not found
        """
        return self.renderers.get(renderer_id)
    
    def get_render_target(self, target_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a render target by ID.
        
        Args:
            target_id: Unique identifier for the render target
        
        Returns:
            Optional[Dict[str, Any]]: Render target configuration or None if not found
        """
        return self.render_targets.get(target_id)
    
    def get_render_pipeline(self, pipeline_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a render pipeline by ID.
        
        Args:
            pipeline_id: Unique identifier for the render pipeline
        
        Returns:
            Optional[Dict[str, Any]]: Render pipeline configuration or None if not found
        """
        # Use pipeline manager if available
        if self.pipeline_manager:
            return self.pipeline_manager.get_pipeline(pipeline_id)
        
        # Simple pipeline lookup if pipeline manager not available
        return self.render_pipelines.get(pipeline_id)
    
    def get_current_mode(self) -> str:
        """
        Get the current rendering mode.
        
        Returns:
            str: Current rendering mode
        """
        return self.current_mode
    
    def get_current_target(self) -> str:
        """
        Get the current rendering target.
        
        Returns:
            str: Current rendering target
        """
        return self.current_target
    
    def get_theme_manager(self) -> Any:
        """
        Get the theme manager.
        
        Returns:
            Any: Theme manager instance
        """
        return self.theme_manager
    
    def get_animation_manager(self) -> Any:
        """
        Get the animation manager.
        
        Returns:
            Any: Animation manager instance
        """
        return self.animation_manager
    
    def get_layout_manager(self) -> Any:
        """
        Get the layout manager.
        
        Returns:
            Any: Layout manager instance
        """
        return self.layout_manager
    
    def get_accessibility_manager(self) -> Any:
        """
        Get the accessibility manager.
        
        Returns:
            Any: Accessibility manager instance
        """
        return self.accessibility_manager
    
    def subscribe_to_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to rendering events.
        
        Args:
            event_type: Type of event to subscribe to
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        if event_type not in self.event_subscribers:
            self.event_subscribers[event_type] = []
        
        self.event_subscribers[event_type].append(callback)
        return True
    
    def unsubscribe_from_events(self, event_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from rendering events.
        
        Args:
            event_type: Type of event to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        if event_type in self.event_subscribers and callback in self.event_subscribers[event_type]:
            self.event_subscribers[event_type].remove(callback)
            return True
        
        return False
    
    def _notify_subscribers(self, event_type: str, event_data: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            event_type: Type of event
            event_data: Event data
        """
        if event_type in self.event_subscribers:
            for callback in self.event_subscribers[event_type]:
                try:
                    callback(event_data)
                except Exception as e:
                    logger.error("Error in event subscriber callback: %s", e)
    
    def to_json(self) -> str:
        """
        Serialize rendering engine state to JSON.
        
        Returns:
            str: JSON string representation of rendering engine state
        """
        state = {
            'current_mode': self.current_mode,
            'current_target': self.current_target,
            'render_targets': self.render_targets,
            'render_pipelines': self.render_pipelines
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize rendering engine state from JSON.
        
        Args:
            json_str: JSON string representation of rendering engine state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        try:
            state = json.loads(json_str)
            
            self.current_mode = state.get('current_mode', self.MODE_STANDARD)
            self.current_target = state.get('current_target', self.TARGET_WEB)
            
            # Only update render targets and pipelines if not using managers
            if not hasattr(self, 'pipeline_manager') or not self.pipeline_manager:
                self.render_pipelines = state.get('render_pipelines', {})
            
            self.render_targets = state.get('render_targets', {})
            
            return True
        except Exception as e:
            logger.error("Error deserializing rendering engine state: %s", e)
            return False
