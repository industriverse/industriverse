"""
Real-Time Context Bus - Enables real-time communication and context sharing across layers

This module implements the core functionality for real-time context sharing and
communication between the UI/UX Layer and other layers of the Industrial Foundry
Framework. It serves as the central nervous system for ambient intelligence,
enabling seamless context propagation and state synchronization.
"""

import logging
import json
import asyncio
import threading
from typing import Dict, List, Any, Optional, Callable, Set

# Initialize logger
logger = logging.getLogger(__name__)

class RealTimeContextBus:
    """
    Enables real-time communication and context sharing across layers.
    """
    
    # Context type constants
    CONTEXT_TYPE_USER = "user"
    CONTEXT_TYPE_DEVICE = "device"
    CONTEXT_TYPE_ENVIRONMENT = "environment"
    CONTEXT_TYPE_WORKFLOW = "workflow"
    CONTEXT_TYPE_SYSTEM = "system"
    CONTEXT_TYPE_AGENT = "agent"
    CONTEXT_TYPE_CAPSULE = "capsule"
    CONTEXT_TYPE_LAYER = "layer"
    
    # Event type constants
    EVENT_TYPE_CONTEXT_UPDATED = "context_updated"
    EVENT_TYPE_STATE_CHANGED = "state_changed"
    EVENT_TYPE_COMMAND = "command"
    EVENT_TYPE_NOTIFICATION = "notification"
    EVENT_TYPE_REQUEST = "request"
    EVENT_TYPE_RESPONSE = "response"
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the Real-Time Context Bus with optional configuration."""
        self.config = config or {}
        self.context_store = {}
        self.subscribers = {}
        self.layer_connections = {}
        self.event_queue = asyncio.Queue()
        self.running = False
        self.event_loop = None
        self.event_thread = None
        self.protocol_bridge = None
        
        # Initialize context store with empty contexts for each type
        for context_type in [self.CONTEXT_TYPE_USER, self.CONTEXT_TYPE_DEVICE, 
                            self.CONTEXT_TYPE_ENVIRONMENT, self.CONTEXT_TYPE_WORKFLOW, 
                            self.CONTEXT_TYPE_SYSTEM, self.CONTEXT_TYPE_AGENT,
                            self.CONTEXT_TYPE_CAPSULE, self.CONTEXT_TYPE_LAYER]:
            self.context_store[context_type] = {}
        
        logger.info("Real-Time Context Bus initialized with config: %s", self.config)
    
    def initialize(self, protocol_bridge=None):
        """
        Initialize the Real-Time Context Bus and all its components.
        
        Args:
            protocol_bridge: Protocol Bridge instance for cross-layer communication
        """
        logger.info("Initializing Real-Time Context Bus components")
        
        self.protocol_bridge = protocol_bridge
        
        # Start event processing loop
        self._start_event_loop()
        
        # Connect to all layers
        self._connect_to_layers()
        
        logger.info("Real-Time Context Bus initialization complete")
        return True
    
    def _start_event_loop(self):
        """Start the event processing loop in a separate thread."""
        if self.running:
            logger.warning("Event loop already running")
            return
        
        self.running = True
        self.event_loop = asyncio.new_event_loop()
        self.event_thread = threading.Thread(target=self._run_event_loop, daemon=True)
        self.event_thread.start()
        
        logger.info("Event loop started")
    
    def _run_event_loop(self):
        """Run the event processing loop."""
        asyncio.set_event_loop(self.event_loop)
        self.event_loop.run_until_complete(self._process_events())
    
    async def _process_events(self):
        """Process events from the event queue."""
        while self.running:
            try:
                event = await self.event_queue.get()
                
                event_type = event.get('type')
                context_type = event.get('context_type')
                source = event.get('source')
                
                logger.debug("Processing event: %s from %s for context type %s", 
                            event_type, source, context_type)
                
                # Handle different event types
                if event_type == self.EVENT_TYPE_CONTEXT_UPDATED:
                    await self._handle_context_updated(event)
                elif event_type == self.EVENT_TYPE_STATE_CHANGED:
                    await self._handle_state_changed(event)
                elif event_type == self.EVENT_TYPE_COMMAND:
                    await self._handle_command(event)
                elif event_type == self.EVENT_TYPE_NOTIFICATION:
                    await self._handle_notification(event)
                elif event_type == self.EVENT_TYPE_REQUEST:
                    await self._handle_request(event)
                elif event_type == self.EVENT_TYPE_RESPONSE:
                    await self._handle_response(event)
                else:
                    logger.warning("Unknown event type: %s", event_type)
                
                self.event_queue.task_done()
            
            except Exception as e:
                logger.error("Error processing event: %s", e)
    
    def _connect_to_layers(self):
        """Connect to all layers using the protocol bridge."""
        if not self.protocol_bridge:
            logger.warning("Protocol bridge not available, cannot connect to layers")
            return
        
        layers = self.config.get('layers', [])
        
        for layer in layers:
            try:
                self.protocol_bridge.connect_to_layer(layer)
                self.layer_connections[layer] = {
                    'status': 'connected',
                    'timestamp': self._get_current_timestamp()
                }
                logger.info("Connected to layer: %s", layer)
            except Exception as e:
                logger.error("Error connecting to layer %s: %s", layer, e)
                self.layer_connections[layer] = {
                    'status': 'error',
                    'error': str(e),
                    'timestamp': self._get_current_timestamp()
                }
    
    async def _handle_context_updated(self, event):
        """
        Handle context updated event.
        
        Args:
            event: Event data
        """
        context_type = event.get('context_type')
        context_data = event.get('context_data', {})
        source = event.get('source')
        
        # Update context store
        if context_type in self.context_store:
            self.context_store[context_type].update(context_data)
        
        # Notify subscribers
        await self._notify_subscribers(context_type, event)
        
        # Propagate to other layers if from UI/UX layer
        if source == 'ui_ux_layer' and self.protocol_bridge:
            self._propagate_context_to_layers(context_type, context_data)
    
    async def _handle_state_changed(self, event):
        """
        Handle state changed event.
        
        Args:
            event: Event data
        """
        # Notify subscribers
        context_type = event.get('context_type')
        await self._notify_subscribers(context_type, event)
        
        # Propagate to other layers if needed
        source = event.get('source')
        if source == 'ui_ux_layer' and self.protocol_bridge:
            self._propagate_state_to_layers(event)
    
    async def _handle_command(self, event):
        """
        Handle command event.
        
        Args:
            event: Event data
        """
        # Notify subscribers
        context_type = event.get('context_type')
        await self._notify_subscribers(context_type, event)
        
        # Forward command to target layer if needed
        target = event.get('target')
        if target and target != 'ui_ux_layer' and self.protocol_bridge:
            self._forward_command_to_layer(event)
    
    async def _handle_notification(self, event):
        """
        Handle notification event.
        
        Args:
            event: Event data
        """
        # Notify subscribers
        context_type = event.get('context_type')
        await self._notify_subscribers(context_type, event)
    
    async def _handle_request(self, event):
        """
        Handle request event.
        
        Args:
            event: Event data
        """
        # Notify subscribers
        context_type = event.get('context_type')
        await self._notify_subscribers(context_type, event)
        
        # Forward request to target layer if needed
        target = event.get('target')
        if target and target != 'ui_ux_layer' and self.protocol_bridge:
            self._forward_request_to_layer(event)
    
    async def _handle_response(self, event):
        """
        Handle response event.
        
        Args:
            event: Event data
        """
        # Notify subscribers
        context_type = event.get('context_type')
        await self._notify_subscribers(context_type, event)
    
    async def _notify_subscribers(self, context_type: str, event: Dict[str, Any]):
        """
        Notify subscribers of an event.
        
        Args:
            context_type: Type of context
            event: Event data
        """
        # Notify subscribers for specific context type
        if context_type in self.subscribers:
            for callback in self.subscribers[context_type]:
                try:
                    callback(event)
                except Exception as e:
                    logger.error("Error in subscriber callback: %s", e)
        
        # Notify subscribers for all context types
        if '*' in self.subscribers:
            for callback in self.subscribers['*']:
                try:
                    callback(event)
                except Exception as e:
                    logger.error("Error in subscriber callback: %s", e)
    
    def _propagate_context_to_layers(self, context_type: str, context_data: Dict[str, Any]):
        """
        Propagate context to other layers.
        
        Args:
            context_type: Type of context
            context_data: Context data
        """
        if not self.protocol_bridge:
            return
        
        # Create message for each connected layer
        for layer, connection in self.layer_connections.items():
            if connection.get('status') != 'connected':
                continue
            
            message = {
                'protocol': 'mcp',
                'type': 'context_update',
                'source': 'ui_ux_layer',
                'target': layer,
                'payload': {
                    'context_type': context_type,
                    'context_data': context_data
                },
                'metadata': {
                    'timestamp': self._get_current_timestamp()
                }
            }
            
            try:
                self.protocol_bridge.send_message(message)
            except Exception as e:
                logger.error("Error propagating context to layer %s: %s", layer, e)
    
    def _propagate_state_to_layers(self, event: Dict[str, Any]):
        """
        Propagate state change to other layers.
        
        Args:
            event: Event data
        """
        if not self.protocol_bridge:
            return
        
        # Create message for each connected layer
        for layer, connection in self.layer_connections.items():
            if connection.get('status') != 'connected':
                continue
            
            message = {
                'protocol': 'mcp',
                'type': 'state_change',
                'source': 'ui_ux_layer',
                'target': layer,
                'payload': {
                    'entity_type': event.get('entity_type'),
                    'entity_id': event.get('entity_id'),
                    'state': event.get('state'),
                    'previous_state': event.get('previous_state')
                },
                'metadata': {
                    'timestamp': self._get_current_timestamp()
                }
            }
            
            try:
                self.protocol_bridge.send_message(message)
            except Exception as e:
                logger.error("Error propagating state to layer %s: %s", layer, e)
    
    def _forward_command_to_layer(self, event: Dict[str, Any]):
        """
        Forward command to target layer.
        
        Args:
            event: Event data
        """
        if not self.protocol_bridge:
            return
        
        target = event.get('target')
        
        if target not in self.layer_connections:
            logger.warning("Target layer not connected: %s", target)
            return
        
        if self.layer_connections[target].get('status') != 'connected':
            logger.warning("Target layer not connected: %s", target)
            return
        
        message = {
            'protocol': 'mcp',
            'type': 'command',
            'source': 'ui_ux_layer',
            'target': target,
            'payload': event.get('command_data', {}),
            'metadata': {
                'timestamp': self._get_current_timestamp(),
                'command_id': event.get('command_id')
            }
        }
        
        try:
            self.protocol_bridge.send_message(message)
        except Exception as e:
            logger.error("Error forwarding command to layer %s: %s", target, e)
    
    def _forward_request_to_layer(self, event: Dict[str, Any]):
        """
        Forward request to target layer.
        
        Args:
            event: Event data
        """
        if not self.protocol_bridge:
            return
        
        target = event.get('target')
        
        if target not in self.layer_connections:
            logger.warning("Target layer not connected: %s", target)
            return
        
        if self.layer_connections[target].get('status') != 'connected':
            logger.warning("Target layer not connected: %s", target)
            return
        
        message = {
            'protocol': 'mcp',
            'type': 'request',
            'source': 'ui_ux_layer',
            'target': target,
            'payload': event.get('request_data', {}),
            'metadata': {
                'timestamp': self._get_current_timestamp(),
                'request_id': event.get('request_id')
            }
        }
        
        try:
            self.protocol_bridge.send_message(message)
        except Exception as e:
            logger.error("Error forwarding request to layer %s: %s", target, e)
    
    def publish_context(self, context_type: str, context_data: Dict[str, Any], 
                       source: str = 'ui_ux_layer') -> bool:
        """
        Publish context data to the bus.
        
        Args:
            context_type: Type of context
            context_data: Context data
            source: Source of the context data
        
        Returns:
            bool: True if published successfully, False otherwise
        """
        logger.info("Publishing context: %s from %s", context_type, source)
        
        event = {
            'type': self.EVENT_TYPE_CONTEXT_UPDATED,
            'context_type': context_type,
            'context_data': context_data,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return True
        except Exception as e:
            logger.error("Error publishing context: %s", e)
            return False
    
    def publish_state_change(self, entity_type: str, entity_id: str, state: Any, 
                            previous_state: Any = None, source: str = 'ui_ux_layer') -> bool:
        """
        Publish state change to the bus.
        
        Args:
            entity_type: Type of entity
            entity_id: ID of entity
            state: New state
            previous_state: Previous state
            source: Source of the state change
        
        Returns:
            bool: True if published successfully, False otherwise
        """
        logger.info("Publishing state change for %s:%s from %s", 
                   entity_type, entity_id, source)
        
        # Determine context type based on entity type
        context_type = self._entity_type_to_context_type(entity_type)
        
        event = {
            'type': self.EVENT_TYPE_STATE_CHANGED,
            'context_type': context_type,
            'entity_type': entity_type,
            'entity_id': entity_id,
            'state': state,
            'previous_state': previous_state,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return True
        except Exception as e:
            logger.error("Error publishing state change: %s", e)
            return False
    
    def publish_command(self, target: str, command_data: Dict[str, Any], 
                       source: str = 'ui_ux_layer') -> str:
        """
        Publish command to the bus.
        
        Args:
            target: Target of the command
            command_data: Command data
            source: Source of the command
        
        Returns:
            str: Command ID
        """
        import uuid
        
        command_id = f"cmd-{uuid.uuid4().hex[:8]}"
        
        logger.info("Publishing command: %s to %s from %s", 
                   command_id, target, source)
        
        # Determine context type based on target
        context_type = self._target_to_context_type(target)
        
        event = {
            'type': self.EVENT_TYPE_COMMAND,
            'context_type': context_type,
            'command_id': command_id,
            'command_data': command_data,
            'target': target,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return command_id
        except Exception as e:
            logger.error("Error publishing command: %s", e)
            return ""
    
    def publish_notification(self, notification_data: Dict[str, Any], 
                            context_type: str = None, source: str = 'ui_ux_layer') -> str:
        """
        Publish notification to the bus.
        
        Args:
            notification_data: Notification data
            context_type: Type of context
            source: Source of the notification
        
        Returns:
            str: Notification ID
        """
        import uuid
        
        notification_id = f"notif-{uuid.uuid4().hex[:8]}"
        
        logger.info("Publishing notification: %s from %s", 
                   notification_id, source)
        
        # Use system context type if not specified
        if not context_type:
            context_type = self.CONTEXT_TYPE_SYSTEM
        
        event = {
            'type': self.EVENT_TYPE_NOTIFICATION,
            'context_type': context_type,
            'notification_id': notification_id,
            'notification_data': notification_data,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return notification_id
        except Exception as e:
            logger.error("Error publishing notification: %s", e)
            return ""
    
    def publish_request(self, target: str, request_data: Dict[str, Any], 
                       source: str = 'ui_ux_layer') -> str:
        """
        Publish request to the bus.
        
        Args:
            target: Target of the request
            request_data: Request data
            source: Source of the request
        
        Returns:
            str: Request ID
        """
        import uuid
        
        request_id = f"req-{uuid.uuid4().hex[:8]}"
        
        logger.info("Publishing request: %s to %s from %s", 
                   request_id, target, source)
        
        # Determine context type based on target
        context_type = self._target_to_context_type(target)
        
        event = {
            'type': self.EVENT_TYPE_REQUEST,
            'context_type': context_type,
            'request_id': request_id,
            'request_data': request_data,
            'target': target,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return request_id
        except Exception as e:
            logger.error("Error publishing request: %s", e)
            return ""
    
    def publish_response(self, request_id: str, response_data: Dict[str, Any], 
                        target: str = None, source: str = 'ui_ux_layer') -> bool:
        """
        Publish response to the bus.
        
        Args:
            request_id: ID of the request
            response_data: Response data
            target: Target of the response
            source: Source of the response
        
        Returns:
            bool: True if published successfully, False otherwise
        """
        logger.info("Publishing response for request: %s from %s", 
                   request_id, source)
        
        # Determine context type based on target
        context_type = self._target_to_context_type(target) if target else self.CONTEXT_TYPE_SYSTEM
        
        event = {
            'type': self.EVENT_TYPE_RESPONSE,
            'context_type': context_type,
            'request_id': request_id,
            'response_data': response_data,
            'target': target,
            'source': source,
            'timestamp': self._get_current_timestamp()
        }
        
        try:
            self.event_queue.put_nowait(event)
            return True
        except Exception as e:
            logger.error("Error publishing response: %s", e)
            return False
    
    def subscribe(self, context_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Subscribe to events for a specific context type.
        
        Args:
            context_type: Type of context to subscribe to, or '*' for all
            callback: Callback function to be called when event occurs
        
        Returns:
            bool: True if subscription was successful, False otherwise
        """
        logger.info("Subscribing to context type: %s", context_type)
        
        if context_type not in self.subscribers:
            self.subscribers[context_type] = set()
        
        self.subscribers[context_type].add(callback)
        return True
    
    def unsubscribe(self, context_type: str, callback: Callable[[Dict[str, Any]], None]) -> bool:
        """
        Unsubscribe from events for a specific context type.
        
        Args:
            context_type: Type of context to unsubscribe from
            callback: Callback function to be removed
        
        Returns:
            bool: True if unsubscription was successful, False otherwise
        """
        logger.info("Unsubscribing from context type: %s", context_type)
        
        if context_type in self.subscribers and callback in self.subscribers[context_type]:
            self.subscribers[context_type].remove(callback)
            return True
        
        return False
    
    def get_context(self, context_type: str) -> Dict[str, Any]:
        """
        Get context data for a specific context type.
        
        Args:
            context_type: Type of context to get
        
        Returns:
            Dict[str, Any]: Context data
        """
        if context_type not in self.context_store:
            logger.warning("Unknown context type: %s", context_type)
            return {}
        
        return self.context_store[context_type].copy()
    
    def get_all_context(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all context data.
        
        Returns:
            Dict[str, Dict[str, Any]]: All context data
        """
        return {k: v.copy() for k, v in self.context_store.items()}
    
    def get_layer_connection_status(self, layer: str) -> str:
        """
        Get connection status for a specific layer.
        
        Args:
            layer: Layer to get status for
        
        Returns:
            str: Connection status
        """
        if layer not in self.layer_connections:
            return 'unknown'
        
        return self.layer_connections[layer].get('status', 'unknown')
    
    def get_all_layer_connection_statuses(self) -> Dict[str, str]:
        """
        Get connection status for all layers.
        
        Returns:
            Dict[str, str]: Connection status for all layers
        """
        return {layer: connection.get('status', 'unknown') 
                for layer, connection in self.layer_connections.items()}
    
    def shutdown(self):
        """Shutdown the Real-Time Context Bus."""
        logger.info("Shutting down Real-Time Context Bus")
        
        # Stop event loop
        self.running = False
        
        # Disconnect from all layers
        if self.protocol_bridge:
            for layer in self.layer_connections:
                try:
                    self.protocol_bridge.disconnect_from_layer(layer)
                except Exception as e:
                    logger.error("Error disconnecting from layer %s: %s", layer, e)
        
        # Clear subscribers
        self.subscribers.clear()
        
        logger.info("Real-Time Context Bus shutdown complete")
    
    def _entity_type_to_context_type(self, entity_type: str) -> str:
        """
        Convert entity type to context type.
        
        Args:
            entity_type: Entity type
        
        Returns:
            str: Context type
        """
        # Map entity types to context types
        entity_to_context = {
            'user': self.CONTEXT_TYPE_USER,
            'device': self.CONTEXT_TYPE_DEVICE,
            'environment': self.CONTEXT_TYPE_ENVIRONMENT,
            'workflow': self.CONTEXT_TYPE_WORKFLOW,
            'system': self.CONTEXT_TYPE_SYSTEM,
            'agent': self.CONTEXT_TYPE_AGENT,
            'capsule': self.CONTEXT_TYPE_CAPSULE,
            'layer': self.CONTEXT_TYPE_LAYER
        }
        
        return entity_to_context.get(entity_type.lower(), self.CONTEXT_TYPE_SYSTEM)
    
    def _target_to_context_type(self, target: str) -> str:
        """
        Convert target to context type.
        
        Args:
            target: Target
        
        Returns:
            str: Context type
        """
        # Map targets to context types
        target_to_context = {
            'user': self.CONTEXT_TYPE_USER,
            'device': self.CONTEXT_TYPE_DEVICE,
            'environment': self.CONTEXT_TYPE_ENVIRONMENT,
            'workflow': self.CONTEXT_TYPE_WORKFLOW,
            'system': self.CONTEXT_TYPE_SYSTEM,
            'agent': self.CONTEXT_TYPE_AGENT,
            'capsule': self.CONTEXT_TYPE_CAPSULE,
            'data_layer': self.CONTEXT_TYPE_LAYER,
            'core_ai_layer': self.CONTEXT_TYPE_LAYER,
            'generative_layer': self.CONTEXT_TYPE_LAYER,
            'application_layer': self.CONTEXT_TYPE_LAYER,
            'protocol_layer': self.CONTEXT_TYPE_LAYER,
            'workflow_layer': self.CONTEXT_TYPE_LAYER,
            'ui_ux_layer': self.CONTEXT_TYPE_LAYER,
            'security_layer': self.CONTEXT_TYPE_LAYER
        }
        
        return target_to_context.get(target.lower(), self.CONTEXT_TYPE_SYSTEM)
    
    def _get_current_timestamp(self) -> int:
        """
        Get current timestamp.
        
        Returns:
            int: Current timestamp in milliseconds
        """
        import time
        return int(time.time() * 1000)
    
    def to_json(self) -> str:
        """
        Serialize context bus state to JSON.
        
        Returns:
            str: JSON string representation of context bus state
        """
        state = {
            'context_store': self.context_store,
            'layer_connections': self.layer_connections
        }
        
        return json.dumps(state)
    
    def from_json(self, json_str: str) -> bool:
        """
        Deserialize context bus state from JSON.
        
        Args:
            json_str: JSON string representation of context bus state
        
        Returns:
            bool: True if deserialization was successful, False otherwise
        """
        try:
            state = json.loads(json_str)
            
            self.context_store = state.get('context_store', {})
            self.layer_connections = state.get('layer_connections', {})
            
            return True
        except Exception as e:
            logger.error("Error deserializing context bus state: %s", e)
            return False
